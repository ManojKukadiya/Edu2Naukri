-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 03, 2020 at 06:06 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `edu2naukri`
--

-- --------------------------------------------------------

--
-- Table structure for table `aboutus`
--

DROP TABLE IF EXISTS `aboutus`;
CREATE TABLE IF NOT EXISTS `aboutus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aboutus` text NOT NULL,
  `contactus` text NOT NULL,
  `team` text NOT NULL,
  `fbnative` varchar(512) NOT NULL,
  `fbbanner` varchar(512) NOT NULL,
  `fbnativebanner` varchar(512) NOT NULL,
  `fbinterstitial` varchar(512) NOT NULL,
  `fbrewarded` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aboutus`
--

INSERT INTO `aboutus` (`id`, `aboutus`, `contactus`, `team`, `fbnative`, `fbbanner`, `fbnativebanner`, `fbinterstitial`, `fbrewarded`) VALUES
(1, 'About us 123', '<h1>Hello</h1>', 'Team Us', 'aaaa', 'aaa', 'aaa', 'aaa', 'aaa');

-- --------------------------------------------------------

--
-- Table structure for table `appdescription`
--

DROP TABLE IF EXISTS `appdescription`;
CREATE TABLE IF NOT EXISTS `appdescription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `step` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=82 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appdescription`
--

INSERT INTO `appdescription` (`id`, `app_id`, `step`) VALUES
(33, 4, 'Click to the link'),
(34, 4, 'Go to YouTube video description'),
(43, 3, 'discription'),
(41, 3, 'Install and Register must '),
(42, 3, 'Use 15 days = 20 Rs'),
(58, 6, 'Use app 10 days minimum '),
(59, 6, 'Open app & install 3 ads'),
(81, 7, 'Vishvesh'),
(57, 6, 'Install and Register must '),
(80, 7, 'Raju'),
(79, 7, 'Manoj');

-- --------------------------------------------------------

--
-- Table structure for table `appinstall`
--

DROP TABLE IF EXISTS `appinstall`;
CREATE TABLE IF NOT EXISTS `appinstall` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `user_id` int(100) NOT NULL,
  `devicetoken` varchar(100) NOT NULL,
  `app_id` int(100) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appinstall`
--

INSERT INTO `appinstall` (`id`, `user_id`, `devicetoken`, `app_id`, `created`, `modified`) VALUES
(15, 18, '3090376804996733', 3, '2020-05-10 19:29:55', '2020-05-10 19:29:55'),
(14, 8, '30cc83bd8992f576', 3, '2020-05-10 18:13:28', '2020-05-10 18:13:28'),
(10, 10, '4a71dda6a9ab3623', 3, '2020-05-08 19:19:49', '2020-05-08 19:19:49'),
(11, 11, '704b5c46f18bea77', 3, '2020-05-08 20:08:33', '2020-05-08 20:08:33'),
(16, 10, '4a71dda6a9ab3623', 5, '2020-05-10 19:39:04', '2020-05-10 19:39:04'),
(17, 11, '704b5c46f18bea77', 5, '2020-05-10 19:39:15', '2020-05-10 19:39:15'),
(18, 10, '4a71dda6a9ab3623', 7, '2020-05-19 14:08:20', '2020-05-19 14:08:20'),
(19, 53, '56fd1cfd6266ec09', 5, '2020-05-26 15:13:12', '2020-05-26 15:13:12');

-- --------------------------------------------------------

--
-- Table structure for table `applist`
--

DROP TABLE IF EXISTS `applist`;
CREATE TABLE IF NOT EXISTS `applist` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `shortdesc` text DEFAULT NULL,
  `package` text NOT NULL,
  `image` text NOT NULL,
  `amount` int(100) NOT NULL,
  `link` varchar(100) NOT NULL,
  `priority` int(100) NOT NULL,
  `videourl` text NOT NULL,
  `offertype` int(11) NOT NULL,
  `descshow` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applist`
--

INSERT INTO `applist` (`id`, `title`, `shortdesc`, `package`, `image`, `amount`, `link`, `priority`, `videourl`, `offertype`, `descshow`, `status`, `created`, `modified`) VALUES
(4, 'Rummy Culture', 'Best Rummy Gaming Experience', 'com.gameskraft.rummyculturelite', 'https://images.downtoid.in/apps/1587640634-CFF3FBF6-4A58-4B90-AB2D-E8F157984A3C.png', 6, 'https://play.google.com/store/apps/details?id=com.gameskraft.rummyculturelite', 0, '', 0, 1, 0, '2020-05-03 19:18:04', '2020-05-14 02:03:46'),
(3, 'All Government Jobs Alerts ( Sarkari Naukri 2020 )', 'Best RewardsTournaments	', 'com.allgovernmentjobs', 'https://lh3.googleusercontent.com/EcFxDMRVacp0NmtCBeMiIYBRVUnH2oOXOHcgQ5HciFMXQTba2jjHaL2zKWUSsJUEnkU=s180-rw', 500, 'https://play.google.com/store/apps/details?id=com.allgovernmentjobs', 0, 'https://www.youtube.com/watch?v=0KNk-Joi-NM', 1, 1, 0, '2020-05-03 19:17:06', '2020-05-18 03:13:14'),
(6, 'Shayari arena', 'Best Shayari app', 'com.techno.myapplication', 'https://lh3.googleusercontent.com/EFW5lYpMVkawY4UDxNTT0tBDfE9FnIE_suniROuhZgyHD7m2-KobCfcIYXUQ1hk0lg=s180-rw', 5000, 'https://play.google.com/store/apps/details?id=com.techno.myapplication', 1, '', 1, 0, 0, '2020-05-16 06:50:11', '2020-05-26 03:22:15'),
(5, '4Fun app', 'Install the app & Get Reward ', 'com.nebula.mamu', 'https://lh3.googleusercontent.com/AZT7-MRSfoptSgzgEiwsiccMSNXHM9bG7YWUvFtSFaDNdwKv78-7pxWET8BVhMYReeI=s180-rw', 5000, 'http://4funindia.com/u/19442028/', 2, '', 0, 0, 0, '2020-05-03 19:17:06', '2020-05-26 02:46:17'),
(7, 'Ace2three', 'Play Rummy game', 'air.com.ace2three.mobile.cash', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQOm28iyMLaPFzZUVqg7ayP1NHjKPYFn85OJITB5KDxejZVvdkI&usqp=CAU', 3000, 'https://infinite-mobility.g2afse.com/click?pid=391&offer_id=31988', 2, '', 1, 0, 0, '2020-05-18 00:15:39', '2020-05-26 02:45:49');

-- --------------------------------------------------------

--
-- Table structure for table `appsettings`
--

DROP TABLE IF EXISTS `appsettings`;
CREATE TABLE IF NOT EXISTS `appsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coin` int(11) NOT NULL,
  `miniwith` int(11) NOT NULL,
  `reffercoin` int(11) NOT NULL,
  `min_coin` int(10) NOT NULL,
  `max_coin` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appsettings`
--

INSERT INTO `appsettings` (`id`, `coin`, `miniwith`, `reffercoin`, `min_coin`, `max_coin`) VALUES
(1, 1000, 220, 5000, 15, 35);

-- --------------------------------------------------------

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
CREATE TABLE IF NOT EXISTS `coin` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `user_id` int(100) NOT NULL,
  `totalcoin` int(100) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coin`
--

INSERT INTO `coin` (`id`, `user_id`, `totalcoin`, `created`, `modified`) VALUES
(1, 7, 1751, '2020-05-03 23:24:05', '2020-05-14 06:17:21'),
(2, 8, 700, '2020-05-05 04:51:23', '2020-05-18 20:44:09'),
(3, 9, 49, '2020-05-05 06:41:00', '2020-05-18 22:25:17'),
(4, 10, 400, '2020-05-05 06:44:40', '2020-05-19 01:38:20'),
(5, 11, 242, '2020-05-05 07:41:13', '2020-05-17 19:18:23'),
(6, 12, 32, '2020-05-05 08:46:34', '2020-05-15 07:23:13'),
(7, 13, 0, '2020-05-05 10:42:48', '0000-00-00 00:00:00'),
(8, 14, 0, '2020-05-05 11:04:35', '0000-00-00 00:00:00'),
(9, 15, 0, '2020-05-08 06:35:02', '0000-00-00 00:00:00'),
(10, 16, 0, '2020-05-08 06:35:02', '0000-00-00 00:00:00'),
(11, 17, 0, '2020-05-08 06:41:06', '0000-00-00 00:00:00'),
(12, 18, 100, '2020-05-10 06:59:18', '2020-05-10 06:59:55'),
(13, 19, 0, '2020-05-11 08:28:44', '0000-00-00 00:00:00'),
(14, 20, 0, '2020-05-11 09:45:36', '0000-00-00 00:00:00'),
(15, 21, 0, '2020-05-11 10:59:31', '0000-00-00 00:00:00'),
(16, 22, 0, '2020-05-11 11:48:51', '0000-00-00 00:00:00'),
(17, 23, 0, '2020-05-12 08:34:27', '0000-00-00 00:00:00'),
(18, 24, 18, '2020-05-14 08:19:17', '2020-05-14 08:19:32'),
(19, 25, 20, '2020-05-15 07:25:15', '2020-05-15 07:26:59'),
(20, 26, 0, '2020-05-15 07:41:13', '0000-00-00 00:00:00'),
(21, 27, 0, '2020-05-15 07:47:20', '0000-00-00 00:00:00'),
(22, 28, 0, '2020-05-15 11:56:02', '0000-00-00 00:00:00'),
(23, 29, 8, '2020-05-16 08:50:24', '2020-05-16 21:00:30'),
(24, 30, 10, '2020-05-16 08:59:48', '2020-05-16 09:00:19'),
(25, 31, 19, '2020-05-16 09:01:46', '2020-05-19 00:08:34'),
(26, 32, 0, '2020-05-17 21:11:30', '0000-00-00 00:00:00'),
(27, 33, 0, '2020-05-17 22:54:54', '0000-00-00 00:00:00'),
(28, 34, 0, '2020-05-18 02:10:10', '0000-00-00 00:00:00'),
(29, 35, 0, '2020-05-18 02:11:14', '0000-00-00 00:00:00'),
(30, 36, 30, '2020-05-18 02:16:49', '2020-05-18 02:16:49'),
(31, 37, 30, '2020-05-18 02:18:14', '2020-05-18 02:18:14'),
(32, 38, 30, '2020-05-18 02:19:56', '2020-05-18 02:19:56'),
(33, 39, 30, '2020-05-18 02:20:49', '2020-05-18 02:20:49'),
(34, 40, 30, '2020-05-18 02:22:44', '2020-05-18 02:22:44'),
(35, 41, 30, '2020-05-18 02:24:49', '2020-05-18 02:24:49'),
(36, 42, 30, '2020-05-18 02:26:38', '2020-05-18 02:26:38'),
(37, 43, 30, '2020-05-18 02:27:18', '2020-05-18 02:27:18'),
(38, 44, 30, '2020-05-18 02:28:31', '2020-05-18 02:28:31'),
(39, 45, 30, '2020-05-18 02:30:34', '2020-05-18 02:30:34'),
(40, 46, 30, '2020-05-18 02:31:10', '2020-05-18 02:31:10'),
(41, 47, 30, '2020-05-18 02:32:10', '2020-05-18 02:32:10'),
(42, 48, 30, '2020-05-18 02:32:38', '2020-05-18 02:32:38'),
(43, 49, 0, '2020-05-18 02:36:16', '0000-00-00 00:00:00'),
(44, 50, 0, '2020-05-18 02:37:29', '0000-00-00 00:00:00'),
(45, 51, 0, '2020-05-18 02:38:23', '0000-00-00 00:00:00'),
(46, 52, 50, '2020-05-18 02:39:50', '2020-05-18 02:39:50'),
(47, 53, 50, '2020-05-18 05:46:47', '2020-05-26 02:43:12'),
(48, 54, 0, '2020-05-21 04:40:20', '0000-00-00 00:00:00'),
(49, 55, 0, '2020-05-21 05:07:09', '0000-00-00 00:00:00'),
(50, 56, 0, '2020-05-21 05:16:34', '0000-00-00 00:00:00'),
(51, 57, 0, '2020-05-21 05:16:44', '0000-00-00 00:00:00'),
(52, 58, 0, '2020-05-21 05:17:14', '0000-00-00 00:00:00'),
(53, 59, 0, '2020-05-21 05:17:59', '0000-00-00 00:00:00'),
(54, 60, 0, '2020-05-21 05:18:15', '0000-00-00 00:00:00'),
(55, 61, 0, '2020-05-21 05:18:44', '0000-00-00 00:00:00'),
(56, 62, 0, '2020-05-21 05:24:52', '0000-00-00 00:00:00'),
(57, 63, 0, '2020-05-21 05:25:29', '0000-00-00 00:00:00'),
(58, 64, 0, '2020-05-21 05:37:22', '0000-00-00 00:00:00'),
(59, 65, 0, '2020-05-21 05:37:49', '0000-00-00 00:00:00'),
(60, 66, 0, '2020-05-22 00:23:36', '0000-00-00 00:00:00'),
(61, 67, 0, '2020-05-22 00:24:35', '0000-00-00 00:00:00'),
(62, 68, 0, '2020-05-22 00:25:03', '0000-00-00 00:00:00'),
(63, 69, 0, '2020-05-22 00:26:12', '0000-00-00 00:00:00'),
(64, 70, 0, '2020-05-22 00:27:59', '0000-00-00 00:00:00'),
(65, 71, 0, '2020-05-22 00:28:50', '0000-00-00 00:00:00'),
(66, 72, 0, '2020-05-22 00:29:05', '0000-00-00 00:00:00'),
(67, 73, 0, '2020-05-22 00:29:43', '0000-00-00 00:00:00'),
(68, 74, 0, '2020-05-22 00:30:23', '0000-00-00 00:00:00'),
(69, 75, 0, '2020-05-22 00:33:12', '0000-00-00 00:00:00'),
(70, 76, 0, '2020-05-22 00:40:16', '0000-00-00 00:00:00'),
(71, 77, 0, '2020-05-22 00:41:04', '0000-00-00 00:00:00'),
(72, 78, 0, '2020-05-22 01:21:32', '0000-00-00 00:00:00'),
(73, 79, 0, '2020-05-22 01:32:32', '0000-00-00 00:00:00'),
(74, 80, 0, '2020-05-22 01:35:30', '0000-00-00 00:00:00'),
(75, 81, 0, '2020-05-22 01:37:23', '0000-00-00 00:00:00'),
(76, 82, 0, '2020-05-22 01:37:39', '0000-00-00 00:00:00'),
(77, 83, 0, '2020-05-22 01:41:34', '0000-00-00 00:00:00'),
(78, 84, 0, '2020-05-22 01:41:57', '0000-00-00 00:00:00'),
(79, 85, 0, '2020-05-22 01:48:15', '0000-00-00 00:00:00'),
(80, 86, 0, '2020-05-22 02:08:50', '0000-00-00 00:00:00'),
(81, 87, 0, '2020-05-22 02:09:44', '0000-00-00 00:00:00'),
(82, 88, 6, '2020-05-22 09:21:13', '2020-05-22 09:21:25'),
(83, 89, 0, '2020-05-26 00:02:23', '0000-00-00 00:00:00'),
(84, 90, 2, '2020-05-26 00:03:54', '2020-05-26 00:03:57'),
(85, 91, 0, '2020-05-26 05:31:35', '0000-00-00 00:00:00'),
(86, 92, 10, '2020-05-26 18:59:56', '2020-05-26 19:05:34'),
(87, 93, 131, '2020-06-02 06:26:18', '2020-06-03 11:31:58');

-- --------------------------------------------------------

--
-- Table structure for table `contactform`
--

DROP TABLE IF EXISTS `contactform`;
CREATE TABLE IF NOT EXISTS `contactform` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

DROP TABLE IF EXISTS `contactus`;
CREATE TABLE IF NOT EXISTS `contactus` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `heading` varchar(512) NOT NULL,
  `message` text NOT NULL,
  `user_id` int(100) NOT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`id`, `heading`, `message`, `user_id`, `created`, `modified`) VALUES
(1, 'Issue', 'Text Message', 7, '2020-05-12 12:21:10', '0000-00-00 00:00:00'),
(2, 'Hello', 'Message', 7, '2020-05-12 12:22:17', '0000-00-00 00:00:00'),
(3, 'Hello', 'Message', 7, '2020-05-12 13:54:12', '2020-05-12 13:54:12'),
(4, 'Hello', 'Message', 7, '2020-05-12 16:00:15', '2020-05-12 16:00:15'),
(5, 'test', 'testing', 8, '2020-05-12 18:55:58', '2020-05-12 18:55:58'),
(6, 'hello', 'he', 9, '2020-05-17 23:15:59', '2020-05-17 23:15:59');

-- --------------------------------------------------------

--
-- Table structure for table `jobcategory`
--

DROP TABLE IF EXISTS `jobcategory`;
CREATE TABLE IF NOT EXISTS `jobcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobcategory`
--

INSERT INTO `jobcategory` (`id`, `name`) VALUES
(2, 'PSC'),
(3, 'SSC'),
(4, 'WALK IN INTERVIEW'),
(5, 'BANKING'),
(6, 'RAILWAY'),
(7, 'POLICE'),
(8, 'DEFENCE'),
(9, 'ENGINEERING'),
(10, 'Test1'),
(12, 'Test11');

-- --------------------------------------------------------

--
-- Table structure for table `jobfavorite`
--

DROP TABLE IF EXISTS `jobfavorite`;
CREATE TABLE IF NOT EXISTS `jobfavorite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `job_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobfavorite`
--

INSERT INTO `jobfavorite` (`id`, `user_id`, `job_id`) VALUES
(6, 7, 1),
(4, 7, 3),
(54, 20, 4),
(53, 20, 1),
(9, 9, 1),
(10, 9, 2),
(11, 9, 3),
(12, 9, 4),
(50, 10, 3),
(51, 10, 4),
(49, 10, 2),
(48, 10, 1),
(37, 9, 6),
(56, 18, 2),
(27, 13, 10),
(28, 13, 4),
(29, 13, 1),
(30, 13, 2),
(31, 9, 9),
(32, 9, 10),
(33, 9, 8),
(38, 9, 7),
(55, 21, 3),
(57, 18, 3),
(58, 18, 1),
(59, 25, 1),
(62, 9, 5),
(61, 25, 4),
(63, 33, 3),
(64, 33, 4),
(65, 89, 1);

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `category` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `jobqulification` int(11) NOT NULL,
  `lastdate` date NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `title`, `category`, `state`, `jobqulification`, `lastdate`, `status`, `created`, `modified`) VALUES
(1, 'Central Government Jobs 2020-21', 4, 4, 3, '2020-05-09', 1, '2020-05-03 20:58:34', '2020-06-02 11:20:52'),
(2, 'Chhattisgarh State Power Generation Company Limited', 0, 4, 0, '2020-05-05', 1, '2020-05-03 20:58:34', '2020-05-26 01:14:39'),
(3, 'IISER TVM', 7, 18, 12, '2020-05-03', 1, '2020-05-03 20:58:34', '2020-05-05 05:24:27'),
(4, 'Posted on : Just Now Acharya Shree Bhikshu Hospital - Govt.of Delhi', 5, 8, 1, '2020-05-03', 1, '2020-05-03 20:58:34', '2020-05-05 05:17:37'),
(5, 'Posted on : Just Now Tata Medical Center', 4, 20, 3, '2020-05-15', 1, '2020-05-03 20:58:34', '2020-05-05 05:17:57'),
(6, 'Tata Medical Center', 8, 6, 4, '2020-05-03', 1, '2020-05-03 20:58:34', '2020-05-05 05:18:19'),
(7, 'Amity University', 5, 9, 15, '2020-05-03', 1, '2020-05-03 20:58:34', '2020-05-05 05:23:57'),
(8, 'Numaligarh Refinery Limited', 5, 8, 10, '2020-05-03', 1, '2020-05-03 20:58:34', '2020-05-05 05:25:09'),
(9, 'Dr Hedgewar Arogya Sansthan - Govt. of Delhi', 2, 9, 7, '2020-05-03', 1, '2020-05-03 20:58:34', '2020-05-05 05:25:29'),
(10, 'Goverment Job', 2, 15, 10, '2020-05-03', 1, '2020-05-03 20:58:34', '2020-05-05 05:25:43'),
(11, 'Test Job', 3, 19, 14, '2020-05-15', 0, '2020-05-16 06:59:05', '0000-00-00 00:00:00'),
(12, 'Sub Goverment Jobs', 2, 18, 17, '2020-05-09', 0, '2020-05-16 07:00:13', '0000-00-00 00:00:00'),
(13, 'Sub Goverment Jobs', 2, 18, 17, '2020-05-09', 0, '2020-05-16 07:00:27', '0000-00-00 00:00:00'),
(14, 'UPSC', 1, 1, 1, '2020-05-22', 0, '2020-05-17 21:11:24', '0000-00-00 00:00:00'),
(15, 'Government Medical College & Hospital Chandigarh', 3, 6, 5, '2020-06-01', 0, '2020-05-26 00:37:04', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `qualification`
--

DROP TABLE IF EXISTS `qualification`;
CREATE TABLE IF NOT EXISTS `qualification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qualification`
--

INSERT INTO `qualification` (`id`, `name`) VALUES
(1, '10th Pass'),
(2, '12th Pass'),
(3, 'BCA'),
(4, 'MCA'),
(5, 'MBBS'),
(6, 'Graduate'),
(7, 'Post Graduate'),
(8, 'Diploma Engineering'),
(9, 'ITI & Equivalent'),
(10, 'Diploma in Nursing'),
(11, 'Engineering'),
(12, 'Medical degree'),
(13, 'Hospital'),
(14, 'Diploma'),
(15, 'HTAT'),
(17, 'CA'),
(18, '8th Pass'),
(19, 'LLB');

-- --------------------------------------------------------

--
-- Table structure for table `redeemmoney`
--

DROP TABLE IF EXISTS `redeemmoney`;
CREATE TABLE IF NOT EXISTS `redeemmoney` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `user_id` int(100) NOT NULL,
  `mode` varchar(100) NOT NULL,
  `upi` varbinary(512) DEFAULT NULL,
  `phoneno` int(10) DEFAULT NULL,
  `bankname` varchar(512) NOT NULL,
  `bankaccount` varchar(512) NOT NULL,
  `bankifsc` varchar(512) NOT NULL,
  `amount` double NOT NULL,
  `transation_id` text NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `redeemmoney`
--

INSERT INTO `redeemmoney` (`id`, `user_id`, `mode`, `upi`, `phoneno`, `bankname`, `bankaccount`, `bankifsc`, `amount`, `transation_id`, `created`, `modified`, `status`) VALUES
(1, 7, 'paytm', '', 2147483647, '', '', '', 10, 'Transation', '2020-05-09 03:55:25', '2020-05-18 03:03:09', 1),
(2, 10, 'paytm', 0x38343838393732313834, 2147483647, '', '20', '', 20, 'Transation', '2020-05-11 06:03:17', '2020-05-18 03:09:10', 2);

-- --------------------------------------------------------

--
-- Table structure for table `referralcode`
--

DROP TABLE IF EXISTS `referralcode`;
CREATE TABLE IF NOT EXISTS `referralcode` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `sender_id` int(100) NOT NULL,
  `receiver_id` int(100) NOT NULL,
  `status` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `referralcode`
--

INSERT INTO `referralcode` (`id`, `sender_id`, `receiver_id`, `status`) VALUES
(1, 36, 8, 1),
(2, 37, 8, 1),
(3, 38, 8, 1),
(4, 39, 8, 1),
(5, 40, 8, 1),
(6, 41, 8, 1),
(7, 42, 8, 1),
(8, 43, 8, 1),
(9, 44, 8, 1),
(10, 45, 8, 1),
(11, 46, 8, 1),
(12, 47, 8, 1),
(13, 48, 8, 1),
(14, 49, 8, 1),
(15, 50, 8, 1),
(16, 51, 8, 1),
(17, 52, 8, 1);

-- --------------------------------------------------------

--
-- Table structure for table `settinginvite`
--

DROP TABLE IF EXISTS `settinginvite`;
CREATE TABLE IF NOT EXISTS `settinginvite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(512) NOT NULL,
  `message` text NOT NULL,
  `link` varchar(512) NOT NULL,
  `term` text NOT NULL,
  `invitecoin` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settinginvite`
--

INSERT INTO `settinginvite` (`id`, `image`, `message`, `link`, `term`, `invitecoin`) VALUES
(1, 'uploads/1589775472_refer.png', 'Hey! Checkout this amazing app. Complete some offers and get rewards. Earn daily upto 1000 Rs Paytm cash at home ?.', 'https://play.google.com/store/apps/details?id=com.edu.sarkari.naukri', '						  						  						  						  						  **Share your referral code.\r\n1. Get Rs 6 for every successful referral. \r\n\r\n2. Device must be a unique device and should never be used to login on Edu2naukri before.\r\n\r\n3. You will only get credits if your friend will enter your referral and after that complete at least 1 offer.\r\n \r\n4. There is no limit on referrals. \r\n\r\n5. Edu2naukri has the rights to revert the amount any time without any prior notice.						  						  						  						  						  ', 5000);

-- --------------------------------------------------------

--
-- Table structure for table `settingredeem`
--

DROP TABLE IF EXISTS `settingredeem`;
CREATE TABLE IF NOT EXISTS `settingredeem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` int(11) NOT NULL,
  `redeemteam` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settingredeem`
--

INSERT INTO `settingredeem` (`id`, `amount`, `redeemteam`) VALUES
(1, 217, '1. Credits will be transferred within 24 hours\r\n2. There will be 10% Charges For Every Redeem.			\r\n2. There will be 10% Charges For Every Redeem.										');

-- --------------------------------------------------------

--
-- Table structure for table `settingsversion`
--

DROP TABLE IF EXISTS `settingsversion`;
CREATE TABLE IF NOT EXISTS `settingsversion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(512) NOT NULL,
  `minversion` varchar(512) NOT NULL,
  `updatelink` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settingsversion`
--

INSERT INTO `settingsversion` (`id`, `version`, `minversion`, `updatelink`) VALUES
(1, '2387', '23', 'https://play.google.com/store/apps/details?id=com.phone.pocket');

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

DROP TABLE IF EXISTS `state`;
CREATE TABLE IF NOT EXISTS `state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`id`, `name`) VALUES
(1, 'Andaman & Nicobar Islands'),
(2, 'Andhra Pradesh'),
(3, 'Arunachal Pradesh'),
(4, 'Assam'),
(5, 'Bihar'),
(6, 'Chandigarh'),
(7, 'Chhattisgarh'),
(8, 'Dadra & Nagar Haveli'),
(9, 'Daman & Diu'),
(10, 'Delhi'),
(11, 'Goa'),
(12, 'Gujarat'),
(13, 'Haryana'),
(14, 'Himachal Pradesh'),
(15, 'Jammu & Kashmir'),
(16, 'Jharkhand'),
(17, 'Karnataka'),
(18, 'Kerala'),
(19, 'Lakshadweep'),
(20, 'Madhya Pradesh'),
(21, 'Maharashtra'),
(22, 'Manipur'),
(23, 'Meghalaya'),
(24, 'Mizoram'),
(25, 'Nagaland'),
(26, 'Odisha'),
(27, 'Puducherry'),
(28, 'Punjab'),
(29, 'Rajasthan'),
(30, 'Sikkim'),
(31, 'Tamil Nadu'),
(32, 'Telangana'),
(33, 'Tripura'),
(34, 'Uttar Pradesh'),
(35, 'Uttarakhand'),
(36, 'West Bengal');

-- --------------------------------------------------------

--
-- Table structure for table `subjobs`
--

DROP TABLE IF EXISTS `subjobs`;
CREATE TABLE IF NOT EXISTS `subjobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `title` varchar(512) NOT NULL,
  `qualification` text NOT NULL,
  `link` text NOT NULL,
  `noofpost` text NOT NULL,
  `salary` text NOT NULL,
  `agelimit` text NOT NULL,
  `lastdate` date NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjobs`
--

INSERT INTO `subjobs` (`id`, `job_id`, `title`, `qualification`, `link`, `noofpost`, `salary`, `agelimit`, `lastdate`, `created`, `modified`) VALUES
(1, 1, 'Sub Goverment Jobs', 'BCA,MCA', 'https://www.names.org/n/sdsad/about', '5 post', '15000', '15', '2020-05-03', '2020-05-03 21:00:17', '0000-00-00 00:00:00'),
(2, 1, 'Sub Goverment Jobs', 'Central Government Jobs are the most trending and high paid jobs in India. 			', 'https://www.recruitment.guru/central-government-jobs/', '5 post', '15000 - 20000 ', '5-7', '2020-05-07', '2020-05-06 06:17:33', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
CREATE TABLE IF NOT EXISTS `tbluser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(512) NOT NULL,
  `image` text NOT NULL,
  `type` varchar(51) NOT NULL,
  `email` varchar(512) NOT NULL,
  `password` varchar(512) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`id`, `username`, `image`, `type`, `email`, `password`, `created`, `modified`) VALUES
(1, 'Test', '', 'admin', 'test@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2020-05-09 10:37:29', '2020-05-09 10:40:56');

-- --------------------------------------------------------

--
-- Table structure for table `transcation`
--

DROP TABLE IF EXISTS `transcation`;
CREATE TABLE IF NOT EXISTS `transcation` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `user_id` int(100) NOT NULL,
  `coin` int(100) NOT NULL,
  `tran_date` datetime NOT NULL DEFAULT current_timestamp(),
  `description` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transcation`
--

INSERT INTO `transcation` (`id`, `user_id`, `coin`, `tran_date`, `description`) VALUES
(1, 7, 6, '2020-05-07 18:08:21', 'App Install'),
(2, 7, 6, '2020-05-07 18:09:15', 'App Install'),
(3, 7, 6, '2020-05-08 05:49:27', 'App Install'),
(4, 10, 100, '2020-05-08 06:49:49', 'App Install'),
(5, 11, 100, '2020-05-08 07:38:33', 'App Install'),
(6, 7, 6, '2020-05-09 03:33:58', 'App Install'),
(7, 8, 100, '2020-05-10 05:43:28', 'App Install'),
(8, 18, 100, '2020-05-10 06:59:55', 'App Install'),
(9, 10, 100, '2020-05-10 07:09:04', 'App Install'),
(10, 11, 100, '2020-05-10 07:09:15', 'App Install'),
(11, 7, 150, '2020-05-12 13:55:03', 'Daily Coin'),
(12, 7, 150, '2020-05-12 15:40:39', 'Daily Coin'),
(13, 7, 150, '2020-05-12 15:40:53', 'Daily Coin'),
(14, 7, 150, '2020-05-12 15:40:56', 'Daily Coin'),
(15, 7, 150, '2020-05-12 18:59:57', 'Daily Coin'),
(16, 8, 50, '2020-05-12 19:03:24', 'Daily Coin'),
(17, 7, 4, '2020-05-12 19:27:00', 'Daily Coin'),
(18, 10, 15, '2020-05-12 19:44:20', 'Daily Coin'),
(19, 11, 6, '2020-05-12 20:08:13', 'Daily Coin'),
(20, 8, 1, '2020-05-12 21:01:27', 'Daily Coin'),
(21, 8, 18, '2020-05-13 07:05:25', 'Daily Coin'),
(22, 8, 3, '2020-05-13 08:11:36', 'Daily Coin'),
(23, 11, 2, '2020-05-13 19:18:26', 'Daily Coin'),
(24, 8, 12, '2020-05-14 06:32:55', 'Daily Coin'),
(25, 8, 17, '2020-05-14 17:55:32', 'Daily Coin'),
(26, 8, 7, '2020-05-14 18:12:29', 'Daily Coin'),
(27, 11, 13, '2020-05-14 18:21:15', 'Daily Coin'),
(28, 10, 2, '2020-05-14 18:22:39', 'Daily Coin'),
(29, 12, 15, '2020-05-14 18:30:17', 'Daily Coin'),
(30, 24, 18, '2020-05-14 20:49:32', 'Daily Coin'),
(31, 8, 13, '2020-05-15 06:58:38', 'Daily Coin'),
(32, 8, 9, '2020-05-15 07:56:10', 'Daily Coin'),
(33, 11, 9, '2020-05-15 08:48:22', 'Daily Coin'),
(34, 10, 12, '2020-05-15 19:38:55', 'Daily Coin'),
(35, 12, 17, '2020-05-15 19:53:13', 'Daily Coin'),
(36, 25, 20, '2020-05-15 19:56:59', 'Daily Coin'),
(37, 9, 13, '2020-05-16 19:15:24', 'Daily Coin'),
(38, 8, 1, '2020-05-16 21:13:48', 'Daily Coin'),
(39, 30, 10, '2020-05-16 21:30:19', 'Daily Coin'),
(40, 31, 14, '2020-05-16 21:32:43', 'Daily Coin'),
(41, 29, 8, '2020-05-17 09:30:30', 'Daily Coin'),
(42, 8, 18, '2020-05-17 17:11:25', 'Daily Coin'),
(43, 9, 16, '2020-05-17 23:16:53', 'Daily Coin'),
(44, 11, 12, '2020-05-18 07:48:23', 'Daily Coin'),
(45, 8, 1, '2020-05-18 09:14:17', 'Daily Coin'),
(46, 36, 30, '2020-05-18 02:16:49', 'Referral'),
(47, 8, 30, '2020-05-18 02:16:49', 'Referral'),
(48, 37, 30, '2020-05-18 02:18:14', 'Referral'),
(49, 8, 30, '2020-05-18 02:18:14', 'Referral'),
(50, 38, 30, '2020-05-18 02:19:56', 'Referral'),
(51, 8, 30, '2020-05-18 02:19:56', 'Referral'),
(52, 39, 30, '2020-05-18 02:20:49', 'Referral'),
(53, 8, 30, '2020-05-18 02:20:49', 'Referral'),
(54, 40, 30, '2020-05-18 02:22:44', 'Referral'),
(55, 8, 30, '2020-05-18 02:22:44', 'Referral'),
(56, 41, 30, '2020-05-18 02:24:49', 'Referral'),
(57, 8, 30, '2020-05-18 02:24:49', 'Referral'),
(58, 42, 30, '2020-05-18 02:26:38', 'Referral'),
(59, 8, 30, '2020-05-18 02:26:38', 'Referral'),
(60, 43, 30, '2020-05-18 02:27:18', 'Referral'),
(61, 8, 30, '2020-05-18 02:27:18', 'Referral'),
(62, 44, 30, '2020-05-18 02:28:31', 'Referral'),
(63, 8, 30, '2020-05-18 02:28:31', 'Referral'),
(64, 45, 30, '2020-05-18 02:30:34', 'Referral'),
(65, 8, 30, '2020-05-18 02:30:34', 'Referral'),
(66, 46, 30, '2020-05-18 02:31:10', 'Referral'),
(67, 8, 30, '2020-05-18 02:31:10', 'Referral'),
(68, 47, 30, '2020-05-18 02:32:10', 'Referral'),
(69, 8, 30, '2020-05-18 02:32:10', 'Referral'),
(70, 48, 30, '2020-05-18 02:32:38', 'Referral'),
(71, 8, 30, '2020-05-18 02:32:38', 'Referral'),
(72, 52, 50, '2020-05-18 02:39:50', 'Referral'),
(73, 8, 50, '2020-05-18 02:39:50', 'Referral'),
(74, 9, 14, '2020-05-18 15:35:02', 'Daily Coin'),
(75, 8, 10, '2020-05-19 09:14:09', 'Daily Coin'),
(76, 9, 6, '2020-05-19 10:55:17', 'Daily Coin'),
(77, 31, 5, '2020-05-19 12:38:34', 'Daily Coin'),
(78, 10, 200, '2020-05-19 01:38:20', 'App Install'),
(79, 88, 6, '2020-05-22 21:51:25', 'Daily Coin'),
(80, 90, 2, '2020-05-26 12:33:57', 'Daily Coin'),
(81, 53, 50, '2020-05-26 02:43:12', 'App Install'),
(82, 92, 10, '2020-05-27 07:35:34', 'Daily Coin'),
(83, 93, 30, '2020-06-03 11:31:46', 'Daily Coin'),
(84, 93, 30, '2020-06-03 11:31:53', 'Daily Coin'),
(85, 93, 16, '2020-06-03 11:31:56', 'Daily Coin'),
(86, 93, 26, '2020-06-03 11:31:57', 'Daily Coin'),
(87, 93, 29, '2020-06-03 11:31:58', 'Daily Coin');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `profile` text DEFAULT NULL,
  `fbid` varchar(200) DEFAULT NULL,
  `gbid` varchar(100) DEFAULT NULL,
  `referralcode` int(20) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `status` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fname`, `lname`, `email`, `profile`, `fbid`, `gbid`, `referralcode`, `created`, `modified`, `status`) VALUES
(7, 'Manoj1', 'Manoj1', 'Manoj1@gmail.com', 'http://naukriedu.raminfohub.com/uploads/1588531551_profile.png', '', '302101', 761437, '2020-05-03 23:24:05', '2020-05-15 07:39:21', 0),
(8, 'Sagar', 'Kmphasis', 'sagar.kmphasis@gmail.com', '', '', '102286362198242797599', 682438, '2020-05-05 17:21:23', '2020-05-05 17:21:23', 0),
(9, 'manoj', 'Kargar', 'manoj.kargar005@gmail.com', '', '', '101205398020258801325', 956590, '2020-05-05 19:11:00', '2020-05-05 19:11:00', 0),
(10, 'Jiren', 'Mangukiya', 'jirenmangukiya007@gmail.com', '', '', '101631630395867860435', 310405, '2020-05-05 19:14:40', '2020-05-14 05:39:33', 0),
(11, 'R', 'Com', 'rcomapp@gmail.com', '', '', '106712412197524968288', 497749, '2020-05-05 20:11:13', '2020-05-05 20:11:13', 0),
(12, 'Daily', 'Income', 'phonepocket1234@gmail.com', '', '', '109559431501988877296', 218310, '2020-05-05 21:16:34', '2020-05-05 21:16:34', 0),
(13, 'Leslie', 'Nichols', 'leslienichols.55802@gmail.com', '', '', '111430903770809154650', 346844, '2020-05-05 23:12:48', '2020-05-05 23:12:48', 0),
(14, 'onehournews', '', 'malhotraavi604@gmail.com', '', '', '117499821276321049534', 639765, '2020-05-05 23:34:35', '2020-05-05 23:34:35', 0),
(15, 'Kinjal', 'Sardhara', 'kinjalsardhara97@gmail.com', '', '', '101926345280140130974', 389015, '2020-05-08 19:05:02', '2020-05-08 19:05:02', 0),
(16, 'Filiberto', 'Amos', 'filibertoamos.94937@gmail.com', '', '', '102975598659863159605', 427538, '2020-05-08 19:05:02', '2020-05-08 19:05:02', 0),
(17, 'komal', 'kajavadara', 'komalkajavadara184@gmail.com', '', '', '108995179671044162529', 843485, '2020-05-08 19:11:06', '2020-05-08 19:11:06', 0),
(18, 'Manoj', 'Kargar', 'manoj.kargar007@gmail.com', '', '', '103455492463222991986', 387136, '2020-05-10 19:29:18', '2020-05-10 19:29:18', 0),
(19, 'Sagar', 'Vekariya', 'sagarvekariya005@gmail.com', '', '2850733468368634', '', 633379, '2020-05-11 20:58:44', '2020-05-11 20:58:44', 0),
(20, 'Betsy', 'Hicks', 'betsyhicks.12952@gmail.com', '', '', '102474127359682206300', 477073, '2020-05-11 22:15:36', '2020-05-11 22:15:36', 0),
(21, 'Deanna', 'Buchanan', 'deannabuchanan.46710@gmail.com', '', '', '106947822477247769291', 858684, '2020-05-11 23:29:31', '2020-05-11 23:29:31', 0),
(22, 'Angel', 'Moreno', 'angelmoreno.83765@gmail.com', '', '', '109089242415425566392', 302517, '2020-05-12 00:18:51', '2020-05-12 00:18:51', 0),
(23, 'Kaushik', 'Patel', '', '', '682010099315301', '', 559331, '2020-05-12 21:04:27', '2020-05-12 21:04:27', 0),
(24, 'Nitul', 'Kmphasis', 'nitul.kmphasis@gmail.com', '', '', '104692538095836255628', 109790, '2020-05-14 20:49:17', '2020-05-14 20:49:17', 0),
(25, 'Brandon', 'Stone', 'brandonstone.73941@gmail.com', '', '', '106344363305721482296', 348238, '2020-05-15 19:55:15', '2020-05-15 19:55:15', 0),
(26, 'Manoj111', 'Manoj11', 'Manoj1111@gmail.com', 'http://naukriedu.raminfohub.com/uploads/1588600178_invite.png', '', '302101111', 163005, '2020-05-15 20:11:13', '2020-05-15 20:11:13', 0),
(27, 'Vicky', 'Kmphasis', 'vicky.kmphasis@gmail.com', 'https://lh3.googleusercontent.com/a-/AOh14GjRG0ghCVSFWCwLdegUs3bW7fdW8Kb5JsJeCIejMw=s96-c', '', '100139192796981006118', 368346, '2020-05-15 20:17:20', '2020-05-15 20:17:20', 0),
(28, 'Stacey', 'Brock', 'staceybrock.26488@gmail.com', 'https://lh3.googleusercontent.com/-RPr76J4MRCk/AAAAAAAAAAI/AAAAAAAAAAA/AMZuuck-Xn45BbbiDYyqXOH2TdHIvRnKMQ/s96-c/photo.jpg', '', '113376474952807952992', 795339, '2020-05-16 00:26:02', '2020-05-16 00:26:02', 0),
(29, 'NikoloGy', 'Motivation', 'banglaschooljone@gmail.com', 'https://lh3.googleusercontent.com/a-/AOh14GhMFqPRludjcVVb8XKjiX9FVGj75YRRaq3hlnCjRw=s96-c', '', '104909801666167787582', 764149, '2020-05-16 21:20:24', '2020-05-16 21:20:24', 0),
(30, 'UPDESH', 'TV', 'malhotraupadesh@gmail.com', 'https://lh3.googleusercontent.com/a-/AOh14GjKQEkQs1PeQdjqNKihGbpuNOyZOHoMGnrx5Ifk=s96-c', '', '107680719801350357410', 621686, '2020-05-16 21:29:48', '2020-05-16 21:29:48', 0),
(31, 'Harish', 'Kumar', 'honeykamboj95@gmail.com', 'https://lh6.googleusercontent.com/--HlO43mlzPI/AAAAAAAAAAI/AAAAAAAAAAA/AMZuuck32a9mbw-gtg8Nkm9zOKfRzHXXCA/s96-c/photo.jpg', '2920744018042971', '109146901786984289583', 641392, '2020-05-16 21:31:46', '2020-05-16 21:31:46', 0),
(92, 'Cersei', 'Baratheon', 'whitelisted071@gmail.com', 'https://lh3.googleusercontent.com/-1bV0VtN24I8/AAAAAAAAAAI/AAAAAAAAAAA/AMZuuckmfg9IWbh2sl13TLBjDj-USdi_-A/s96-c/photo.jpg', '', '114759804127734740451', 475943, '2020-05-27 07:29:56', '2020-05-27 07:29:56', 0),
(91, 'Buyitdeals', 'Data', 'buyitdealsdata@gmail.com', 'https://lh3.googleusercontent.com/-_b2tpJRbaKE/AAAAAAAAAAI/AAAAAAAAAAA/AMZuucneZReuyvB6CJF8QNWlpFOyUikMJA/s96-c/photo.jpg', '', '117829127849825276935', 587084, '2020-05-26 18:01:35', '2020-05-26 18:01:35', 0),
(90, 'Harish', 'Kumar', 'admin@syncro.in', 'https://lh3.googleusercontent.com/a-/AOh14Gh3NlkbbVKEz3Ngq8TsJJlNkuH2JSSTvNyebm50=s96-c', '', '111933932951871209609', 575666, '2020-05-26 12:33:54', '2020-05-26 12:33:54', 0),
(89, 'PANKAJ', 'PRAMANIK', '1998pankajpramanik@gmail.com', 'https://lh4.googleusercontent.com/-UhBPZfdZ7ms/AAAAAAAAAAI/AAAAAAAAAAA/AMZuucnf4viBijSlZer9VoY0BYxSyMktvQ/s96-c/photo.jpg', '', '111480690969032433768', 840768, '2020-05-26 12:32:23', '2020-05-26 12:32:23', 0),
(88, 'Karan', 'Vakharia', 'karanvakharia004@gmail.com', 'https://lh6.googleusercontent.com/-Toi4qMrH7Tc/AAAAAAAAAAI/AAAAAAAAAAA/AMZuuck32SVnUUZooP8ZphKZ-j87oJGp7g/s96-c/photo.jpg', '', '117421515869279737785', 132666, '2020-05-22 21:51:13', '2020-05-22 21:51:13', 0),
(53, 'Phone', 'pocket-', 'pratapmandal700@gmail.com', 'https://lh3.googleusercontent.com/a-/AOh14GgPf61llpf7PAp9FMMblW68K5j8hr6g6ASsXf-oRA=s96-c', '', '106490159410376251926', 942701, '2020-05-18 18:16:47', '2020-05-18 18:16:47', 0),
(93, 'Manoj', 'Manoj21', 'Manoj@gmail.com', NULL, NULL, '151541', 482006, '2020-06-02 18:56:18', '2020-06-02 18:56:18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `userlogin`
--

DROP TABLE IF EXISTS `userlogin`;
CREATE TABLE IF NOT EXISTS `userlogin` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `user_id` int(100) NOT NULL,
  `devicetoken` varchar(100) NOT NULL,
  `playerId` varchar(512) NOT NULL,
  `authtoken` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=150 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlogin`
--

INSERT INTO `userlogin` (`id`, `user_id`, `devicetoken`, `playerId`, `authtoken`) VALUES
(102, 31, 'e354021f78e649f9', 'e23b246f-858d-4cd9-9e75-19313bc8a520', 'aea84167570f27f7abe92ac0006f90dd'),
(101, 53, '3b063b889d65ff69', '', 'a384a1efbc01be21ea6b0db84bdf5d1f'),
(105, 10, '4a71dda6a9ab3623', 'a936b9ce-7c88-4976-ab2b-82d88190ee81', 'd4249530242056d948420c5212f6f750'),
(99, 52, 'Manoj111aaaaaaaasaaaasaaaaa', 'd42e4c4d-5479-425e-8a50-cf980fc427e0', '28f4d64af3c2172728ad6e68ad88d55d'),
(98, 49, 'Manoj111aaaaaaaaaasaaaaa', '123', '7f4b18de3cfeb9b4ac78c381ee2ad278'),
(97, 48, 'Manoj111aaaaaaaaasaaaaa', 'd42e4c4d-5479-425e-8a50-cf980fc427e0', '980c9d1c2752a29a8cdc5669b9e22e6f'),
(96, 47, 'Manoj111aaaaaaaasaaaaa', '123', 'c91749e2f19cee0f3c11f4c06989f3ef'),
(95, 43, 'Manoj111aaaaaaasaaaa', '123', '4fe8ef6bc55b5e5d5287ef7450d43abb'),
(94, 43, 'Manoj111aaaaaaasaaaa', 'd42e4c4d-5479-425e-8a50-cf980fc427e0', '422e42d058a41c75062760d7d640debf'),
(93, 42, 'Manoj111aaaaaaasaa', '123', '60c1d292d9f43d7e93029a58a42cf1bf'),
(92, 42, 'Manoj111aaaaaaasaa', 'd42e4c4d-5479-425e-8a50-cf980fc427e0', '4326f9d7ea13518c025efc660cd629c7'),
(91, 40, 'Manoj111aaaasa', '123', 'f8b389f255ced0270201109950a1b035'),
(90, 39, 'Manoj111aaaas', '123', 'b0010c02635eb32881456d2a4505557d'),
(89, 39, 'Manoj111aaaas', '123', '608b78a38cd26383321b54a3b02f68db'),
(88, 38, 'Manoj111aaaa', '123', '3413ce14d52b87557e87e2c1518c2cbe'),
(87, 37, 'Manoj111aaaa', '123', '445a98d440958a251022b6d81d80dd08'),
(86, 37, 'Manoj111aaaa', '123', '21780a686b0ad3b45a6929f284dfd571'),
(85, 36, 'Manoj111aaa', '123', '3bf5659242cf77f195cb3792a1ce983d'),
(84, 36, 'Manoj111aaa', '123', '2a6b82244c72e226480452c163136992'),
(83, 34, 'Manoj111a', '123', 'e05704968a3070a2e5e3f1c2d77da9f5'),
(82, 34, 'Manoj111', '123', '0d858ba37c2b615078a3565d90947776'),
(81, 32, 'Manoj11', '682438', 'c73ff6dceadedf3652d678cd790ff167'),
(80, 9, '3090376804996733', 'd42e4c4d-5479-425e-8a50-cf980fc427e0', '68d65e024bd059199ce251ea65d13194'),
(79, 2, '4a71dda6a9ab3623', 'd42e4c4d-5479-425e-8a50-cf980fc427e0', '9fc64354454711c97058db6110b3a369'),
(77, 8, '30cc83bd8992f576', 'd42e4c4d-5479-425e-8a50-cf980fc427e0', '867b28af28629f14bcc0aa513c835fbb'),
(76, 32, 'Manoj11', '1234561', '1ab9f53c53dc087056a99065861a6f65'),
(75, 26, 'Manoj1', '123456', 'e3651a24a59395f95f7e4d71c758a4c1'),
(103, 10, '4a71dda6a9ab3623', '', '332d62c00e4e7218915d19a6f084d0ae'),
(106, 54, 'Manoj11', '1234561', 'ad991d32eb17e17007e63268f19944b6'),
(107, 54, 'Manoj11', '1234561', 'e67981d241ad5e29f4420a6f4ef2b7cb'),
(108, 54, 'Manoj11', '1234561', '10133a234bd0665fd79acb8cbbb4b61b'),
(109, 7, 'Mana', 'Mana', '62b74c5bd8bf9fec4e523c4173460160'),
(110, 7, 'Jsjs', 'Jsjs', '51c4671a7d35487e550eb071d891c949'),
(111, 7, 'Jsjshs', 'Jsjshs', '9b29c0062d5433a8b2a44fea100f3bd2'),
(112, 7, 'Fff', 'Fff', '15ea43997c9e00317564201ca5267210'),
(113, 7, 'Sjjss', 'Sjjss', 'e7538b84d1096dd867aa1ff882a11055'),
(114, 7, 'Sjs', 'Sjs', 'eb3c9620d7cd9b43d91437fc4397453e'),
(115, 7, 'Bshs', 'Bshs', '5993d62a909320b8c3d62ef50e61b25a'),
(116, 7, 'Urux', 'Urux', '9abd91bcb880ca339be74e57b41db7dd'),
(117, 7, 'Mznxh', 'Mznxh', '850618e22f83f152773d2a3e51168812'),
(118, 7, 'Mano', 'Mano', '14e613272979fa4a99e01542f8c981aa'),
(119, 7, 'Manoj', 'Manoj', 'deceadecf04167f28d3e92a743dca071'),
(120, 7, 'Mansn', 'Mansn', '8f1132db5edd938b22f6167b7f67d82b'),
(121, 7, 'Nsne', 'Nsne', '263f7dadfda23b095c9bb6db65db610a'),
(122, 7, 'Tgg', 'Tgg', '8e7a464b2e4d30b46cfde133272a16af'),
(123, 7, 'Tgggg', 'Tgggg', '61b1fb3f59e28c67f3925f3c79be81a1'),
(124, 7, 'Nsns', 'Nsns', 'e9437348054c27c0951c7d9d59bac04f'),
(125, 7, 'Amsmsks', 'Amsmsks', '13f82e34e49d957bf47270f8556b0d97'),
(126, 7, 'Hehd', 'Hehd', 'e47f5cfc9ff8723d4832a68a623585a1'),
(127, 7, 'Hsjs', 'Hsjs', 'df87903b9fc64ef820868aba497c804a'),
(128, 7, 'Cgg', 'Cgg', 'fa7518562603d5c4a7ad69e2e5726f5f'),
(129, 7, 'Nansns', 'Nansns', '809a92d947f7d47607c0e69329c13025'),
(130, 7, 'Msmmsnd', 'Msmmsnd', '1f358252feff8d3169d6cae466a8c819'),
(131, 7, 'Snnsnd', 'Snnsnd', '19e4eb080cdbf8da0c1f52351e3bfc61'),
(132, 7, 'Jijjj', 'Jijjj', '06928b9f63ebf064f0e8174d86a80dd2'),
(133, 7, 'Tatat', 'Tatat', '4d362d4b9ed9416a8b02b790dea8a0f9'),
(134, 7, 'Rdd', 'Rdd', 'ae42100894109a63e44a3e4420d19793'),
(135, 7, 'Cc', 'Cc', 'be0f7bc1d8fda065e5f8b576af2fcdbc'),
(136, 7, 'Ffgt', 'Ffgt', '230cd70c2b0572cf45c2c0ea927f1187'),
(137, 7, 'Ddd', 'Ddd', '50fa4f1afaa1ca5a224686c5da2d231d'),
(138, 7, 'Ccg', 'Ccg', 'd73421d9fcf0ac43f1aebb2bb6ab3909'),
(139, 7, 'Gfgg', 'Gfgg', '807146b6e182180f66c8f118b3b7cc4a'),
(140, 7, 'Dffg', 'Dffg', '13019fc8997b04326425e0c525115724'),
(141, 7, 'Dff', 'Dff', '195d01f104437ebe2661a317ca2e231c'),
(142, 88, 'a9b8397e235ed9ac', '', '151eece7fb451c947b351ae861e8cd9f'),
(143, 10, '4a71dda6a9ab3623', '85b239a0-6294-4856-a36b-ea8c20257b7b', 'f542eae1949358e25d8bfeefe5b199f1'),
(144, 89, 'b9f434f59d71c01e', '199a031c-0c5a-4d9d-a7f9-aaaf0df6ed1e', 'b05596af74c76d3e1d54e797a8a2e688'),
(145, 90, '162b07f8910d1b5b', '', '8a8f71838a01a98435790e19f9da1513'),
(146, 53, '56fd1cfd6266ec09', '', '47e93d4cf6b266b2cffa6eb70d9ab969'),
(147, 91, '8b58c3d920447e7e', '', 'eacfdaeb30d44a59b6095199053f29f8'),
(148, 92, 'f918abc553c6e57', '', 'a6b032cc13e531b6fc9824b18154da41'),
(149, 93, 'Manoj21', '1234561', 'cc8e05b9bde0f802f8af10273bb89d5c');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
