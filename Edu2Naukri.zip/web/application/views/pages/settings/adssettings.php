<div class="main-content" style="min-height: 262px;">
        <section class="section">
          <div class="section-header">
            <h1>Ads Settings</h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="/">Dashboard</a></div>
              <div class="breadcrumb-item">Ads Settings</div>
            </div>
          </div>

          <div class="section-body">
            <div id="output-status"></div>
            <div class="row">
              <div class="col-md-4">
                <div class="card">
                  <div class="card-header">
                  </div>
					<div class="card-body">
                     <ul class="nav nav-pills flex-column">
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/appsetting" class="nav-link">App Settings</a></li>
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/adssetting" class="nav-link active">Ads Settings</a></li>
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/aboutus" class="nav-link">About us</a></li>
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/version" class="nav-link">Version</a></li>
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/invite" class="nav-link">Invite</a></li>

					 </ul>
                  </div>
                </div>
              </div>
              <div class="col-md-8">
                <div class="card" id="settings-card">
                  <div class="card-header">
                    <h4>Ads Settings</h4>
                  </div>
                  <form action="<?php echo site_url('settings/editadssettings/').$fetchsetting['id']; ?>" method="POST" id="spece_data" >
				  	<?php 
					$success=$this->session->flashdata('success');
					$error=$this->session->flashdata('error');	
					if(!empty($success)) { ?>
						<div class="alert alert-success">
						  <strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?>
						</div>
					<?php } ?>
					<?php if(!empty($error)) { ?>
						<div class="alert alert-warning">
						  <strong>Fail!</strong> <?php echo $this->session->flashdata('error');?>
						</div>

					<?php } ?> 
                  <div class="card-body">
                    <div class="form-group row align-items-center">
                      <label for="FB_Native" class="form-control-label col-sm-3 text-md-right">FB Native</label>
                      <div class="col-sm-6 col-md-9">
                        <input type="text" name="fbnative" placeholder="FB Native" class="form-control" id="FB_Native" value="<?php if(!empty($fetchsetting['fbnative'])) { echo $fetchsetting['fbnative'];} else { } ?>">
                      </div>
                    </div>
					<div class="form-group row align-items-center">
                      <label for="FB_Banner" class="form-control-label col-sm-3 text-md-right">FB Banner</label>
                      <div class="col-sm-6 col-md-9">
                        <input type="text" name="fbbanner" placeholder="FB Banner" class="form-control" id="FB_Banner" value="<?php if(!empty($fetchsetting['fbbanner'])) { echo $fetchsetting['fbbanner'];} else { } ?>">
                      </div>
                    </div>
					<div class="form-group row align-items-center">
                      <label for="FB_Native_Banner" class="form-control-label col-sm-3 text-md-right">FB Native Banner</label>
                      <div class="col-sm-6 col-md-9">
                        <input type="text" name="fbnativebanner" placeholder="FB Native Banner" class="form-control" id="FB_Native_Banner" value="<?php if(!empty($fetchsetting['fbnativebanner'])) { echo $fetchsetting['fbnativebanner'];} else { } ?>">
                      </div>
                    </div>
					<div class="form-group row align-items-center">
                      <label for="FB_Interstitial" class="form-control-label col-sm-3 text-md-right">FB Interstitial</label>
                      <div class="col-sm-6 col-md-9">
                        <input type="text" name="fbinterstitial" placeholder="FB Interstitial" class="form-control" id="FB_Interstitial" value="<?php if(!empty($fetchsetting['fbinterstitial'])) { echo $fetchsetting['fbinterstitial'];} else { } ?>">
                      </div>
                    </div>
					<div class="form-group row align-items-center">
                      <label for="FB_Rewarded" class="form-control-label col-sm-3 text-md-right">FB Rewarded</label>
                      <div class="col-sm-6 col-md-9">
                        <input type="text" name="fbrewarded" placeholder="FB Rewarded" class="form-control" id="FB_Rewarded" value="<?php if(!empty($fetchsetting['fbrewarded'])) { echo $fetchsetting['fbrewarded'];} else { } ?>">
                      </div>
                    </div>
                  </div>
                  <div class="card-footer bg-whitesmoke text-md-right">
                    <button class="btn btn-primary" type="submit" id="save-btn">Save Changes</button>
                  </div>
				  </form>
                </div>
              </div>
            </div>
  		    </div>
      	</section>
      </div>