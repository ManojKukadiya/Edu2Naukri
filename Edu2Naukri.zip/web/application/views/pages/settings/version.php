<div class="main-content" style="min-height: 562px;">
        <section class="section">
          <div class="section-header">
            <h1>Version Settings</h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="/">Dashboard</a></div>
              <div class="breadcrumb-item">Version Settings</div>
            </div>
          </div>

          <div class="section-body">
            <div id="output-status"></div>
            <div class="row">
              <div class="col-md-4">
                <div class="card">
                  <div class="card-header">
                    <h4>Jump To</h4>
                  </div>
                  
                  				<div class="card-body">
                  <ul class="nav nav-pills flex-column">
                	  <!-- li class="nav-item"><a href="<?php echo base_url();?>settings" class="nav-link ">Reedem</a></li -->
					   <li class="nav-item"><a href="<?php echo base_url();?>settings/appsetting" class="nav-link">App Settings</a></li>
					   <li class="nav-item"><a href="<?php echo base_url();?>settings/adssetting" class="nav-link">Ads Settings</a></li>
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/aboutus" class="nav-link">About us</a></li>
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/version" class="nav-link active">Version</a></li>
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/invite" class="nav-link">Invite</a></li>
					 
					 </ul>
                  </div>

                </div>
              </div>
              <div class="col-md-8">
                  <div class="card" id="settings-card">
                    <div class="card-header">
                      <h4>Version Settings</h4>
                    </div>
					 <form action="<?php echo site_url('settings/editversion/').$versionlist['id']; ?>" method="POST" id="spece_data" >
				  	<?php 
					$success=$this->session->flashdata('success');
					$error=$this->session->flashdata('error');	
					if(!empty($success)) { ?>
						<div class="alert alert-success">
						  <strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?>
						</div>
					<?php } ?>
					<?php if(!empty($error)) { ?>
						<div class="alert alert-warning">
						  <strong>Fail!</strong> <?php echo $this->session->flashdata('error');?>
						</div>

					<?php } ?> 
                      <div class="card-body">
                      <div class="form-group row align-items-center">
                        <label for="version" class="form-control-label col-sm-3 text-md-right">Version</label>
                        <div class="col-sm-6 col-md-9">
                          <input type="number" name="version" placeholder="version" class="form-control" id="version" value="<?php if(!empty($versionlist['version'])) { echo $versionlist['version'];} else { } ?>">
                        </div>
                      </div>
                      <div class="form-group row align-items-center">
                        <label for="site-description" class="form-control-label col-sm-3 text-md-right">Minimum Version</label>
                        <div class="col-sm-6 col-md-9">
                          <input type="number" class="form-control" placeholder="MinimumVersion" name="min_version" id="min_version" value="<?php if(!empty($versionlist['minversion'])) { echo $versionlist['minversion'];} else { } ?>">
                        </div>
                      </div>
                      <div class="form-group row align-items-center">
                        <label class="form-control-label col-sm-3 text-md-right">Update Link</label>
                        <div class="col-sm-6 col-md-9">
                          <input class="form-control" name="Update Link" placeholder="Update Link" id="update_link" value="<?php if(!empty($versionlist['updatelink'])) { echo $versionlist['updatelink'];} else { } ?>">
                        </div>
                      </div>
                    </div>
                    <div class="card-footer bg-whitesmoke text-md-right">
                      <button class="btn btn-primary"  type="submit" id="save-btn">Save Changes</button>
                    </div>
					</form>
                  </div>
              </div>
            </div>
  		    </div>
      	</section>
      </div>