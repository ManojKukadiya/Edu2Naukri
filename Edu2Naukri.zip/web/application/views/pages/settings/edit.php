<div class="main-content" style="min-height: 530px;">
   <section class="section">
    <div class="section-header">
      <h1>Edit Main Jobs</h1>
      <div class="section-header-breadcrumb">
        <div class="breadcrumb-item active"><a href="/">Dashboard</a></div>
        <div class="breadcrumb-item active"><a href="/offers">Jobs</a></div>
        <div class="breadcrumb-item">Edit Main Jobs</div>
      </div>
    </div>
      <div class="section-body">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h4>Edit Main Jobs</h4>
              </div>
              <div class="card-body">
			  	<?php 
				$success=$this->session->flashdata('success');
				$error=$this->session->flashdata('error');	
				if(!empty($success)) { ?>
					<div class="alert alert-success">
					  <strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?>
					</div>
				<?php } ?>
				<?php if(!empty($error)) { ?>
					<div class="alert alert-warning">
					  <strong>Fail!</strong> <?php echo $this->session->flashdata('error');?>
					</div>

				<?php } ?> 
                <form action="<?php echo site_url('jobs/editjob/').$id; ?>" method="POST" id="spece_data" >
                  <div class="col-12">
                    <div class="form-group row align-items-center">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Title</label>
                      <div class="col-sm-12 col-md-7">
                        <input name="title" type="text" class="form-control" placeholder="Title" value="<?php if(!empty($fetchJobById['title'])) { echo $fetchJobById['title'];} else { } ?>">
                      </div>
                    </div>

					<div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Category</label>
                      <div class="col-sm-12 col-md-7">
                        <select  class="form-control selectric" name="category">
						<?php if(!empty($category)) { 
								foreach($category as $categoryname) { ?>
									<option value="<?php echo $categoryname['id']; ?>" <?php if($fetchJobById['category']==$categoryname['id']) echo 'selected="selected"'; ?>><?php echo $categoryname['name']; ?></option>
							<?php } 
						} else { ?>
							<option value="#" select disable>Empty Category List</option>
						
						<?php } ?>
                        </select>
                      </div>
                    </div>

					<div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">State</label>
                      <div class="col-sm-12 col-md-7">
                        <select  class="form-control selectric" name="state">
						<?php if(!empty($state)) { 
								foreach($state as $statename) { ?>
									<option value="<?php echo $statename['id']; ?>" <?php if($fetchJobById['state']==$statename['id']) echo 'selected="selected"'; ?>><?php echo $statename['name']; ?></option>
							<?php } 
						} else { ?>
							<option value="#" select disable>Empty State List</option>
						
						<?php } ?>
                        </select>
                      </div>
                    </div>

					<div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Job Qualification</label>
                      <div class="col-sm-12 col-md-7">
                        <select  class="form-control selectric" name="jobqulification">
						<?php if(!empty($qualification)) { 
								foreach($qualification as $qualificationname) { ?>
									<option value="<?php echo $qualificationname['id']; ?>" <?php if($fetchJobById['jobqulification']==$qualificationname['id']) echo 'selected="selected"'; ?>><?php echo $qualificationname['name']; ?></option>
							<?php } 
						} else { ?>
							<option value="#" select disable>Empty Job Qualification List</option>
						
						<?php } ?>
                        </select>
                      </div>
                    </div>
					
					<div class="form-group row align-items-center">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Last Date</label>
                      <div class="col-sm-12 col-md-7">
                        <input name="lastdate" type="date" class="form-control" value="<?php if(!empty($fetchJobById['lastdate'])) { echo $fetchJobById['lastdate'];} else { } ?>">
                      </div>
                    </div>
					
				  </div>
                  <div class="form-group row mb-4">
                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                    <div class="col-sm-12 col-md-7">
                      <button class="ml-2 btn btn-primary" type="submit"  id="addOffer">Submit</button>
                    </div>
                  </div>
                </form>

              </div>
            </div>
        </div>
      </div>
    </div>
 </section>
</div>