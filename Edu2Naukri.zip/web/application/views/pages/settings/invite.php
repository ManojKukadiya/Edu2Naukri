<div class="main-content" style="min-height: 198px;">
        <section class="section">
          <div class="section-header">
            <h1>Invite Settings</h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="/">Dashboard</a></div>
              <div class="breadcrumb-item">Invite Settings</div>
            </div>
          </div>

          <div class="section-body">
            <div id="output-status"></div>
            <div class="row">
              <div class="col-md-4">
                <div class="card">
                  <div class="card-header">
                    <h4>Jump To</h4>
                  </div>
                  	<div class="card-body">
					<ul class="nav nav-pills flex-column">
                	  <!-- li class="nav-item"><a href="<?php echo base_url();?>settings" class="nav-link ">Reedem</a></li -->
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/appsetting" class="nav-link">App Settings</a></li>
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/adssetting" class="nav-link">Ads Settings</a></li>
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/aboutus" class="nav-link">About us</a></li>
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/version" class="nav-link">Version</a></li>
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/invite" class="nav-link active">Invite</a></li>
					</ul>
                  </div>                </div>
              </div>
              <div class="col-md-8">
                  <div class="card" id="settings-card">
                    <div class="card-header">
                      <h4>Invite Settings</h4>
                    </div>
                    <form action="<?php echo site_url('settings/editinvite/').$fetchinvite['id']; ?>" method="POST" id="spece_data" enctype="multipart/form-data">
				  	<?php 
					$success=$this->session->flashdata('success');
					$error=$this->session->flashdata('error');	
					if(!empty($success)) { ?>
						<div class="alert alert-success">
						  <strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?>
						</div>
					<?php } ?>
					<?php if(!empty($error)) { ?>
						<div class="alert alert-warning">
						  <strong>Fail!</strong> <?php echo $this->session->flashdata('error');?>
						</div>

					<?php } ?> 
                    <div class="card-body">
                      <div class="form-group row align-items-center">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Invite Image</label>
                        <div class="col-lg-4 col-md-6">
                          <div id="selector" class="text-center form-group dropimage h-100">
                            <img class="w-100 my-auto" id="preview" src="<?php echo base_url().$fetchinvite['image']; ?>" alt="Invite Image">
                            <div class="pt-4" id="imgTxt" style="display: none;">
                              <i class="fas fa-plus fa-4x mt-4" id="fasimg"></i>
                              <p class="text-dark">Click here to add Tag Icon</p>
                            </div>
                          </div>
                            <input height="0" type="file" id="image_file" name="invite_image"   hidden="">
                            <input type="hidden" id="invite_image"  value="<?php if(!empty($fetchinvite['image'])) { echo $fetchinvite['image'];} else { } ?>">
                        </div>
                      </div>
					  <div class="form-group row align-items-center">
						  <label for="invite_coin" class="form-control-label col-sm-3 text-md-right">Invite Coin</label>
						  <div class="col-sm-6 col-md-9">
							<input type="number" name="invite_coin" placeholder="Invite Coin" class="form-control" id="invite_coin" value="<?php if(!empty($fetchinvite['invitecoin'])) { echo $fetchinvite['invitecoin'];} else { } ?>">
						  </div>
						</div>
                      <div class="form-group row align-items-center">
                        <label class="form-control-label col-sm-3 text-md-right">Invite Message</label>
                        <div class="col-sm-6 col-md-9">
                          <textarea class="form-control" name="site_description" placeholder="Invite Text" id="invite_msg" rows="1"><?php if(!empty($fetchinvite['message'])) { echo $fetchinvite['message'];} else { } ?></textarea>
                        </div>
                      </div>

                      <div class="form-group row align-items-center">
                        <label class="form-control-label col-sm-3 text-md-right">Invite Link</label>
                        <div class="col-sm-6 col-md-9">
                          <input class="form-control" id="invite_link" name="invitelink" placeholder="Invite Message" value="<?php if(!empty($fetchinvite['link'])) { echo $fetchinvite['link'];} else { } ?>">
                        </div>
                      </div>

                      <div class="form-group row align-items-center">
                        <label class="form-control-label col-sm-3 text-md-right">Invite Term</label>
                        <div class="col-sm-6 col-md-9">
                          <textarea class="form-control" name="team" placeholder="Invite Terms" id="invite_terms" rows="1">
						  <?php if(!empty($fetchinvite['term'])) { echo $fetchinvite['term'];} else { } ?>
						  </textarea>
                        </div>
                      </div>
                    </div>
                    
                    <div class="card-footer bg-whitesmoke text-md-right">
                      <button class="btn btn-primary"  type="submit"  id="save-btn">Save Changes</button>
                    </div>
					</form>
                  </div>
              </div>
            </div>
  		    </div>
      	</section>
      </div>