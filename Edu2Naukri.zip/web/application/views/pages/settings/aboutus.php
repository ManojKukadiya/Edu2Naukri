<div class="main-content" style="min-height: 262px;">
        <section class="section">
          <div class="section-header">
            <h1>Reedem Settings</h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="/">Dashboard</a></div>
              <div class="breadcrumb-item">Reedem Settings</div>
            </div>
          </div>

          <div class="section-body">
            <div id="output-status"></div>
            <div class="row">
              <div class="col-md-4">
                <div class="card">
                  <div class="card-header">
                    <h4>Jump To</h4>
                  </div>
					<div class="card-body">
                     <ul class="nav nav-pills flex-column">
                	  <!-- li class="nav-item"><a href="<?php echo base_url();?>settings" class="nav-link">Reedem</a></li -->
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/appsetting" class="nav-link">App Settings</a></li>
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/adssetting" class="nav-link">Ads Settings</a></li>
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/aboutus" class="nav-link active">About us</a></li>
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/version" class="nav-link">Version</a></li>
					  <li class="nav-item"><a href="<?php echo base_url();?>settings/invite" class="nav-link">Invite</a></li>

					 </ul>
                  </div>
                </div>
              </div>
              <div class="col-md-8">
                <div class="card" id="settings-card">
                  <div class="card-header">
                    <h4>About Us</h4>
                  </div>
                  <form action="<?php echo site_url('settings/editaboutus/').$fetchaboutus['id']; ?>" method="POST" id="spece_data" >
				  	<?php 
				$success=$this->session->flashdata('success');
				$error=$this->session->flashdata('error');	
				if(!empty($success)) { ?>
					<div class="alert alert-success">
					  <strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?>
					</div>
				<?php } ?>
				<?php if(!empty($error)) { ?>
					<div class="alert alert-warning">
					  <strong>Fail!</strong> <?php echo $this->session->flashdata('error');?>
					</div>

				<?php } ?> 
                  <div class="card-body">
					 <div class="form-group row align-items-center">
                        <label class="form-control-label col-sm-3 text-md-right">About Us</label>
                        <div class="col-sm-6 col-md-9">
                          <textarea class="form-control" name="aboutus" placeholder="About Us" id="about us" rows="5"><?php if(!empty($fetchaboutus['aboutus'])) { echo $fetchaboutus['aboutus'];} else { } ?></textarea>
                        </div>
                     </div>
					 <div class="form-group row align-items-center">
                        <label class="form-control-label col-sm-3 text-md-right">Privacy Policy</label>
                        <div class="col-sm-6 col-md-9">
                          <textarea class="form-control" name="contactus" placeholder="Privacy Policy" id="about us" rows="5"><?php if(!empty($fetchaboutus['contactus'])) { echo $fetchaboutus['contactus'];} else { } ?></textarea>
                        </div>
                     </div>
					 <div class="form-group row align-items-center">
                        <label class="form-control-label col-sm-3 text-md-right">Team & Condition</label>
                        <div class="col-sm-6 col-md-9">
                          <textarea class="form-control" name="team" placeholder="Team & Condition" id="about us" rows="5"><?php if(!empty($fetchaboutus['team'])) { echo $fetchaboutus['team'];} else { } ?></textarea>
                        </div>
                     </div>
					</div>
                  <div class="card-footer bg-whitesmoke text-md-right">
                    <button class="btn btn-primary" type="submit" id="save-btn">Save Changes</button>
                  </div>
				  </form>
                </div>
              </div>
            </div>
  		    </div>
      	</section>
      </div>