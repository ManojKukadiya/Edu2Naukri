<div class="main-content" style="min-height: 530px;">
        <section class="section">
          <div class="section-header">
            <h1>Qualification List</h1>
            <a href="<?php echo base_url(); ?>/qualification/newqualification" class="btn btn-primary ml-4">ADD New Qualification</a>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="/">Dashboard</a></div>
              <div class="breadcrumb-item">Qualification List</div>
            </div>
          </div>
			<?php if(!empty($qualificationlist)) { ?>
          <div class="section-body">
			<div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Qualification List</h4>
                  </div>
                  <div class="card-body px-2">
				  <?php 
					$success=$this->session->flashdata('success');
					$error=$this->session->flashdata('error');
						if(!empty($success)) { ?>
						<div class="alert alert-success">
						  <strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?>
						</div>
					<?php } ?>
					<?php if(!empty($error)) { ?>
						<div class="alert alert-warning">
						  <strong>Fail!</strong> <?php echo $this->session->flashdata('error');?>
						</div>

					<?php } ?>
                    <div class="table-responsive">
                      <table class="table table-striped table-md" id="table-2">
                        <thead>
							 <tr>
							  <th>#</th>
							  <th class="text-center">Qualification</th>
							  <th class="text-center">Action</th>
							</tr>
                        </thead>
                        <tbody>
							<?php $i=1; foreach($qualificationlist as $qualification) { ?>
							<tr>
							  <td><?php echo $i ?></td>
							  <td class="text-center"><?php echo $qualification['name']; ?></td>
							  <td class="text-center">
								<div class="btn-group mb-2">
								  <button class="btn btn-primary btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								  Action
								  </button>
								  <div class="dropdown-menu">
									<a class="dropdown-item" href="<?php echo site_url('qualification/editqualification/').$qualification['id']; ?>">Edit</a>
									<a class="qualificationdelete dropdown-item"  data-title="QualificationDelete" data-toggle="modal" data-target="#qualificationdelete" data-id="<?php echo  $qualification['id']; ?>">Delete</a>
								  </div>
								</div>
							  </td>
							</tr>
							<?php $i++; } ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                 
		 </div>
       
			<?php } ?>
	   </section>
      </div>
	   <div class="modal fade" id="qualificationdelete" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
						</div>						
						<div class="modal-body">
							<div class="alert alert-danger"><span class="glyphicon glyphicon-warning-sign"></span>&nbsp;&nbsp;Are you sure you want to change job status?</div>
						</div>
						<div class="modal-footer ">
							<a id="btnqualificationlist" href="">
							<button type="button" class="btn btn-success" ><span class="glyphicon glyphicon-ok-sign"></span> Yes</button></a>
							<button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> No</button>
						</div>

				  </div>
			</div>
		</div>