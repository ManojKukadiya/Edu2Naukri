<div class="main-content" style="min-height: 530px;">
        <section class="section">
          <div class="section-header">
            <h1>Jobs</h1>
            <a href="<?php echo base_url(); ?>/jobs/newjobs" class="btn btn-primary ml-4">ADD Main Job</a>
			<a href="<?php echo base_url(); ?>/category" class="btn btn-primary ml-4">View Category</a>
			<a href="<?php echo base_url(); ?>/qualification" class="btn btn-primary ml-4">View Qualification</a>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="/">Dashboard</a></div>
              <div class="breadcrumb-item">Jobs</div>
            </div>
          </div>
			<?php if(!empty($joblist)) { ?>
          <div class="section-body">
			<div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Jobs Main</h4>
                  </div>
                  <div class="card-body px-2">
				  <?php 
					$success=$this->session->flashdata('success');
					$error=$this->session->flashdata('error');
						if(!empty($success)) { ?>
						<div class="alert alert-success">
						  <strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?>
						</div>
					<?php } ?>
					<?php if(!empty($error)) { ?>
						<div class="alert alert-warning">
						  <strong>Fail!</strong> <?php echo $this->session->flashdata('error');?>
						</div>

					<?php } ?>
                    <div class="table-responsive">
                      <table class="table table-striped table-md" id="table-2">
                        <thead>
							 <tr>
							  <th>#</th>
							  <th class="text-center">Title</th>
							  <th>Category</th>
							  <th>State</th>
							  <th>Qualification</th>
							  <th class="text-center">Last Date</th>
							  <th class="text-center">Status</th>
							  <th class="text-center">Action</th>
							</tr>
                        </thead>
                        <tbody>
							<?php $i=1; foreach($joblist as $jobs) { ?>
							<tr>
							  <td><?php echo $i ?></td>
							  <td class="text-center"><?php echo $jobs['title']; ?></td>
							  <td><?php echo $jobs['category']; ?></td>
							  <td><?php echo $jobs['state']; ?></td>
							  <td><?php echo $jobs['qualification']; ?></td>
							  <td class="text-center"><?php echo $jobs['lastdate']; ?></td>
							  <td class="text-center">
								<?php if($jobs['status']==0) {  ?>
									<div class="badge badge-success" id="uStatus_193">Active</div>
								<?php } else { ?>
									<div class="badge badge-warning" id="uStatus_193">Inactive</div>
								<?php } ?>
							  </td>
							  <td class="text-center">
								<div class="btn-group mb-2">
								  <button class="btn btn-primary btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								  Action
								  </button>
								  <div class="dropdown-menu">
									<a class="dropdown-item" href="<?php echo site_url('jobs/editjobs/').$jobs['id']; ?>">Edit</a>
									<a class="dropdown-item" href="<?php echo site_url('jobs/subjobs/').$jobs['id']; ?>">View Sub Jobs</a>
									<div class="dropdown-divider"></div>
								   <a class="jobstatuschange dropdown-item" data-title="Userstatus" data-toggle="modal" data-target="#status" data-id="<?php echo  $jobs['id']; ?>" >
									<?php if($jobs['status'] == 0) { ?>
									Inactive
									<?php } else { ?>
									Active
									<?php }  ?>
									</a>
								</div>
								</div>
							  </td>
							</tr>
							<?php $i++; } ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                 
		 </div>
       
			<?php } ?>
	   </section>
      </div>
	   <div class="modal fade" id="status" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
						</div>						
						<div class="modal-body">
							<div class="alert alert-danger"><span class="glyphicon glyphicon-warning-sign"></span>&nbsp;&nbsp;Are you sure you want to change job status?</div>
						</div>
						<div class="modal-footer ">
							<a id="btnjobstatuschange" href="">
							<button type="button" class="btn btn-success" ><span class="glyphicon glyphicon-ok-sign"></span> Yes</button></a>
							<button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> No</button>
						</div>

				  </div>
			</div>
		</div>