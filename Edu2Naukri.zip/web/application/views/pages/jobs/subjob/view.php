<div class="main-content" style="min-height: 530px;">
        <section class="section">
          <div class="section-header">
            <h1>Sub Jobs</h1>
            <a href="<?php echo base_url(); ?>/jobs" class="btn btn-primary ml-4">View Main Job</a>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="/">Dashboard</a></div>
              <div class="breadcrumb-item">Jobs</div>
            </div>
          </div>
			
          <div class="section-body">
			<div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4><?php echo $jobtitle['title']; ?></h4>
					<a href="<?php echo site_url('jobs/newsubjob/').$jobid; ?>" class="btn btn-primary ml-4">ADD Sub Job</a>
                  </div>
				  <?php if(!empty($subjoblist)) { ?>
                  <div class="card-body px-2">
				  <?php 
					$success=$this->session->flashdata('success');
					$error=$this->session->flashdata('error');
						if(!empty($success)) { ?>
						<div class="alert alert-success">
						  <strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?>
						</div>
					<?php } ?>
					<?php if(!empty($error)) { ?>
						<div class="alert alert-warning">
						  <strong>Fail!</strong> <?php echo $this->session->flashdata('error');?>
						</div>

					<?php } ?>
                    <div class="table-responsive">
                      <table class="table table-striped table-md" id="table-2">
                        <thead>
							 <tr>
							  <th>#</th>
							  <th class="text-center">Title</th>
							  <th>Qualification / Description</th>
							  <th>NoofPost</th>
							  <th>Salary</th>
							  <th>Age Limit</th>
							  <th class="text-center">Last Date</th>
							  <th class="text-center">Action</th>
							</tr>
                        </thead>
                        <tbody>
                         <?php $i=1; foreach($subjoblist as $jobs) { ?>
                        <tr>
                          <td><?php echo $i ?></td>
                          <td class="text-center"><?php echo $jobs['title']; ?></td>
                          <td><?php echo $jobs['qualification']; ?></td>
						  <td><?php echo $jobs['noofpost']; ?></td>
						  <td><?php echo $jobs['salary']; ?></td>
						  <td><?php echo $jobs['agelimit']; ?></td>
                          <td class="text-center"><?php echo $jobs['lastdate']; ?></td>
                          <td class="text-center">
                            <div class="btn-group mb-2">
                              <button class="btn btn-primary btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Action
                              </button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="<?php echo site_url('jobs/editsubjobs/').$jobs['id']; ?>">Edit</a>
                                <a class="dropdown-item" href="#">Delete</a>
                            </div>
                            </div>
                          </td>
                        </tr>
						<?php $i++; } ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                 
		 </div>
       
			<?php } ?>
	   </section>
      </div>