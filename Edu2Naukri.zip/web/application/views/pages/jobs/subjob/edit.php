<div class="main-content" style="min-height: 530px;">
   <section class="section">
    <div class="section-header">
      <h1>Edit Sub Jobs</h1>
	  <a href="<?php echo site_url('jobs/subjobs/').$subjob['job_id']; ?>" class="btn btn-primary ml-4">View Sub Job</a>
      <div class="section-header-breadcrumb">
        <div class="breadcrumb-item active"><a href="/">Dashboard</a></div>
        <div class="breadcrumb-item active"><a href="/offers">Jobs</a></div>
        <div class="breadcrumb-item">Edit Sub Jobs</div>
      </div>
    </div>
      <div class="section-body">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h4>Edit Sub Jobs</h4>
              </div>
              <div class="card-body">
			  	<?php 
				$success=$this->session->flashdata('success');
				$error=$this->session->flashdata('error');	
				if(!empty($success)) { ?>
					<div class="alert alert-success">
					  <strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?>
					</div>
				<?php } ?>
				<?php if(!empty($error)) { ?>
					<div class="alert alert-warning">
					  <strong>Fail!</strong> <?php echo $this->session->flashdata('error');?>
					</div>

				<?php } ?> 
                <form action="<?php echo site_url('jobs/editsubjobdata/').$subjob['id']; ?>" method="POST" id="spece_data" >
                  <div class="col-12">
                    <div class="form-group row align-items-center">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Title</label>
                      <div class="col-sm-12 col-md-7">
                        <input name="title" type="text" class="form-control" placeholder="Title" value="<?php if(!empty($subjob['title'])) { echo $subjob['title'];} else { } ?>">
                      </div>
                    </div>
					<input type="hidden" value="<?php if(!empty($subjob['job_id'])) { echo $subjob['job_id'];} else { } ?>" name="job_id" />
					<div class="form-group row align-items-center">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Qualification / Description</label>
                      <div class="col-sm-12 col-md-7">
						<textarea class="form-control" placeholder="Qualification" name="qualification" rows="4" cols="50">
						<?php if(!empty($subjob['qualification'])) { echo $subjob['qualification'];} else { } ?>
						</textarea>
                      </div>
                    </div>
					
					<div class="form-group row align-items-center">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Link</label>
                      <div class="col-sm-12 col-md-7">
                        <input name="link" type="text" class="form-control"  placeholder="Apply Link" value="<?php if(!empty($subjob['link'])) { echo $subjob['link'];} else { } ?>">
                      </div>
                    </div>
					
					<div class="form-group row align-items-center">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">No of Post</label>
                      <div class="col-sm-12 col-md-7">
                        <input name="nopost" type="text" class="form-control" placeholder="Post" value="<?php if(!empty($subjob['noofpost'])) { echo $subjob['noofpost'];} else { } ?>">
                      </div>
                    </div>
					
					 <div class="form-group row align-items-center">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Salary</label>
                      <div class="col-sm-12 col-md-7">
                        <input name="salary" type="text" class="form-control" placeholder="Salary Limit" value="<?php if(!empty($subjob['salary'])) { echo $subjob['salary'];} else { } ?>">
                      </div>
                    </div>
					
					<div class="form-group row align-items-center">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Last Date</label>
                      <div class="col-sm-12 col-md-7">
                        <input name="lastdate" type="date" class="form-control" value="<?php if(!empty($subjob['lastdate'])) { echo $subjob['lastdate'];} else { } ?>">
                      </div>
                    </div>
					
				  </div>
                  <div class="form-group row mb-4">
                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                    <div class="col-sm-12 col-md-7">
                      <button class="ml-2 btn btn-primary" type="submit"  id="addOffer">Submit</button>
                    </div>
                  </div>
                </form>

              </div>
            </div>
        </div>
      </div>
    </div>
 </section>
</div>