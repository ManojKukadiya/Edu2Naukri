<div class="main-content" style="min-height: 530px;">
        <section class="section">
          <div class="section-header">
            <h1>Edit Offer</h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="/">Dashboard</a></div>
              <div class="breadcrumb-item active"><a href="/offers">Offer</a></div>
              <div class="breadcrumb-item">Edit Offer</div>
            </div>
          </div>
          <div class="section-body">
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Edit Offer</h4>
                  </div>
                  <div class="card-body">
				    <?php 
					$success=$this->session->flashdata('success');
					$error=$this->session->flashdata('error');
						if(!empty($success)) { ?>
						<div class="alert alert-success">
						  <strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?>
						</div>
					<?php } ?>
					<?php if(!empty($error)) { ?>
						<div class="alert alert-warning">
						  <strong>Fail!</strong> <?php echo $this->session->flashdata('error');?>
						</div>

					<?php } ?> 
                    <form action="<?php echo site_url('offers/editoffer/').$id; ?>"  method="POST" id="spece_data" enctype="multipart/form-data">
                      <div class="col-12">
                        <div class="form-group row align-items-center">
                          <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Title</label>
                          <div class="col-sm-12 col-md-7">
                            <input name="title" type="text" class="form-control" placeholder="Title" value="<?php if(!empty($editdata['title'])) { echo $editdata['title'];} else { } ?>">
                          </div>
                        </div>
						<div class="form-group row align-items-center">
						  <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Short Description</label>
						  <div class="col-sm-12 col-md-7">
							<input name="shortdesc" type="text" class="form-control" placeholder="Short Description" value="<?php if(!empty($editdata['shortdesc'])) { echo $editdata['shortdesc'];} else { } ?>">
						  </div>
						</div>
                        <div class="form-group row align-items-center">
                          <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Icon</label>
                          <div class="col-sm-12 col-md-7">
                            <input name="icon" type="text" class="form-control" placeholder="Icon" value="<?php if(!empty($editdata['image'])) { echo $editdata['image'];} else { } ?>">
                          </div>
                        </div>

                        <div class="form-group row align-items-center">
                          <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Link</label>
                          <div class="col-sm-12 col-md-7">
                            <input name="link" type="text" class="form-control" placeholder="Link" value="<?php if(!empty($editdata['link'])) { echo $editdata['link'];} else { } ?>">
                          </div>
                        </div>

                        <div class="form-group row align-items-center">
                          <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Package</label>
                          <div class="col-sm-12 col-md-7">
                            <input name="package" type="text" class="form-control" placeholder="Package" value="<?php if(!empty($editdata['package'])) { echo $editdata['package'];} else { } ?>">
                          </div>
                        </div>

                        <div class="form-group row align-items-center">
                          <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Amount</label>
                          <div class="col-sm-12 col-md-7">
                            <input name="amount" type="text" class="form-control" placeholder="Amount" value="<?php if(!empty($editdata['amount'])) { echo $editdata['amount'];} else { } ?>">
                          </div>
                        </div>

                        <div class="form-group row align-items-center">
                          <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Priority</label>
                          <div class="col-sm-12 col-md-7">
                            <input name="priority" type="text" class="form-control" placeholder="Priority" value="<?php if(!empty($editdata['priority'])) { echo $editdata['priority'];} else { echo 0; } ?>">
                          </div>
                        </div>

                        <div class="form-group row align-items-center">
                          <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Video URL (Optional)</label>
                          <div class="col-sm-12 col-md-7">
                            <input name="video" type="text" class="form-control" placeholder="Video URL (Optional)" value="<?php if(!empty($editdata['videourl'])) { echo $editdata['videourl'];} else { } ?>">
                          </div>
                        </div>

                        <div class="form-group row mb-4">
                          <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Type</label>
                          <div class="col-sm-12 col-md-7">
                            <select name="type" class="form-control selectric">
								<option value="0" <?php if($editdata['offertype']==0) echo 'selected="selected"'; ?>>Super Offers</option>
                                <option value="1" <?php if($editdata['offertype']==1) echo 'selected="selected"'; ?>>Hot Offers</option>
                                                        
                            </select>
                          </div>
                        </div>
						<?php $count=1; ?>
                        <div class="form-group row mb-4">
                          <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Description</label>
                          <div class="col-sm-12 col-md-7" id="step_table">
								<?php 
								foreach($editofferdesc as $desc) { ?>
									<div class="form-group ofer29-div dynamic" id="row<?php $count; ?>">
										<div class="input-group">
											<input type="text" placeholder="Enter Step" class="form-control" name="desc[]" value="<?php echo $desc['step']; ?>">
											<?php if($count == 1) { ?>
												<select name="copy" class="form-control selectric">
													<option value="0" <?php if($editdata['descshow']==0) echo 'selected="selected"'; ?>>Do not Show Copy</option>
													<option value="1" <?php if($editdata['descshow']==1) echo 'selected="selected"'; ?>>Show Copy</option>
												</select>
											<?php } else { ?>
												<div class="input-group-append">
													<button class="btn btn-danger remove-box" type="button"><i class="fas fa-times"></i>
													</button>
												</div>
											<?php } ?>
										</div>
									</div>
								<?php $count++; } ?>
                            </div>
                        </div>
                        <div class="form-group m-auto col-2">
                          <p class="btn btn-primary adddescription" >Add More Fields</p>
                        </div>
                      </div>
                      <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                        <div class="col-sm-12 col-md-7">
                          <button class="ml-2 btn btn-primary"  type="submit"  id="edittags">Submit</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
         </div>
      </section>
    </div>