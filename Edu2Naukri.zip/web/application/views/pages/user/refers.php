<div class="main-content" style="min-height: 530px;">
        <section class="section">
          <div class="section-header">
            <h1>Refers</h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="/">Dashboard</a></div>
              <div class="breadcrumb-item">Refers</div>
            </div>
          </div>

          <div class="section-body">
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Refers</h4>
                  </div>

					<?php if(!empty($refers)) { ?>
					  <div class="card-body p-0">
						<div class="table-responsive">
						  <table class="table table-striped">
							<tbody>
							<tr>
							  <th>Sr</th>
							  <th>Name</th>
							  <th>Email</th>
							</tr>
						   <?php 
						   
						   $i=1;
						   foreach($refers as $value)
							{ ?>
								<tr>
								  <td><?php echo $i; ?></td>
								  <td><?php echo $value['fname'].' '.$value['lname']; ?></td>
								  <td><?php echo $value['email']; ?></td>
								</tr>
							<?php $i++; } ?>
							</tbody>
							</table>
						</div>
					  </div>
					<?php } else { ?>
                    <div class="card-body p-0">
						<div class="empty-state" data-height="400" style="height: 400px;">
						  <div class="empty-state-icon">
							<i class="fas fa-users"></i>
						  </div>
						  <h2>We couldn't find any Users</h2>
						  <p class="lead">
							Sorry we can't find any Users on this page, Please contact server admin.
						  </p>
						</div>
					</div>
					<?php } ?>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>