<div class="main-content" style="min-height: 333px;">
        <section class="section">
          <div class="section-header">
            <h1>History</h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="/">Dashboard</a></div>
              <div class="breadcrumb-item active"><a href="/users">Users</a></div>
              <div class="breadcrumb-item">History</div>
            </div>
          </div>
			<?php if(!empty($history)) { ?>
          <div class="section-body">
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>History</h4>
                  </div>

                     <div class="card-body p-0">
                    <div class="table-responsive">
                      <table class="table table-striped table-md" id="table-headers">
                        <tbody><tr>
                          <th>#</th>
                          <th class="text-center">Icon</th>
                          <th>Offer</th>
                          <th>Installed at</th>
                        </tr>
						<?php foreach($history as $historylist) { ?>
                        <tr>
                          <td>#<?php echo $historylist['id']; ?></td>
                          <td class="text-center">
                            <img alt="image" src="<?php echo $historylist['image'];?>" class="rounded" width="35">
                          </td>
                          <td><?php echo $historylist['title']; ?></td>
                          <td><?php echo $historylist['created']; ?></td>
                        </tr>
						<?php } ?>
						</tbody>
					</table>
                    </div>
                  </div>

                                                    </div>
              </div>
            </div>
          </div>
			<?php } ?>
        </section>
      </div>