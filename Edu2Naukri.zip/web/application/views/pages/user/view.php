<div class="main-content">
        <section class="section">
          <div class="section-header">
            <h1>Users</h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
              <div class="breadcrumb-item"><a href="#">Users</a></div>
            </div>
          </div>
        
          <div class="section-body">
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Users</h4>
                  </div>
                  <div class="card-body px-2">
                    <div class="table-responsive">
					 <?php 
						$success=$this->session->flashdata('success');
						$error=$this->session->flashdata('error');
							if(!empty($success)) { ?>
							<div class="alert alert-success">
							  <strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?>
							</div>
						<?php } ?>
						<?php if(!empty($error)) { ?>
							<div class="alert alert-warning">
							  <strong>Fail!</strong> <?php echo $this->session->flashdata('error');?>
							</div>

						<?php } ?> 
                       <table class="table table-striped table-md" id="table-2">
					   <thead>
                        <tr>
                          <th>#</th>
                          <th>Image</th>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Credits</th>
                          <th>Refers</th>
						  <th>Joining Date</th>
						  <th>Status</th>
                          <th>Action</th>
                        </tr>
						</thead>
						 <tbody>
						<?php 
							if(!empty($user)) 
							{ 
									foreach($user as $value)
									{ ?>
								<tr>
						
                          <td class="p-0 text-center"><?php echo $value['id']; ?></td>
						  <?php if(!empty($value['profile'])) { ?>
						  <td class="text-center"><img alt="image" src="<?php echo $value['profile'];?>" class="rounded-circle" width="35" data-toggle="tooltip" title="<?php echo $value['fname'].' '.$value['lname'];?>"></td>
                          <?php } else { ?> 
						  <td class="text-center"><img alt="image" src="<?php echo base_url().'uploads/user_default.png';?>" class="rounded-circle" width="35" data-toggle="tooltip" title="<?php echo $value['fname'].' '.$value['lname'];?>"></td>
						  <?php } ?>
						  <td><?php echo $value['fname'].' '.$value['lname']; ?></td>
						  <td><?php echo $value['email']; ?></td>
						  <td><?php echo $value['totalcoin']; ?></td>
						  <td><?php echo $value['treferral']; ?></td>
						  <td><?php echo $value['created']; ?></td>
						  <td class="text-center">
							<?php if($value['status'] == 0) { ?>
								<div class="badge badge-success">Active</div>
							<?php } else { ?>
								<div class="badge badge-warning">Block</div>	
							<?php }?>
						  </td>
                          <td class="text-center">
                            <div class="btn-group mb-2">
                              <button class="btn btn-primary btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Action
                              </button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="<?php echo  base_url() ?>user/profile/<?php echo $value['id']; ?>">View Profile</a>
                                <a class="dropdown-item" href="<?php echo  base_url() ?>user/history/<?php echo $value['id']; ?>">View App Downloads</a>
                                <a class="dropdown-item" href="<?php echo  base_url() ?>user/refers/<?php echo $value['id']; ?>">View Referral</a>
                                <div class="dropdown-divider"></div>
                                <a class="statuschange dropdown-item" data-title="Userstatus" data-toggle="modal" data-target="#status" data-id="<?php echo  $value['id']; ?>" >
								<?php if($value['status'] == 0) { ?>
								Block
								<?php } else { ?>
								Unblock
								<?php }  ?>
								</a>
                              </div>
                            </div>
                          </td>
						  </tr>
						<?php }
							}
						?>
							 </tbody>		
                     </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            </div>
        </section>
      </div>
	  <div class="modal fade" id="status" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
						</div>						
						<div class="modal-body">
							<div class="alert alert-danger"><span class="glyphicon glyphicon-warning-sign"></span>&nbsp;&nbsp;Are you sure you want to change user status?</div>
						</div>
						<div class="modal-footer ">
							<a id="btnstatuschange" href="">
							<button type="button" class="btn btn-success" ><span class="glyphicon glyphicon-ok-sign"></span> Yes</button></a>
							<button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> No</button>
						</div>

				  </div>
		</div>
</div>