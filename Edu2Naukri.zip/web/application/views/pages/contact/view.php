<div class="main-content">
        <section class="section">
          <div class="section-header">
            <h1>Contact Us</h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
              <div class="breadcrumb-item"><a href="#">Contact Us</a></div>
            </div>
          </div>
          <div class="section-body">
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Contact Us</h4>
                  </div>
                  <div class="card-body px-2">
                    <div class="table-responsive">
					 <?php 
						$success=$this->session->flashdata('success');
						$error=$this->session->flashdata('error');
							if(!empty($success)) { ?>
							<div class="alert alert-success">
							  <strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?>
							</div>
						<?php } ?>
						<?php if(!empty($error)) { ?>
							<div class="alert alert-warning">
							  <strong>Fail!</strong> <?php echo $this->session->flashdata('error');?>
							</div>

						<?php } ?> 
                       <table class="table table-striped table-md" id="table-2">
					   <thead>
                        <tr>
                          <th class="text-center">#</th>
                          <th>Email</th>
                          <th>Heading</th>
                          <th>Message</th>
                        </tr>
						</thead>
						 <tbody>
						<?php 
							if(!empty($contact)) 
							{ 
									foreach($contact as $value)
									{ ?>
								<tr>
								  <td class="text-center"><?php echo $value['contactid']; ?></td>
								  <td><?php echo $value['email']; ?></td>
								  <td><?php echo $value['heading']; ?></td>
								  <td><?php echo $value['message']; ?></td>
								</tr>
						<?php }
							}
						?>
							 </tbody>		
                     </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            </div>
        </section>
      </div>