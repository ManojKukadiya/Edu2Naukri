<div class="main-content">
        <section class="section">
          <div class="section-header">
            <h1>Dashboard</h1>
          </div>
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                  <i class="far fa-user"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Total Users</h4>
                  </div>
                  <div class="card-body">
                   <?php if(!empty($totaluser)) { echo $totaluser; } else { echo "0"; } ?>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-danger">
                  <i class="fas fa-tag"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Active Offers</h4>
                  </div>
                  <div class="card-body">
                  <?php if(!empty($activeoffer)) { echo $activeoffer; } else { echo "0"; } ?>
                  </div>
                </div>
              </div>
            </div>
            <!-- div class="col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-warning">
                  <i class="far fa-file"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Reports</h4>
                  </div>
                  <div class="card-body">
                    1,201
                  </div>
                </div>
              </div>
            </div >
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-success">
                  <i class="fas fa-circle"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Online Users</h4>
                  </div>
                  <div class="card-body">
                    47
                  </div>
                </div>
              </div>
            </div -->                  
          </div>
          <div class="row">
			<div class="col-lg-8 col-md-8 col-12 col-sm-12">
              <div class="card" onload="bodyOnLoad()">
                <div class="card-header">
                  <h4>Users in last 30 days</h4>
                </div>
                <div class="card-body" >
				  <div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;">
					  <div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
						  <div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0">
						  </div>
					  </div>
					  <div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
						  <div style="position:absolute;width:200%;height:200%;left:0; top:0">
						  </div>
					  </div>
				  </div>
                  <canvas id="myChart" width="633" height="316" class="chartjs-render-monitor" style="display: block; width: 633px; height: 316px;"></canvas>
                </div>
              </div>
            </div>
			<div class="col-lg-4 col-md-4 col-sm-12">
              <div class="card gradient-bottom cmobiles">
				<?php if(!empty($topoffer)) { ?>
                <div class="card-header">
                  <h4>Top 10 Offers</h4>
                </div>
                <div class="card-body" id="top-5-scroll" tabindex="2" style="height: 315px; overflow: hidden; outline: none;">
                  <ul class="list-unstyled list-unstyled-border">
					<?php foreach($topoffer as $top) { ?>
						<li class="media">
						  <img alt="image" class="mr-3 rounded" width="50" src="<?php echo $top['image']; ?>" >
						  <div class="media-body">
							<div class="mt-0 mb-1 font-weight-bold"><?php if(!empty($top['title'])) { echo $top['title'];} else { } ?></div>
							<div class="text-dark"><?php if(!empty($top['download'])) { echo $top['download'];} else { echo "0"; } ?> Downloads</div>
						  </div>
						</li>      
					<?php } ?>
                </ul>
                </div>
				<?php } ?>
                <div class="card-footer pt-3 d-flex justify-content-center">
                  
                </div>
              </div>
            </div>
		  </div>
        </section>
		<script>
		getapihits();
		var myChart;
		function getapihits(){ 
			$.ajax({
				url: base_url+"user/userstate",
				cache: false,
				contentType: false,
				processData: false,
				type: 'POST',
				dataType: 'json',
				success: function(data) {
				  var statistics_chart = document.getElementById("myChart").getContext('2d');
				  if(myChart){
					myChart.destroy();
				  }
				  myChart = new Chart(statistics_chart, {
					type: 'line',
					data: {
					  labels: data['label'],
					  datasets: [{
						data: data['count'],
						borderWidth: 5,
						borderColor: '#6777ef',
						backgroundColor: 'transparent',
						pointBackgroundColor: '#fff',
						pointBorderColor: '#6777ef',
						pointRadius: 4
					  }]
					},
					options: {
					  legend: {
						display: false
					  },
					  scales: {
						yAxes: [{
						  gridLines: {
							display: false,
							drawBorder: false,
						  },
						  ticks: {
							stepSize: 100
						  }
						}],
						xAxes: [{
						  gridLines: {
							color: '#fbfbfb',
							lineWidth: 2
						  }
						}]
					  },
					}
				  }); 
				},
				error: function(data) {
				  console.log(data);
				}
			 });
		}
		</script>
      </div>