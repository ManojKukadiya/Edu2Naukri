<div class="main-content" style="min-height: 346px;">
        <section class="section">
          <div class="section-header">
            <h1>Edit Payment</h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="/">Dashboard</a></div>
              <div class="breadcrumb-item active"><a href="/payments">Payments</a></div>
              <div class="breadcrumb-item">Edit Payment</div>
            </div>
          </div>
          <div class="section-body">
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Edit Payment</h4>
                  </div>
                  <div class="card-body">
                    <form method="POST" action="<?php echo site_url('payment/edit/').$singlepay['id']; ?>"   enctype="multipart/form-data">
                      <div class="col-12">
                        <?php if($singlepay['mode'] == "paytm") { ?>
                        <div class="form-group row mb-4">
                            <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Paytm Number</label>
                            <div class="col-sm-12 col-md-7" id="step_table">
								<input type="text" class="form-control" placeholder="Paytm Number" value="<?php if(!empty($singlepay['phoneno'])) { echo $singlepay['phoneno'];} else { } ?>" disabled="">
							</div>
                        </div>
						<?php } else if($singlepay['mode'] == "upi") { ?>
						<div class="form-group row mb-4">
                            <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">UPI ID</label>
                            <div class="col-sm-12 col-md-7" id="step_table">
								<input type="text" class="form-control" placeholder="UPI ID" value="<?php if(!empty($singlepay['upi'])) { echo $singlepay['upi'];} else { } ?>" disabled="">
							</div>
                        </div>
						<?php } else { ?>
						<div class="form-group row mb-4">
                            <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Bank Name</label>
                            <div class="col-sm-12 col-md-7" id="step_table">
								<input type="text" class="form-control" placeholder="Bank Name" value="<?php if(!empty($singlepay['bankname'])) { echo $singlepay['bankname'];} else { } ?>" disabled="">
							</div>
                        </div>
						<div class="form-group row mb-4">
                            <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Account No</label>
                            <div class="col-sm-12 col-md-7" id="step_table">
								<input type="text" class="form-control" placeholder="Account No" value="<?php if(!empty($singlepay['bankaccount'])) { echo $singlepay['bankaccount'];} else { } ?>" disabled="">
							</div>
                        </div>
						   <div class="form-group row mb-4">
                            <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">IFSC Code</label>
                            <div class="col-sm-12 col-md-7" id="step_table">
								<input type="text" class="form-control" placeholder="IFSC Code" value="<?php if(!empty($singlepay['bankifsc'])) { echo $singlepay['bankifsc'];} else { } ?>" disabled="">
							</div>
                        </div>
						<?php } ?>
						<div class="form-group row align-items-center">
                          <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Amount</label>
                          <div class="col-sm-12 col-md-7">
                            <input type="text" name="amount" class="form-control"  placeholder="Amount" value="<?php if(!empty($singlepay['amount'])) { echo $singlepay['amount'];} else { } ?>" disabled="">
                          </div>
                        </div>
                        <div class="form-group row align-items-center">
                          <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Payment Transaction ID (Optional)</label>
                          <div class="col-sm-12 col-md-7">
                            <input name="transation_id" type="text" class="form-control" placeholder="Payment Transaction ID (Optional)"  value="<?php if(!empty($singlepay['transation_id'])) { echo $singlepay['transation_id'];} else { } ?>">
                          </div>
                        </div>

                        <div class="form-group row mb-4">
                          <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Payment Status</label>
                          <div class="col-sm-12 col-md-7">
                            <select name="status" class="form-control selectric" name="status">
                                <option value="0" <?php if($singlepay['status']== 0) echo 'selected="selected"'; ?>>Pending</option>
                                <option value="1" <?php if($singlepay['status']== 1) echo 'selected="selected"'; ?>>Completed</option>
                                <option value="2" <?php if($singlepay['status']== 2) echo 'selected="selected"'; ?>>Canceled</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="form-group row mb-4">
                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                        <div class="col-sm-12 col-md-7">
                          <button class="ml-2 btn btn-primary"  type="submit" >Update</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
         </div>
      </section>
    </div>