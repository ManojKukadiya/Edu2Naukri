	<footer class="main-footer">
        <div class="footer-left">
		<div class="bullet"></div> Develop By <a href="http://softicetechnology.com/">SoftIce Technology</a>
        </div>
        <div class="footer-right">
          
        </div>
      </footer>
    </div>
  </div>

  <!-- General JS Scripts -->
   <script src="<?php echo base_url()?>assets/modules/popper.js"></script>
  <script src="<?php echo base_url()?>assets/modules/tooltip.js"></script>
  <script src="<?php echo base_url()?>assets/modules/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url()?>assets/modules/nicescroll/jquery.nicescroll.min.js"></script>
  <script src="<?php echo base_url()?>assets/modules/moment.min.js"></script>
  <script src="<?php echo base_url()?>assets/js/stisla.js"></script>
  

  <!-- JS Libraies -->
  <script src="<?php echo base_url()?>assets/modules/datatables/datatables.min.js"></script>
  <script src="<?php echo base_url()?>assets/modules/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
  <script src="<?php echo base_url()?>assets/modules/datatables/Select-1.2.4/js/dataTables.select.min.js"></script>
  <script src="<?php echo base_url()?>assets/modules/jquery-ui/jquery-ui.min.js"></script>
  <script src="<?php echo base_url()?>assets/js/page/modules-datatables.js"></script>
	
  <!-- Page Specific JS File --> 
  <!--  <script src="<?php echo base_url()?>assets/js/page/index-0.js"></script> -->

  <!-- Template JS File -->
  <script src="<?php echo base_url()?>assets/js/scripts.js"></script>
  <script src="<?php echo base_url()?>assets/js/custom.js"></script>
  <script src="<?php echo base_url()?>assets/js/customscript.js"></script>
   <script>
	$(document).ready(function() { 
		var base_url = '<?php echo base_url(); ?>';
		$(document).on("click", ".statuschange", function(){
			var id=$(this).attr('data-id');
			$("a#btnstatuschange").attr('href','<?php echo base_url('user/changestatus'); ?>/'+id);
		}); 
		$(document).on("click", ".statusapp", function(){
			var id=$(this).attr('data-id');
			$("a#btnstatusapp").attr('href','<?php echo base_url('offers/changestatus'); ?>/'+id);
		}); 
		$(document).on("click", ".jobstatuschange", function(){
			var id=$(this).attr('data-id');
			$("a#btnjobstatuschange").attr('href','<?php echo base_url('jobs/changestatus'); ?>/'+id);
		}); 
		$(document).on("click", ".categorydelete", function(){
			var id=$(this).attr('data-id');
			$("a#btncatgorylist").attr('href','<?php echo base_url('category/deletecategory'); ?>/'+id);
		}); 
		$(document).on("click", ".qualificationdelete", function(){
			var id=$(this).attr('data-id');
			$("a#btnqualificationlist").attr('href','<?php echo base_url('qualification/deletequalification'); ?>/'+id);
		}); 
	});
 </script>
</body>
</html>