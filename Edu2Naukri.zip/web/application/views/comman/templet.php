<?php

$this->load->view('comman/header');
$this->load->view('comman/sitebar');
    if(isset($main_content))
    {
        $this->load->view($main_content);
    }
$this->load->view('comman/footer');
?>