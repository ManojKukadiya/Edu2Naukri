<div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="<?php echo  base_url(); ?>">Edu2Naukri</a>
          </div>
          <ul class="sidebar-menu">
            <li class="menu-header">Dashboard</li>
            <li class="<?php if($this->uri->segment(1)=="index"){echo "active";}?>"><a class="nav-link" href="<?php echo  base_url(); ?>index"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
            <li class="<?php if($this->uri->segment(1)=="user"){echo "active";}?>"><a class="nav-link" href="<?php echo  base_url(); ?>user"><i class="fas fa-user"></i> <span>User</span></a></li>
			<li class="<?php if($this->uri->segment(1)=="offers"){echo "active";}?>"><a class="nav-link" href="<?php echo  base_url(); ?>offers"><i class="fas fa-tags"></i> <span>Offer</span></a></li>
			<li class="<?php if($this->uri->segment(1)=="jobs"){echo "active";}?>"><a class="nav-link" href="<?php echo  base_url(); ?>jobs"><i class="fas fa-tags"></i> <span>Jobs</span></a></li>
			<li class="<?php if($this->uri->segment(1)=="payment"){echo "active";}?>"><a class="nav-link" href="<?php echo  base_url(); ?>payment"><i class="fas fa-money-bill"></i> <span>Payments</span></a></li>
			<li class="<?php if($this->uri->segment(1)=="notification"){echo "active";}?>"><a class="nav-link" href="<?php echo  base_url(); ?>notification"><i class="fas fa-bell"></i> <span>Push Notification</span></a></li>
			<li class="<?php if($this->uri->segment(1)=="contact"){echo "active";}?>"><a class="nav-link" href="<?php echo  base_url(); ?>contact"><i class="fas fa-comment-alt"></i> <span>Contact Us</span></a></li>
			<li class="<?php if($this->uri->segment(1)=="settings"){echo "active";}?>"><a class="nav-link" href="<?php echo  base_url(); ?>settings"><i class="fas fa-cog"></i> <span>Settings</span></a></li>
                     
		 </ul>
    </aside>
</div>