<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mdl_dashboard extends CI_Model {
		
		public function totaluser()
		{
			$query=$this->db->get('user');
			return $query->num_rows();
		}
		public function activeoffer()
		{
			$this->db->where('status',0);
			$query=$this->db->get('applist');
			return $query->num_rows();
		}
		public function topoffer()
		{
			$this->db->select('a.id as appid,a.title,a.image,COUNT(al.app_id) as download');
			$this->db->join('appinstall as al','al.app_id=a.id');
			$this->db->where('status',0);
			$this->db->group_by('al.app_id'); 
			$this->db->order_by('download', 'desc'); 
			$query=$this->db->get('applist as a',10);
			return $query->result_array();
		}
		
		/* public function fetchuser()
		{
			$this->db->select('user.id,user.fname,user.lname,user.email,user.profile,user.created,user.status,c.totalcoin, COUNT(referralcode.sender_id) as treferral')
			->from('user')
			->order_by('user.id', 'desc');
			$this->db->join('coin as c','c.user_id=user.id');
			$this->db->join('referralcode', 'sender_id = user.id','left')->group_by('user.id');
			$query=$this->db->get(); 
			return $query->result_array();
		} 
		public function fetchuserByid($id)
		{
			$this->db->select('user.id,user.fname,user.lname,user.email,user.profile,user.referralcode,user.status,c.totalcoin, COUNT(referralcode.sender_id) as treferral')
			->from('user')
			->order_by('user.id', 'desc');
			$this->db->join('coin as c','c.user_id=user.id');
			$this->db->join('referralcode', 'sender_id = user.id','left')->group_by('user.id');
			$this->db->where('user.id',$id);
			$query=$this->db->get(); 
			return $query->row_array();
		} 
		public function transactionByid($id)
		{
			$this->db->where('user_id',$id);
			$query=$this->db->get('transcation');
			return $query->result_array();
		}
		public function historyById($id)
		{
			$this->db->select('a.id,l.title,l.image,a.created');
			$this->db->from('appinstall as a');
			$this->db->join('applist as l','a.app_id=l.id');
			$this->db->where('a.user_id',$id);
			$query=$this->db->get('');
			return $query->result_array();
		}
		public function refersById($id)
		{
			$this->db->select('l.fname,l.lname,l.email');
			$this->db->from('referralcode as re');
			$this->db->join('user as l','re.receiver_id=l.id');
			$this->db->where('re.sender_id',$id);
			$query=$this->db->get('');
			return $query->result_array();
		}
		
		/*public function adduser($data)
		{
			$this->db->insert('tbluser',$data);
			return $this->db->affected_rows();
		}
		public function fetchuserdata($id)
		{
			$this->db->where('id',$id);
			$query=$this->db->get('tbluser');
			return $query->row_array();
		}
		public function updateuserdata($data,$id)
		{
			$this->db->where('id',$id);
			$this->db->update('tbluser',$data);
			return $this->db->affected_rows();
		}
		public function deleteuser($id)
		{
			$this->db->where('id',$id);
			$this->db->delete('tbluser');
			return $this->db->affected_rows();
			
		}
		public function checkuser($emailaddress,$password)
		{
			$this->db->where('email',$emailaddress);
			$this->db->where('password',$password);
			$query=$this->db->get('tbluser');
			$result=$query->row_array();
			return $result; 
			
		} */
		
}
