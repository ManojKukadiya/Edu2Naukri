<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mdl_notification extends CI_Model {
	
		public function fetchpayment()
		{
			$this->db->select('user.id,user.fname,user.lname,user.email,user.profile,user.referralcode,r.id as redeemid,r.mode,r.amount,r.status');
			$this->db->join('redeemmoney as r','r.user_id=user.id');
			$query=$this->db->get('user'); 
			return $query->result_array();
		} 
		public function fetchpaymentdata($id)
		{
			$this->db->where('id',$id);
			$query=$this->db->get('redeemmoney');
			return $query->row_array();
		}
		public function updatepaymentstatus($data,$id)
		{
			$this->db->where('id', $id);
			$this->db->update('redeemmoney',$data);
			return $this->db->affected_rows();	
		}
		
}
