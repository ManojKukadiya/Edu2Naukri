<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mdl_user extends CI_Model {
    
    public function  __construct(){
        parent::__construct();
         $this->load->helper('date');
         date_default_timezone_set('Asia/Kolkata');
    }
    public function userregister($data,$email)
    {
		$query = $this->db->get_where('user', array('email' => $email));
		if ($query->num_rows() > 0) {
			return "2";
		} 
		else 
		{
			if($data['fbid'] != null)
				$this->db->where('fbid',$data['fbid']); 
			if($data['gbid'] != null)
				 $this->db->where('gbid',$data['gbid']);
			$query=$this->db->get('user');
			$datas=$query->num_rows();
			if($datas == "1")
			{
				$data['modified'] = date('Y-m-d H:i:s',now());
				if($data['fbid'] != null)
					$this->db->where('fbid',$data['fbid']); 
				if($data['gbid'] != null)
					 $this->db->where('gbid',$data['gbid']);
				$this->db->update('user',$data);
			}
			else
			{
				
				$data['created'] = date('Y-m-d H:i:s',now());
				$data['modified'] = date('Y-m-d H:i:s',now());
				$this->db->insert('user',$data);
				$last_id = $this->db->insert_id();
				$coindata=array(
				   'user_id' => $last_id,
				   'totalcoin' => '0'
				);
				$this->db->insert('coin',$coindata);
			}
			$affrect=$this->db->affected_rows();
			if($affrect > 0)
			{
				if($data['fbid'] != null)
					$this->db->where('fbid',$data['fbid']); 
				if($data['gbid'] != null)
					 $this->db->where('gbid',$data['gbid']);
				$query=$this->db->get('user'); 
				return $query->row_array();
			}
			else
			{
				return '';
			}
		}
    }
	 
	 public function userlogin($data)
    {
        $this->db->insert('userlogin',$data);
      	$this->db->select('u.id,u.fname,u.lname,u.email,u.profile,u.referralcode,c.totalcoin,ul.devicetoken,ul.authtoken');
		$this->db->from('userlogin as ul');
        $this->db->join('user as u','u.id=ul.user_id');
		$this->db->join('coin as c','u.id=c.user_id');
		$this->db->where('ul.devicetoken',$data['devicetoken']);
		$this->db->where('ul.user_id',$data['user_id']);
		$query=$this->db->get('userlogin');
		$result=$query->row_array();
		return $result;
    }
	
	public function fbidcheck($fbid)
	{
		$this->db->where('fbid',$fbid);
		$query=$this->db->get('user');
		$datas=$query->row_array();
		return $datas;
	}
	
	public function gbidcheck($gbid)
	{
		$this->db->where('gbid',$gbid);
		$query=$this->db->get('user');
		$datas=$query->row_array();
		return $datas;
	}
	public function receivercode($receiver)
	{
		$this->db->select('u.id,ul.playerId');
		$this->db->from('user as u');
		$this->db->join('userlogin as ul','u.id=ul.user_id');
		$this->db->where('u.referralcode',$receiver);
		$query=$this->db->get();
		$result=$query->row_array();
		return $result;
		
	}
	public function referralcode($referralcodedata)
	{
		$this->db->insert('referralcode',$referralcodedata);
		$referralcode=$this->db->affected_rows();	
		if($referralcode == "1")
		{
			$this->db->select('reffercoin')->where('id',1);
			$reffer=$this->db->get('appsettings');
			$refferdata=$reffer->row_array();
			for($i=1;$i<=2;$i++)
			{
				if($i==1)
				{
					$user_id=$referralcodedata['sender_id'];
				}
				else
				{
					$user_id=$referralcodedata['receiver_id'];
				}

				$transcation=array(
						'user_id'=>$user_id,
						'coin'=>$refferdata['reffercoin'],
						'description'=>'Referral');
				$this->db->insert('transcation',$transcation);
				$transcationrow=$this->db->affected_rows();	
				if($transcationrow == "1")
				{
					$this->db->where('user_id',$user_id);
					$query=$this->db->get('coin');
					$datas=$query->row_array();
					if(!empty($datas))
					{
							$totalcoin=$datas['totalcoin']+$refferdata['reffercoin'];
							$this->db->set('totalcoin',$totalcoin);
							$this->db->where('user_id',$user_id);
							$this->db->update('coin');
					}
					else
					{
						$coin=array(
										'user_id'=>$user_id,
										'totalcoin'=>$refferdata['reffercoin']
									);
						$coin['created'] = date('Y-m-d H:i:s',now());
						$coin['modified'] = date('Y-m-d H:i:s',now());
						$this->db->insert('coin',$coin);
					}
				}
				else
				{
					return "2";
				}
			}	
			return $this->db->affected_rows();	
		}
		else
		{
			return "2";
		}
	}
    public function IsValidAuthToken($userid,$authtoken)
	{
		$this->db->where(array('user_id'=>$userid,'authtoken'=>$authtoken));
		$query=$this->db->get('userlogin');
		$result=$query->row_array();
		return $result;
	}
	
	public function logoutuser($data)
    {
        $this->db->where('user_id',$data['user_id']);
		$this->db->where('authtoken',$data['authtoken']);
		$this->db->where('devicetoken',$data['devicetoken']);
		$this->db->delete('userlogin');
		$query=$this->db->affected_rows();
		return $query;
    } 
  
    public function profiledata($user_id)
    {
        $this->db->select('u.fname,u.lname,u.email,u.profile,c.totalcoin');
        $this->db->from('user as u');
        $this->db->join('coin as c','u.id=c.user_id','left');
        $this->db->where('u.id',$user_id);
        $query=$this->db->get('');
        return $query->row_array();
    }
	public function redeemuser($data,$withcoin)
	{
		$this->db->where('user_id', $data['user_id']);
		$this->db->set('totalcoin', '`totalcoin`-'.$withcoin, FALSE);
		$this->db->update('coin');
		$this->db->trans_complete();
		if ($this->db->trans_status() === FALSE){
			return "-1";
		}
		else
		{
			$query=$this->db->insert('redeemmoney',$data);
			return $this->db->insert_id();
		}
	}
	public function checkAmount($user_id)
	{
		$this->db->select('totalcoin');
		$this->db->where('user_id',$user_id);
		$query=$this->db->get('coin');
		$totalcoin=$query->row_array();
		if($totalcoin['totalcoin'] > 0)
		{
			return $totalcoin['totalcoin'];
		}
		else
		{
			return "-1";
		}
	}
	public function miniAmount(){
		$this->db->select('coin,miniwith');
		$query1=$this->db->get('appsettings');
		return $query1->row_array();
	}
	public function transationHistory($user_id)
	{
		$this->db->select('coin,description,tran_date');
		$this->db->where('user_id',$user_id);
		$this->db->order_by('tran_date','ASC');
		$query1=$this->db->get('transcation');
		return $query1->result_array();	
	}
	public function WithdrawHistory($user_id)
	{
		$this->db->select('amount,mode,status,created');
		$this->db->where('user_id',$user_id);
		$this->db->order_by('created','ASC');
		$query1=$this->db->get('redeemmoney');
		return $query1->result_array();	
	}
	public function userInvite()
	{
		$this->db->select('image,link,message,term,invitecoin');
		$this->db->where('id',1);
		$query1=$this->db->get('settinginvite');
		return $query1->row_array();	
	}
	public function contactForm($contactform)
	{		
		$contactform['created'] = date('Y-m-d H:i:s',now());
		$contactform['modified'] = date('Y-m-d H:i:s',now());
		$this->db->insert('contactus',$contactform);
		return $this->db->affected_rows();	
	}
	public function fetchaboutus()
	{
		$this->db->select('aboutus');
		$this->db->where('id',1);
		$query1=$this->db->get('aboutus');
		return $query1->row_array();
	}
	public function fetchprivacy()
	{
		$this->db->select('contactus');
		$this->db->where('id',1);
		$query1=$this->db->get('aboutus');
		return $query1->row_array();
	}
	public function fetchteam()
	{
		$this->db->select('team');
		$this->db->where('id',1);
		$query1=$this->db->get('aboutus');
		return $query1->row_array();
	}	
	public function fetchadslist()	
	{		
		$this->db->select('team,fbnative,fbbanner,fbnativebanner,fbinterstitial,fbrewarded');		
		$this->db->where('id',1);		
		$query1=$this->db->get('aboutus');		
		return $query1->row_array();	
	}
	public function dailychecknow($data)
	{
		$this->db->insert('transcation',$data);
		return $this->db->affected_rows();
	}
	public function addcoin($coin)
	{
		$this->db->where('user_id',$coin['user_id']);
		$query=$this->db->get('coin');
		$datas=$query->num_rows();
		if($datas == "1")
		{
			$olddata=$query->row_array();
			$newspin=$olddata['totalcoin']+$coin['totalcoin'];
			$coin['modified'] = date('Y-m-d H:i:s',now());
			$this->db->set('totalcoin',$newspin);
			$this->db->where('user_id',$coin['user_id']);
			$this->db->update('coin');
		}
		else
		{
			$coin['created'] = date('Y-m-d H:i:s',now());
            $coin['modified'] = date('Y-m-d H:i:s',now());
            $this->db->insert('coin',$coin);
		}
		return $this->db->affected_rows();
		
	}
	public function fetchsetting()
	{
		$this->db->select('min_coin,max_coin');
		$this->db->where('id',1);
		$query=$this->db->get('appsettings');
		return $query->row_array();
	}
}