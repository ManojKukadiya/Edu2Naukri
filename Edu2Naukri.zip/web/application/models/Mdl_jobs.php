<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mdl_jobs extends CI_Model {
	
		public function fetchcategory()
		{
			$query=$this->db->get('jobcategory');
			return $query->result_array();
		}
		public function fetchstate()
		{
			$query=$this->db->get('state');
			return $query->result_array();
		}
		public function fetchqualification()
		{
			$query=$this->db->get('qualification');
			return $query->result_array();
		}
		public function addjobs($data)
		{
			$query=$this->db->insert('jobs',$data);
			return $this->db->insert_id();
		}
		public function fetchjobs()
		{
			$this->db->select('j.id,j.title,j.status,c.name as category,s.name as state,q.name as qualification,j.lastdate');
			$this->db->join('jobcategory as c','c.id=j.category');
			$this->db->join('state as s','s.id=j.state');
			$this->db->join('qualification as q','q.id=j.jobqulification');
			$query=$this->db->get('jobs as j');
			return $query->result_array();
		}
		public function fetchJobById($id)
		{
			$this->db->where('j.id',$id);
			$query=$this->db->get('jobs as j');
			return $query->row_array();
		}
		public function editjobs($data,$id){
			$this->db->where('id',$id);
			$this->db->update('jobs',$data);
			return $this->db->affected_rows();
		}
		
		public function addsubjobs($data)
		{
			$query=$this->db->insert('subjobs',$data);
			return $this->db->insert_id();
		}
		public function fetchsubjobs($id)
		{
			$this->db->where('job_id',$id);
			$query=$this->db->get('subjobs');
			return $query->result_array();	
		}
		public function jobtitle($id)
		{
			$this->db->select('title');
			$this->db->where('id',$id);
			$query=$this->db->get('jobs');
			return $query->row_array();	
		}
		public function jobidBYSubjob($id)
		{
			$this->db->where('id',$id);
			$query=$this->db->get('subjobs');
			return $query->row_array();	
		}
		public function editsubjobs($data,$id)
		{
			$this->db->where('id',$id);
			$this->db->update('subjobs',$data);
			return $this->db->affected_rows();
		}
		public function changestatus($id)
		{
			$this->db->select('status');
			$this->db->where('id', $id);
			$query=$this->db->get('jobs');
			$status=$query->row_array();
			if($status['status'] == 0)
			{
				$this->db->set('status', 1);
				$this->db->where('id', $id);
				$this->db->update('jobs');
				return $this->db->affected_rows();				
			}
			else
			{
				$this->db->set('status', 0);
				$this->db->where('id', $id);
				$this->db->update('jobs');
				return $this->db->affected_rows();		
			}
			
		}
		/* public function fetchoffer()
		{
			$this->db->select('a.id,a.title,a.image,a.amount,a.created,a.status,COUNT(ai.app_id) as total')
			->from('applist as a')
			->order_by('a.id', 'desc')
			->join('appinstall as ai','ai.app_id=a.id','left')
			->group_by('a.id');
			$query=$this->db->get();
			return $query->result_array();
		}
		public function addoffer($data)
		{
			$this->db->insert('applist',$data);
			return $this->db->insert_id();
		}
		public function insertappdescription($data)
		{
			$this->db->insert('appdescription',$data);
			return $this->db->insert_id();
		}
		public function editoffer($id)
		{
			$this->db->select('*')
			->from('applist as a')	
			->where('a.id',$id);
			$query=$this->db->get();
			return $query->row_array();
		}
		public function editofferdesc($id)
		{
			$this->db->select('step')
			->from('appdescription as ad')	
			->where('ad.app_id',$id);
			$query=$this->db->get();
			return $query->result_array();
		}
		public function updateoffer($data,$id)
		{
			$this->db->where('id',$id);
			$this->db->update('applist',$data);
			return $this->db->affected_rows();
		}
		public function deleteoffers($id)
		{
			$this->db->where('app_id',$id);
			$this->db->delete('appdescription');
			return $this->db->affected_rows();
		}
		
		 */ 
		 
	/*	public function fetchuser()
		{
			$this->db->select('user.id,user.fname,user.lname,user.email,user.profile,user.created,user.status,c.totalcoin, COUNT(referralcode.sender_id) as treferral')
			->from('user')
			->order_by('user.id', 'desc');
			$this->db->join('coin as c','c.user_id=user.id');
			$this->db->join('referralcode', 'sender_id = user.id','left')->group_by('user.id');
			$query=$this->db->get(); 
			return $query->result_array();
		} 
		public function fetchuserByid($id)
		{
			$this->db->select('user.id,user.fname,user.lname,user.email,user.profile,user.referralcode,user.status,c.totalcoin, COUNT(referralcode.sender_id) as treferral')
			->from('user')
			->order_by('user.id', 'desc');
			$this->db->join('coin as c','c.user_id=user.id');
			$this->db->join('referralcode', 'sender_id = user.id','left')->group_by('user.id');
			$this->db->where('user.id',$id);
			$query=$this->db->get(); 
			return $query->row_array();
		} 
		public function transactionByid($id)
		{
			$this->db->where('user_id',$id);
			$query=$this->db->get('transcation');
			return $query->result_array();
		}
		public function historyById($id)
		{
			$this->db->select('a.id,l.title,l.image,a.created');
			$this->db->from('appinstall as a');
			$this->db->join('applist as l','a.app_id=l.id');
			$this->db->where('a.user_id',$id);
			$query=$this->db->get('');
			return $query->result_array();
		}
		public function refersById($id)
		{
			$this->db->select('l.fname,l.lname,l.email');
			$this->db->from('referralcode as re');
			$this->db->join('user as l','re.receiver_id=l.id');
			$this->db->where('re.sender_id',$id);
			$query=$this->db->get('');
			return $query->result_array();
		}
		
		/*public function adduser($data)
		{
			$this->db->insert('tbluser',$data);
			return $this->db->affected_rows();
		}
		public function fetchuserdata($id)
		{
			$this->db->where('id',$id);
			$query=$this->db->get('tbluser');
			return $query->row_array();
		}
		public function updateuserdata($data,$id)
		{
			$this->db->where('id',$id);
			$this->db->update('tbluser',$data);
			return $this->db->affected_rows();
		}
		public function deleteuser($id)
		{
			$this->db->where('id',$id);
			$this->db->delete('tbluser');
			return $this->db->affected_rows();
			
		}
		public function checkuser($emailaddress,$password)
		{
			$this->db->where('email',$emailaddress);
			$this->db->where('password',$password);
			$query=$this->db->get('tbluser');
			$result=$query->row_array();
			return $result; 
			
		} */
		
}
