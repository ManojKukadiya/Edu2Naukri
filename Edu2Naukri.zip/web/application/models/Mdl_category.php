<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mdl_category extends CI_Model {
	
		public function fetchcategory()
		{
			$query=$this->db->get('jobcategory');
			return $query->result_array();
		}
		public function addcategory($data)
		{
			$query=$this->db->insert('jobcategory',$data);
			return $this->db->insert_id();
		}
		public function fetchCategoryById($id)
		{
			$this->db->where('id',$id);
			$query=$this->db->get('jobcategory');
			return $query->row_array();
		}
		public function editcategory($data,$id){
			$this->db->where('id',$id);
			$this->db->update('jobcategory',$data);
			return $this->db->affected_rows();
		}
		public function deletecategorys($id)
		{
			$this->db->where('id',$id);
			$this->db->delete('jobcategory');
			return $this->db->affected_rows();
		}
		
}
