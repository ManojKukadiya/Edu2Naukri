<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mdl_settings extends CI_Model {
	
		public function fetchredeemlist()
		{
			$this->db->where('id',1);
			$query=$this->db->get('settingredeem');
			return $query->row_array();
		}
		public function updateredeemlist($data)
		{
			$this->db->where('id',1);
			$query=$this->db->update('settingredeem',$data);
			return $this->db->affected_rows();
		}
		public function fetchversion()
		{
			$this->db->where('id',1);
			$query=$this->db->get('settingsversion');
			return $query->row_array();
		}
		public function updateversion($data)
		{
			$this->db->where('id',1);
			$query=$this->db->update('settingsversion',$data);
			return $this->db->affected_rows();
		}
		public function fetchinvite()
		{
			$this->db->where('id',1);
			$query=$this->db->get('settinginvite');
			return $query->row_array();
		}
		public function updateinvited($data,$file)
		{
			if(!empty($file))
				$this->db->set('image',$file);
			$this->db->where('id',1);
			$query=$this->db->update('settinginvite',$data);
			return $this->db->affected_rows();
		}
		public function fetchsetting()
		{
			$this->db->where('id',1);
			$query=$this->db->get('appsettings');
			return $query->row_array();
		}
		public function updateappsettings($data)
		{
			$this->db->where('id',1);
			$query=$this->db->update('appsettings',$data);
			return $this->db->affected_rows();
		}
		public function fetchaboutus()
		{
			$this->db->where('id',1);
			$query=$this->db->get('aboutus');
			return $query->row_array();
		}
		public function updateaboutus($data)
		{
			$this->db->where('id',1);
			$query=$this->db->update('aboutus',$data);
			return $this->db->affected_rows();
		}
				public function fetchadssetting()		{			$this->db->where('id',1);			$query=$this->db->get('aboutus');			return $query->row_array();		}		public function updateadssettings($data)		{			$this->db->where('id',1);			$query=$this->db->update('aboutus',$data);			return $this->db->affected_rows();		}
}
