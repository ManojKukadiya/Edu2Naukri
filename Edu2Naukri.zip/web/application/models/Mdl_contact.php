<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mdl_contact extends CI_Model {
		
		public function fetchcontact()
		{
			$this->db->select('c.id as contactid,u.id as userid,u.email,c.heading,c.message');
			$this->db->join('contactus as c','c.user_id=u.id');
			$query=$this->db->get('user as u'); 
			return $query->result_array();
		} 
		
		
}
