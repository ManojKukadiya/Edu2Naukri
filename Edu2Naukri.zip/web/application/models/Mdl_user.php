<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mdl_user extends CI_Model {
		
		public function fetchuser()
		{
			$this->db->select('user.id,user.fname,user.lname,user.email,user.profile,user.created,user.status,c.totalcoin, COUNT(referralcode.sender_id) as treferral')
			->from('user')
			->order_by('user.id', 'desc');
			$this->db->join('coin as c','c.user_id=user.id');
			$this->db->join('referralcode', 'sender_id = user.id','left')->group_by('user.id');
			$query=$this->db->get(); 
			return $query->result_array();
		} 
		public function fetchuserByid($id)
		{
			$this->db->select('user.id,user.fname,user.lname,user.email,user.profile,user.referralcode,user.status,c.totalcoin, COUNT(referralcode.sender_id) as treferral')
			->from('user')
			->order_by('user.id', 'desc');
			$this->db->join('coin as c','c.user_id=user.id');
			$this->db->join('referralcode', 'sender_id = user.id','left')->group_by('user.id');
			$this->db->where('user.id',$id);
			$query=$this->db->get(); 
			return $query->row_array();
		} 
		public function transactionByid($id)
		{
			$this->db->where('user_id',$id);
			$query=$this->db->get('transcation');
			return $query->result_array();
		}
		public function historyById($id)
		{
			$this->db->select('a.id,l.title,l.image,a.created');
			$this->db->from('appinstall as a');
			$this->db->join('applist as l','a.app_id=l.id');
			$this->db->where('a.user_id',$id);
			$query=$this->db->get('');
			return $query->result_array();
		}
		public function refersById($id)
		{
			$this->db->select('l.fname,l.lname,l.email');
			$this->db->from('referralcode as re');
			$this->db->join('user as l','re.receiver_id=l.id');
			$this->db->where('re.receiver_id',$id);
			$query=$this->db->get('');
			return $query->result_array();
		}
		public function getusercount()
		{
			$this->db->select('DATE_FORMAT(created, "%Y-%m-%d") as label,COUNT(*) as count');
			$this->db->group_by('DATE_FORMAT(created, "%Y-%m-%d")');
			$this->db->order_by('created','DESC');
			$this->db->limit(31);
			$query=$this->db->get('user');
			return $query->result_array();
		}
		public function changestatus($id)
		{
			$this->db->select('status');
			$this->db->where('id', $id);
			$query=$this->db->get('user');
			$status=$query->row_array();

			if($status['status'] == 0)
			{
				$this->db->set('status', 1);
				$this->db->where('id', $id);
				$this->db->update('user');
				return $this->db->affected_rows();				
			}
			else
			{
				$this->db->set('status', 0);
				$this->db->where('id', $id);
				$this->db->update('user');
				return $this->db->affected_rows();		
			}
			
		}
		public function changeusercoin($coin,$id)
		{
			$this->db->set('totalcoin', $coin);
			$this->db->where('user_id',$id);
			$this->db->update('coin');
			return $this->db->affected_rows();
		}
		/*public function adduser($data)
		{
			$this->db->insert('tbluser',$data);
			return $this->db->affected_rows();
		}
		public function fetchuserdata($id)
		{
			$this->db->where('id',$id);
			$query=$this->db->get('tbluser');
			return $query->row_array();
		}
		public function updateuserdata($data,$id)
		{
			$this->db->where('id',$id);
			$this->db->update('tbluser',$data);
			return $this->db->affected_rows();
		}
		public function deleteuser($id)
		{
			$this->db->where('id',$id);
			$this->db->delete('tbluser');
			return $this->db->affected_rows();
			
		}
		*/
		public function checkuser($emailaddress,$password)
		{
			$this->db->where('email',$emailaddress);
			$this->db->where('password',$password);
			$query=$this->db->get('tbluser');
			$result=$query->row_array();
			return $result; 
			
		} 
		
}
