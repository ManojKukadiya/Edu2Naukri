<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mdl_qualification extends CI_Model {
	
		public function fetchqualification()
		{
			$query=$this->db->get('qualification');
			return $query->result_array();
		}
		public function addqualification($data)
		{
			$query=$this->db->insert('qualification',$data);
			return $this->db->insert_id();
		}
		public function fetchQualificationById($id)
		{
			$this->db->where('id',$id);
			$query=$this->db->get('qualification');
			return $query->row_array();
		}
		public function editqualification($data,$id){
			$this->db->where('id',$id);
			$this->db->update('qualification',$data);
			return $this->db->affected_rows();
		}
		public function deletequalifications($id)
		{
			$this->db->where('id',$id);
			$this->db->delete('qualification');
			return $this->db->affected_rows();
		}
		
}
