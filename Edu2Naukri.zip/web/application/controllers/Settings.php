<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends CI_Controller {

	public function __construct(){
		parent::__construct();
		if(site_url() == MY_SITE)
		{		
		
			if($this->session->userdata('userdata'))
			{
				$this->load->Model('Mdl_settings');
				$this->load->library('form_validation','globals');
				$this->load->helper(array('form', 'url'));
			}
			else
			{
				redirect('user/login');
				exit;
			}
		 }
	    else
		{
		 	redirect('user/login');
		 	exit;
		 }
    }
	public function index()
	{
		$fetchsetting=$this->Mdl_settings->fetchsetting();
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'fetchsetting'=>$fetchsetting,
            'main_content' => 'pages/settings/appsettings'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function editredeem($id)
	{
		$data=array(
					'amount'=>$_POST['Reedem_Amount'],
					'redeemteam'=>$_POST['site_description']					
		);
	
		$updateredeem=$this->Mdl_settings->updateredeemlist($data,$id);
		if(!empty($updateredeem))
		{
			$this->session->set_flashdata('success', 'Update Successfully.');
			redirect('settings');	
		}
		else
		{
			$data=$this->session->set_flashdata('error','Something went Wrong.');
			redirect('settings');
		}
	}
	public function version()
	{
		$versionlist=$this->Mdl_settings->fetchversion();
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'versionlist'=>$versionlist,
            'main_content' => 'pages/settings/version'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function editversion($id)
	{
		$data=array(
			'version'=>$_POST['version'],
			'minversion'=>$_POST['min_version'],
			'updatelink'=>$_POST['Update_Link']						
		);
	
		$updateversion=$this->Mdl_settings->updateversion($data,$id);
		if(!empty($updateversion))
		{
			$this->session->set_flashdata('success', 'Update Successfully.');
			redirect('settings/version');	
		}
		else
		{
			$data=$this->session->set_flashdata('error','Something went Wrong.');
			redirect('settings/version');	
		}
	}
	public function invite()
	{
		$fetchinvite=$this->Mdl_settings->fetchinvite();
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'fetchinvite'=>$fetchinvite,
            'main_content' => 'pages/settings/invite'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function editinvite($id)
	{
		if(!empty($_FILES['invite_image']['name']))
		{
			$invite = time().'_'.$_FILES['invite_image']['name'];
			$config['file_name'] = $invite;
			$config['upload_path'] = './uploads';
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size'] = 2000;
			$config['max_width'] = 1500;
			$config['max_height'] = 1500;

			$this->upload->initialize($config);
			
			if($this->upload->do_upload('invite_image'))
			{
				$file = 'uploads/'.$invite;
			}
			else
			{
				$error = array('error' => $this->upload->display_errors());
				$file='';
			}
		}
		$data=array(
			'invitecoin'=>$_POST['invite_coin'],
			'message'=>$_POST['site_description'],
			'link'=>$_POST['invitelink'],
			'term'=>$_POST['team']						
		);
	
		$updateversion=$this->Mdl_settings->updateinvited($data,$file);
		if(!empty($updateversion))
		{
			$this->session->set_flashdata('success', 'Update Successfully.');
			redirect('settings/invite');	
		}
		else
		{
			$data=$this->session->set_flashdata('error','Something went Wrong.');
			redirect('settings/invite');	
		}
	}
	public function appsetting()
	{
		$fetchsetting=$this->Mdl_settings->fetchsetting();
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'fetchsetting'=>$fetchsetting,
            'main_content' => 'pages/settings/appsettings'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function aboutus()
	{
		$fetchaboutus=$this->Mdl_settings->fetchaboutus();
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'fetchaboutus'=>$fetchaboutus,
            'main_content' => 'pages/settings/aboutus'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function editaboutus($id)
	{
		$data=array(
			'aboutus'=>$_POST['aboutus'],
			'contactus'=>$_POST['contactus'],
			'team'=>$_POST['team']
		);
	
		$updateaboutus=$this->Mdl_settings->updateaboutus($data,$id);
		if(!empty($updateaboutus))
		{
			$this->session->set_flashdata('success', 'Update Successfully.');
			redirect('settings/aboutus');	
		}
		else
		{
			$data=$this->session->set_flashdata('error','Something went Wrong.');
			redirect('settings/aboutus');	
		}
	}
	
	
	public function editappsettings($id)
	{
		$data=array(
			'coin'=>$_POST['Coin_Amount'],
			'miniwith'=>$_POST['Withdraw_Amount'],
			'reffercoin'=>$_POST['Referral_Coin'],
			'min_coin'=>$_POST['min_coin'],	
			'max_coin'=>$_POST['max_coin']				
		);

		$updateappsettings=$this->Mdl_settings->updateappsettings($data,$id);

		if(!empty($updateappsettings))
		{
			$this->session->set_flashdata('success', 'Update Successfully.');
			redirect('settings/appsetting');	
		}
		else
		{
			$data=$this->session->set_flashdata('error','Something went Wrong.');
			redirect('settings/appsetting');	
		}
	}
	public function adssetting()
	{
		$fetchsetting=$this->Mdl_settings->fetchadssetting();
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'fetchsetting'=>$fetchsetting,
            'main_content' => 'pages/settings/adssettings'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function editadssettings($id)
	{
		$data=array(
			'fbnative'=>$_POST['fbnative'],
			'fbbanner'=>$_POST['fbbanner'],
			'fbnativebanner'=>$_POST['fbnativebanner'],
			'fbinterstitial'=>$_POST['fbinterstitial'],
			'fbrewarded'=>$_POST['fbrewarded']			
		);

		$updateappsettings=$this->Mdl_settings->updateadssettings($data,$id);

		if(!empty($updateappsettings))
		{
			$this->session->set_flashdata('success', 'Update Successfully.');
			redirect('settings/adssetting');	
		}
		else
		{
			$data=$this->session->set_flashdata('error','Something went Wrong.');
			redirect('settings/adssetting');	
		}
	}
}
