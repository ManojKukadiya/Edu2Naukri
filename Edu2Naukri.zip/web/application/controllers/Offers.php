<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Offers extends CI_Controller {

	public function __construct(){
		parent::__construct();
		 if(site_url() == MY_SITE)
		 {		
			if($this->session->userdata('userdata'))
			{
				$this->load->Model('Mdl_app');
				$this->load->library('form_validation','globals');
				$this->load->helper(array('form', 'url'));
			}
			else
			{
				redirect('user/login');
				exit;
			}
		 }
		 else
		 {
			redirect('user/login');
		 	exit;
		 }
    }
	public function index()
	{

		$applist=$this->Mdl_app->fetchoffer();
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
            'applist'=>$applist,
            'main_content' => 'pages/offer/offerlist'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function newoffer()
	{
		$this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
            'main_content' => 'pages/offer/new'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function addoffer()
	{
		$ispost=$this->input->method(TRUE);
		if($ispost == "POST")
		{
			$this->form_validation->set_rules('title','Enter Title','required');
			$this->form_validation->set_rules('icon','Icon Image','required');  
			$this->form_validation->set_rules('link','Insert Link','required');  
			$this->form_validation->set_rules('package','Insert Package Name','required');  
			$this->form_validation->set_rules('amount','Insert Amount','required');  
			$this->form_validation->set_rules('priority','Inser Priority','required');
			$this->form_validation->set_rules('type','Select Type','required');
							
			
			if($this->form_validation->run() == FALSE)
			{
				     $this->data = array(
						'success' => $this->session->flashdata('success'),
						'error'	=> $this->session->flashdata('error'),
						'main_content' => 'pages/offer/new'
					);
					$this->load->view('comman/templet',$this->data);
                
			}
			else
			{
					$title=$this->input->post('title');
					$shortdesc=$this->input->post('shortdesc');
					$icon=$this->input->post('icon');
					$link=$this->input->post('link');
					$package=$this->input->post('package');
					$amount=$this->input->post('amount');
					$priority=$this->input->post('priority');
					$offertype=$this->input->post('type');
					$videourl=$this->input->post('video');
					$copy=$this->input->post('copy');
					
					$data=array(
								'title'=>$title,
								'shortdesc'=>$shortdesc,
								'package'=>$package,
								'image'=>$icon,
								'amount'=>$amount,
								'link'=>$link,
								'priority'=>$priority,
								'videourl'=>$videourl,
								'offertype'=>$offertype,
								'descshow'=>$copy,
								'status'=>0
					);
				
					$addofferdata=$this->Mdl_app->addoffer($data);
					if(!empty($addofferdata))
					{
						$desc=$this->input->post('desc');
						$desc_count=count($desc);
						$counter=0;
						
						foreach ($desc as $row)
						{
							 $datas=array(
								'app_id'=>$addofferdata,
								'step'=>$row,
							);
							$this->Mdl_app->insertappdescription($datas);
							$counter++;
						}
						if($desc_count == $counter)
						{
							
							$content = array(
								"en" => "$shortdesc"
							);
							$headings = array(
								"en" => "$title"
							);

							$fields = array(
								'app_id' => "d1babf36-8b94-4544-bb09-f9076902ce62",
								'included_segments' => array('All'),
								'large_icon' =>$icon,
								'contents' => $content,
								'headings' => $headings
							);

							$fields = json_encode($fields);


							$ch = curl_init();
							curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
							curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
								'Authorization: Basic Y2E3NzNjMWItNTlkMi00ZTBkLWFjYjYtZjFhYmNlNmQ1ZWZj'));
							curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
							curl_setopt($ch, CURLOPT_HEADER, FALSE);
							curl_setopt($ch, CURLOPT_POST, TRUE);
							curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
							curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

							$response = curl_exec($ch);
							curl_close($ch);

					
					
						   $this->session->set_flashdata('success', 'Add Offer Successfully');
						   redirect('offers/newoffer');	
						}
						else
						{
							$data=$this->session->set_flashdata('error','Some Problem Into Description.');
							redirect('offers/newoffer');
						}
					}
					else
					{
						$data=$this->session->set_flashdata('error','Something went Wrong. Data not inserted Proper.');
						redirect('offers/newoffer');
					}
			}
		}
		else
		{
			 $data=$this->session->set_flashdata('error','Something Went Wrong.');
			 redirect('offers/newoffer');
		}
	}	
	public function editoffers($id)
	{
		$editdata=$this->Mdl_app->editoffer($id);
		$editofferdesc=$this->Mdl_app->editofferdesc($id);
		$this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'editdata'=>$editdata,
			'editofferdesc'=>$editofferdesc,
			'id'=>$id,
            'main_content' => 'pages/offer/edit'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function editoffer($id)
	{
		$ispost=$this->input->method(TRUE);
		if($ispost == "POST")
		{
			$this->form_validation->set_rules('title','Enter Title','required');
			$this->form_validation->set_rules('icon','Icon Image','required');  
			$this->form_validation->set_rules('link','Insert Link','required');  
			$this->form_validation->set_rules('package','Insert Package Name','required');  
			$this->form_validation->set_rules('amount','Insert Amount','required');  
			$this->form_validation->set_rules('priority','Inser Priority','required');
			$this->form_validation->set_rules('type','Select Type','required');
							
	
			if($this->form_validation->run() == FALSE)
			{
				   	$applist=$this->Mdl_app->fetchoffer();
					$this->data = array(
						'success' => $this->session->flashdata('success'),
						'error'	=> $this->session->flashdata('error'),
						'applist'=>$applist,
						'main_content' => 'pages/offer/offerlist'
					);
					$this->load->view('comman/templet',$this->data);
                
			}
			else
			{
					$title=$this->input->post('title');
					$shortdesc=$this->input->post('shortdesc');
					$icon=$this->input->post('icon');
					$link=$this->input->post('link');
					$package=$this->input->post('package');
					$amount=$this->input->post('amount');
					$priority=$this->input->post('priority');
					$offertype=$this->input->post('type');
					$videourl=$this->input->post('video');
					$copy=$this->input->post('copy');
					
					$data=array(
								'title'=>$title,
								'shortdesc'=>$shortdesc,
								'package'=>$package,
								'image'=>$icon,
								'amount'=>$amount,
								'link'=>$link,
								'priority'=>$priority,
								'videourl'=>$videourl,
								'offertype'=>$offertype,
								'descshow'=>$copy,
								'status'=>0
					);
					$addofferdata=$this->Mdl_app->updateoffer($data,$id);
					$offerdelete=$this->Mdl_app->deleteoffers($id);
					
					if(!empty($offerdelete))
					{
					
						$desc=$this->input->post('desc');
						$desc_count=count($desc);
						$counter=0;
						
						foreach ($desc as $row)
						{
							 $datas=array(
								'app_id'=>$id,
								'step'=>$row,
							);
							$this->Mdl_app->insertappdescription($datas);
							$counter++;
						}
						if($desc_count == $counter)
						{
						   $this->session->set_flashdata('success', 'Update Offer Successfully');
						   redirect('offers');	
						}
						else
						{
							$data=$this->session->set_flashdata('error','Some Problem Into Description.');
							redirect('offers');	
						}
					}
					else
					{
						$data=$this->session->set_flashdata('error','Something went Wrong. Data not inserted Proper.');
						redirect('offers');	;
					}
			}
		}
		else
		{
			 $data=$this->session->set_flashdata('error','Something Went Wrong.');
			 redirect('offers');	
		}
	}
	public function changestatus($id)
	{
		if(!empty($id))
		{
		   $appstatus=$this->Mdl_app->changestatus($id);
           if($appstatus > 0)
           {
                   $this->session->set_flashdata('success', 'Update app status');
				   redirect('offers'); 
            }
            else
            {
                  $data=$this->session->set_flashdata('error','Invalid status');
				  redirect('offers'); 
            }
		}
		else
		{
			$data=$this->session->set_flashdata('error','Something want wrong');
			redirect('offers'); 
		}
	}
	/*public function profile($id)
	{
		$profile=$this->Mdl_user->fetchuserByid($id);
		$transaction=$this->Mdl_user->transactionByid($id);
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
            'profile'=>$profile,
			'transaction'=>$transaction,
            'main_content' => 'pages/user/profile'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function history($id)
	{
		$apphistory=$this->Mdl_user->historyById($id);
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'history'=>$apphistory,
            'main_content' => 'pages/user/history'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function refers($id)
	{
		$referslist=$this->Mdl_user->refersById($id);
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'refers'=>$referslist,
            'main_content' => 'pages/user/refers'
        );
        $this->load->view('comman/templet',$this->data);
	}
	/*
	public function adduser()
    {

        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
            'main_content' => 'pages/user/adduser'
        );
        $this->load->view('comman/templet',$this->data);
    }
	public function insertuser()
	{
		$ispost=$this->input->method(TRUE);
		if($ispost == "POST")
		{
			$this->form_validation->set_rules('username','user Name','required');
			$this->form_validation->set_rules('emailaddress','Email Address','trim|required|valid_email|is_unique[tbluser.email]');  
			$this->form_validation->set_rules('password','Password','required');  
			$this->form_validation->set_rules('cnf_password','Confirm password','required|matches[password]');  
			
			if($this->form_validation->run() == FALSE)
			{
				
				   $data=$this->session->set_flashdata('error','Try with another email or password and confirm password not match');
				   redirect('user/adduser');
                
			}
			else
			{
					$username=$this->input->post('username');
					$emailaddress=$this->input->post('emailaddress');
					$password=$this->input->post('password');
					
					$data=array(
								'name'=>$username,
								'email'=>$emailaddress,
								'password'=>md5($password)
					);
				
					$adduser=$this->Mdl_user->adduser($data);

					if($adduser > 0)
					{
						   $this->session->set_flashdata('success', 'Add user Details Successfully');
						   redirect('user/adduser');
					}
					else
					{
						  $data=$this->session->set_flashdata('error','Please enter valid Data');
						  redirect('user/adduser');
					}
					
			}
		}
		else
		{
			 $data=$this->session->set_flashdata('error','Something Went Wrong.');
			 redirect('user/adduser');
		}
	}
	
	public function edituser($id)
    {
        if(!empty($id))
        {
           $fetchuserdata=$this->Mdl_user->fetchuserdata($id);
           $this->data = array(
                'success' => $this->session->flashdata('success'),
                'error'	=> $this->session->flashdata('error'),
                'fetchuserdata'=>$fetchuserdata,
                'id'=>$id,
                'main_content' => 'pages/user/edituser'
            );
            $this->load->view('comman/templet',$this->data);

        }
        else
        {
            $data=$this->session->set_flashdata('error','Something Went Wrong');
            redirect('user'); 
        }
    }
	public function updateuser($id)
	{
		if(!empty($id))
        {
			$ispost=$this->input->method(TRUE);
			
			if($ispost == "POST")
			{
					$this->form_validation->set_rules('username','user Name','required');
			$this->form_validation->set_rules('emailaddress','Email Address','trim|required|valid_email');    
				  
					if($this->form_validation->run() == FALSE)
					
					{
					$this->session->set_flashdata('error','Something Went Wrong');
						redirect('user');

					}
					else
					{
							$username=$this->input->post('username');
							$emailaddress=$this->input->post('emailaddress');
							$data=array(
										'name'=>$username,
										'email'=>$emailaddress
							);
						   $updatecust=$this->Mdl_user->updateuserdata($data,$id);

						   if($updatecust > 0)
						   {
								   $this->session->set_flashdata('success', 'Update user Successfully');
								   redirect('user');
							}
							else
							{
								  $data=$this->session->set_flashdata('error','Please enter valid Data');
								  redirect('user');
							}
		   
					}					
			}
			else
			{
				 $data=$this->session->set_flashdata('error','Something Went Wrong..!');
				 redirect('user');
			}
		}
		else
		{
			$data=$this->session->set_flashdata('error','Please Select Record..!');
			redirect('user');
		}
	} 
	public function deleteuser($id)
	{
		if(!empty($id))
		{
			$deleteparty=$this->Mdl_user->deleteuser($id);
           if($deleteparty > 0)
           {
                   $this->session->set_flashdata('success', 'Delete user Successfully');
                   redirect('user');
            }
            else
            {
                  $data=$this->session->set_flashdata('error','something went wrong');
                  redirect('user');
            }
		}
		else
		{
			$data=$this->session->set_flashdata('error','Please Select Record..!');
			redirect('user');	
		}
	}
	public function login()
	{
		if(site_url() == MY_SITE)
		{
			$this->data = array(
				'success' => $this->session->flashdata('success'),
				'error'	=> $this->session->flashdata('error'),
				'main_content' => 'pages/user/login'
			);
			$this->load->view('pages/user/login',$this->data);
		}
		else
		{
			echo "404 Page Not Found..!";
			exit;
		}
	}
	public function checklogin()
	{
        $ispost=$this->input->method(TRUE);
		if($ispost == "POST")
		{
		
			$this->form_validation->set_rules('emailaddress','Email','required');
			$this->form_validation->set_rules('password','password','required');  
			
			if($this->form_validation->run() == FALSE)
			{
				
				   $data=$this->session->set_flashdata('error','something went wrong');
				   redirect('user/login');
                
			}
			else
			{
					$emailaddress=$this->input->post('emailaddress');
					$password=md5($this->input->post('password'));
					
					$adduser=$this->Mdl_user->checkuser($emailaddress,$password);

					if(empty($adduser))
					{
						   $this->session->set_flashdata('error', 'Email or Password incorrect');
						   redirect('user/login');
					}
					else
					{
						$this->session->set_userdata('userdata',$adduser);
						redirect('dashboard');
					}
					
			}
		}
		else
		{
			 $data=$this->session->set_flashdata('error','Something Went Wrong.');
			 redirect('user/login');
		}
	}
	public function logout()
	{
		$this->session->unset_userdata('userdata');
        redirect('user/login');
	} */
	
}
