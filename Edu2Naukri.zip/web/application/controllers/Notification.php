<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Notification extends CI_Controller {

	public function __construct(){
		parent::__construct();
		if(site_url() == MY_SITE)
		{		
			
			if($this->session->userdata('userdata'))
			{
				$this->load->Model('Mdl_notification');
				$this->load->library('form_validation','globals');
				$this->load->helper(array('form', 'url'));
			}
			else
			{
				redirect('user/login');
				exit;
			}
		}
		else
		{
			redirect('user/login');
			exit;
		}
    }
	public function index()
	{
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
            'main_content' => 'pages/notify/view'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function send()
	{
		$ispost=$this->input->method(TRUE);
		if($ispost == "POST")
		{
			$this->form_validation->set_rules('title','Title','required');
			$this->form_validation->set_rules('message','Message','required');  
			
			if($this->form_validation->run() == FALSE)
			{
				 $this->data = array(
					'success' => $this->session->flashdata('success'),
					'error'	=> $this->session->flashdata('error'),
					'main_content' => 'pages/notify/view'
				);
				$this->load->view('comman/templet',$this->data);
                
			}
			else
			{
					$title=$this->input->post('title');
					$message=$this->input->post("message");
					
					//$device_ids = array('30cc83bd8992f576');
					$content = array(
						"en" => "$message"
					);
					$headings = array(
						"en" => "$title"
					);
					$data = array(
						"title"          => $title,
						"message"        => $message,
						"type"          => 'custom'
					);
					$fields = array(
						'app_id' => "d1babf36-8b94-4544-bb09-f9076902ce62",
						'included_segments' => array('All'),
						'large_icon' =>"ic_launcher_round.png",
						'contents' => $content,
						'data' => $data,
						'headings' => $headings
					);

					$fields = json_encode($fields);


					$ch = curl_init();
					curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
					curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
						'Authorization: Basic Y2E3NzNjMWItNTlkMi00ZTBkLWFjYjYtZjFhYmNlNmQ1ZWZj'));
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
					curl_setopt($ch, CURLOPT_HEADER, FALSE);
					curl_setopt($ch, CURLOPT_POST, TRUE);
					curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
					curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

					$response = curl_exec($ch);
					curl_close($ch);
				    if(!empty($response))
					{
						$data=$this->session->set_flashdata('success','Successfully Send Notification');
						redirect('notification');
					}
					else
					{
						$data=$this->session->set_flashdata('error','Something Went Wrong.');
						redirect('notification');
					}
			}
		}
		else
		{
			 $data=$this->session->set_flashdata('error','Something Went Wrong.');
			 redirect('notification');
		}	
	}
	public function sendnoti()
	{
		
		
		$content = array(
			"en" => "Hello"
		);
		$headings = array(
			"en" => "Manoj"
		);
		$data = array(
			"title"          => "Hello",
			"message"        => "Good",
			"type"          => 'custom'
		);
		$fields = array(
			'app_id' => "d1babf36-8b94-4544-bb09-f9076902ce62",
			'include_player_ids' => ['d42e4c4d-5479-425e-8a50-cf980fc427e0'],
			'large_icon' =>"ic_launcher_round.png",
			'contents' => $content,
			'data' => $data,
			'headings' => $headings
		);
		$fields = json_encode($fields);
		print("\nJSON sent:\n");
		print($fields);

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
												   'Authorization: Basic xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);    

		$response = curl_exec($ch);
		curl_close($ch);

	
		/*$registration_ids = array('3090376804996733');
		$token="3090376804996733";
		$title = "Title";
		$body = "Body of the message";
		$notification = array('title' =>$title , 'text' => $body, 'sound' => 'default', 'badge' => '1');
		$arrayToSend = array('registration_tokens'=>$registration_ids,'to' => $token, 'notification' => $notification,'priority'=>'high');
		$data = json_encode($arrayToSend);
		//FCM API end-point
		$url = 'https://fcm.googleapis.com/fcm/send';
		//api_key in Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key
		$server_key = 'AAAAEunAlic:APA91bEe-EJz_KetmTqpXVL2p9-v1dXbaORUMSyFVF5l4tCFwOWxutHOAVYMfYGMGgjpOhey7IzjZPhPtFPo85-jKeINfwU0-9-KaXKwu88-rby4YI8m4TlV0R1_uj3Nk8UhhYvwvCPE';
		//header with content_type api key
		$headers = array(
			'Content-Type:application/json',
			'Authorization:key='.$server_key
		);
		//CURL request to route notification to FCM connection server (provided by Google)
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		$result = curl_exec($ch);
		if ($result === FALSE) {
			die('Oops! FCM Send Error: ' . curl_error($ch));
		}
		curl_close($ch);
		
		$url = "https://fcm.googleapis.com/fcm/send";
		$token = "81231124007";
		$serverKey = 'AAAAEunAlic:APA91bEe-EJz_KetmTqpXVL2p9-v1dXbaORUMSyFVF5l4tCFwOWxutHOAVYMfYGMGgjpOhey7IzjZPhPtFPo85-jKeINfwU0-9-KaXKwu88-rby4YI8m4TlV0R1_uj3Nk8UhhYvwvCPE';
		$title = "Title";
		$body = "Body of the message";
		$notification = array('title' =>$title , 'text' => $body, 'sound' => 'default', 'badge' => '1');
		$arrayToSend = array('to' => $token, 'notification' => $notification,'priority'=>'high');
		$json = json_encode($arrayToSend);
		$headers = array();
		$headers[] = 'Content-Type: application/json';
		$headers[] = 'Authorization: key='. $serverKey;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);

		curl_setopt($ch, CURLOPT_CUSTOMREQUEST,"POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
		curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
		//Send the request
		$response = curl_exec($ch);
		//Close request
		if ($response === FALSE) {
		die('FCM Send Error: ' . curl_error($ch));
		}
		curl_close($ch); */
	}
}
