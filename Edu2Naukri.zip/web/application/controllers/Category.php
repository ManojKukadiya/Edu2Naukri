<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {

	public function __construct(){
		parent::__construct();
		if(site_url() == MY_SITE)
		{		

			if($this->session->userdata('userdata'))
			{
				$this->load->Model('Mdl_category');
				$this->load->library('form_validation','globals');
				$this->load->helper(array('form', 'url'));
			}
			else
			{
				redirect('user/login');
				exit;
			}
		}
		else
		{
		 	redirect('user/login');
		 	exit;
		}
    }
	public function index()
	{
		$categortlist=$this->Mdl_category->fetchcategory();
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
            'categortlist'=>$categortlist,
            'main_content' => 'pages/jobs/category/view'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function newcategory()
	{
		$this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
            'main_content' => 'pages/jobs/category/new'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function addcategory()
	{
		$ispost=$this->input->method(TRUE);
		if($ispost == "POST")
		{
			$this->form_validation->set_rules('category','Category','required');
			if($this->form_validation->run() == FALSE)
			{
				     $this->data = array(
						'success' => $this->session->flashdata('success'),
						'error'	=> $this->session->flashdata('error'),
						'main_content' => 'pages/jobs/category/new'
					);
					$this->load->view('comman/templet',$this->data);
                
			}
			else
			{
					$category=$this->input->post('category');
					$data=array(
								'name'=>$category
					);
				
					$addjobsdata=$this->Mdl_category->addcategory($data);

					if(!empty($addjobsdata))
					{
						   $this->session->set_flashdata('success', 'Add Category Successfully');
						   redirect('category/newcategory');	
					}
					else
					{
						$data=$this->session->set_flashdata('error','Something went Wrong. Data not inserted Proper.');
						redirect('category/newcategory');
					}
			}
		}
		else
		{
			 $data=$this->session->set_flashdata('error','Something Went Wrong.');
			 redirect('category/newcategory');
		}			
	}
	
	public function editcategory($id)
	{
		$fetchCategoryById=$this->Mdl_category->fetchCategoryById($id);
		$this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'fetchCategoryById'=>$fetchCategoryById,
			'id'=>$id,
            'main_content' => 'pages/jobs/category/edit'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function editcategorychange($id)
	{
		$ispost=$this->input->method(TRUE);
		if($ispost == "POST")
		{
			$this->form_validation->set_rules('category','Category','required'); 
			if($this->form_validation->run() == FALSE)
			{
				    redirect('category/newcategory');
                
			}
			else
			{
					$category=$this->input->post('category');
					
					$data=array(
								'name'=>$category,
					);
				
					$editcategory=$this->Mdl_category->editcategory($data,$id);
					if(!empty($editcategory))
					{
						$this->session->set_flashdata('success', 'Edit Category Successfully');
						redirect('category');	
					}
					else
					{
						$data=$this->session->set_flashdata('error','Something went Wrong. Data not inserted Proper.');
						redirect('category');	
					}
			}
		}
		else
		{
			 $data=$this->session->set_flashdata('error','Something Went Wrong.');
			 redirect('category');	
		}			
	}
	public function deletecategory($id)
	{
		if(!empty($id))
		{
		   $deleteparty=$this->Mdl_category->deletecategorys($id);
           if($deleteparty > 0)
           {
                   $this->session->set_flashdata('success', 'Delete Category Successfully');
                   redirect('category');
            }
            else
            {
                  $data=$this->session->set_flashdata('error','something went wrong');
                  redirect('category');
            }
		}
		else
		{
			$data=$this->session->set_flashdata('error','Please Select Record..!');
			redirect('category');	
		}
	}
}
