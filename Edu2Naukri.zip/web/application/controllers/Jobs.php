<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Jobs extends CI_Controller {

	public function __construct(){
		parent::__construct();
		if(site_url() == MY_SITE)
		{		

			if($this->session->userdata('userdata'))
			{
				$this->load->Model('Mdl_jobs');
				$this->load->library('form_validation','globals');
				$this->load->helper(array('form', 'url'));
			}
			else
			{
				redirect('user/login');
				exit;
			}
		}
		else
		{
		 	redirect('user/login');
		 	exit;
		}
    }
	public function index()
	{
		$joblist=$this->Mdl_jobs->fetchjobs();
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
            'joblist'=>$joblist,
            'main_content' => 'pages/jobs/joblist'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function newjobs()
	{
		$category=$this->Mdl_jobs->fetchcategory();
		$state=$this->Mdl_jobs->fetchstate();
		$qualification=$this->Mdl_jobs->fetchqualification();
		$this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'category'=>$category,
			'state'=>$state,
			'qualification'=>$qualification,
            'main_content' => 'pages/jobs/new'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function addjobs()
	{
		$ispost=$this->input->method(TRUE);
		if($ispost == "POST")
		{
			$this->form_validation->set_rules('title','Title','required');
			$this->form_validation->set_rules('category','Category','required');  
			$this->form_validation->set_rules('state','State','required');  
			$this->form_validation->set_rules('jobqulification','Job Qualification','required'); 
			$this->form_validation->set_rules('lastdate','Last Date','required'); 
			if($this->form_validation->run() == FALSE)
			{
				     $this->data = array(
						'success' => $this->session->flashdata('success'),
						'error'	=> $this->session->flashdata('error'),
						'main_content' => 'pages/jobs/newjobs'
					);
					$this->load->view('comman/templet',$this->data);
                
			}
			else
			{
					$title=$this->input->post('title');
					$category=$this->input->post('category');
					$state=$this->input->post('state');
					$jobqulification=$this->input->post('jobqulification');
					$lastdate=$this->input->post('lastdate');
					
					$data=array(
								'title'=>$title,
								'category'=>$category,
								'state'=>$state,
								'jobqulification'=>$jobqulification,
								'lastdate'=>$lastdate,
								'status'=>0
					);
				
					$addjobsdata=$this->Mdl_jobs->addjobs($data);

					if(!empty($addjobsdata))
					{
						    $content = array(
								"en" => "$lastdate"
							);
							$headings = array(
								"en" => "$title"
							);

							$fields = array(
								'app_id' => "d1babf36-8b94-4544-bb09-f9076902ce62",
								'included_segments' => array('All'),
								'large_icon' =>"ic_launcher_round.png",
								'contents' => $content,
								'headings' => $headings
							);

							$fields = json_encode($fields);


							$ch = curl_init();
							curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
							curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
								'Authorization: Basic Y2E3NzNjMWItNTlkMi00ZTBkLWFjYjYtZjFhYmNlNmQ1ZWZj'));
							curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
							curl_setopt($ch, CURLOPT_HEADER, FALSE);
							curl_setopt($ch, CURLOPT_POST, TRUE);
							curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
							curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

							$response = curl_exec($ch);
							curl_close($ch);

						   $this->session->set_flashdata('success', 'Add Offer Successfully');
						   redirect('jobs/newjobs');	
					}
					else
					{
						$data=$this->session->set_flashdata('error','Something went Wrong. Data not inserted Proper.');
						redirect('jobs/newjobs');
					}
			}
		}
		else
		{
			 $data=$this->session->set_flashdata('error','Something Went Wrong.');
			 redirect('jobs/newjobs');
		}			
	}
	
	public function editjobs($id)
	{
		$fetchJobById=$this->Mdl_jobs->fetchJobById($id);
		$category=$this->Mdl_jobs->fetchcategory();
		$state=$this->Mdl_jobs->fetchstate();
		$qualification=$this->Mdl_jobs->fetchqualification();
		$this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'category'=>$category,
			'state'=>$state,
			'fetchJobById'=>$fetchJobById,
			'id'=>$id,
			'qualification'=>$qualification,
            'main_content' => 'pages/jobs/edit'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function editjob($id)
	{
		$ispost=$this->input->method(TRUE);
		if($ispost == "POST")
		{
			$this->form_validation->set_rules('title','Title','required');
			$this->form_validation->set_rules('category','Category','required');  
			$this->form_validation->set_rules('state','State','required');  
			$this->form_validation->set_rules('jobqulification','Job Qualification','required'); 
			$this->form_validation->set_rules('lastdate','Last Date','required'); 
			if($this->form_validation->run() == FALSE)
			{
				    redirect('jobs/newjobs');
                
			}
			else
			{
					$title=$this->input->post('title');
					$category=$this->input->post('category');
					$state=$this->input->post('state');
					$jobqulification=$this->input->post('jobqulification');
					$lastdate=$this->input->post('lastdate');
					
					$data=array(
								'title'=>$title,
								'category'=>$category,
								'state'=>$state,
								'jobqulification'=>$jobqulification,
								'lastdate'=>$lastdate
					);
				
					$addjobsdata=$this->Mdl_jobs->editjobs($data,$id);
					if(!empty($addjobsdata))
					{
						$this->session->set_flashdata('success', 'Edit Offer Successfully');
						redirect('jobs');	
					}
					else
					{
						$data=$this->session->set_flashdata('error','Something went Wrong. Data not inserted Proper.');
						redirect('jobs');	
					}
			}
		}
		else
		{
			 $data=$this->session->set_flashdata('error','Something Went Wrong.');
			 redirect('jobs');	
		}			
	}
	
	public function subjobs($id)
	{
		$jobtitle=$this->Mdl_jobs->jobtitle($id);
		$subjoblist=$this->Mdl_jobs->fetchsubjobs($id);
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
            'subjoblist'=>$subjoblist,
			'jobtitle'=>$jobtitle,
			'jobid'=>$id,
            'main_content' => 'pages/jobs/subjob/view'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function newsubjob($id)
	{	
		$this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'jobid'=>$id,
            'main_content' => 'pages/jobs/subjob/new'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function addsubjob($id)
	{
		$ispost=$this->input->method(TRUE);
		if($ispost == "POST" && (!empty($id)))
		{
			$this->form_validation->set_rules('title','Title','required');
			$this->form_validation->set_rules('qualification','qualification','required');  
			$this->form_validation->set_rules('link','link','required');  
			$this->form_validation->set_rules('lastdate','Last Date','required'); 
			if($this->form_validation->run() == FALSE)
			{
				    redirect('jobs/newsubjob/'.$id);
                
			}
			else
			{
					$title=$this->input->post('title');
					$qualification=$this->input->post('qualification');
					$link=$this->input->post('link');
					$nopost=$this->input->post('nopost');
					$salary=$this->input->post('salary');
					$agelimit=$this->input->post('agelimit');
					$lastdate=$this->input->post('lastdate');
					
					$data=array(
								'job_id'=>$id,
								'title'=>$title,
								'qualification'=>$qualification,
								'link'=>$link,
								'noofpost'=>$nopost,
								'salary'=>$salary,
								'agelimit'=>$agelimit,
								'lastdate'=>$lastdate
								
					);
				
					$addsubjobsdata=$this->Mdl_jobs->addsubjobs($data);
					if(!empty($addsubjobsdata))
					{
						$this->session->set_flashdata('success', 'ADD Sub Job Successfully');
						redirect('jobs/newsubjob/'.$id);	
					}
					else
					{
						$data=$this->session->set_flashdata('error','Something went Wrong. Data not inserted Proper.');
						redirect('jobs/newsubjob/'.$id);
					}
			}
		}
		else
		{
			$data=$this->session->set_flashdata('error','Something Went Wrong.');
			redirect('jobs/newsubjob/'.$id);	
		}			
	}
	public function editsubjobs($id){
		$subjobdata=$this->Mdl_jobs->jobidBYSubjob($id);
		$this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'subjob'=>$subjobdata,
            'main_content' => 'pages/jobs/subjob/edit'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function editsubjobdata($id)
	{
		$ispost=$this->input->method(TRUE);
		if($ispost == "POST" && (!empty($id)))
		{
				
			$job_id=$this->input->post('job_id');
			$this->form_validation->set_rules('title','Title','required');
			$this->form_validation->set_rules('qualification','qualification','required');  
			$this->form_validation->set_rules('link','link','required');  
			$this->form_validation->set_rules('lastdate','Last Date','required'); 
			
			if($this->form_validation->run() == FALSE)
			{
				    redirect('jobs/subjobs/'.$job_id);
			}
			else
			{
					$title=$this->input->post('title');
					$qualification=$this->input->post('qualification');
					$link=$this->input->post('link');
					$nopost=$this->input->post('nopost');
					$salary=$this->input->post('salary');
					$agelimit=$this->input->post('agelimit');
					$lastdate=$this->input->post('lastdate');
					
					$data=array(
								'title'=>$title,
								'qualification'=>$qualification,
								'link'=>$link,
								'noofpost'=>$nopost,
								'salary'=>$salary,
								'agelimit'=>$agelimit,
								'lastdate'=>$lastdate
								
					);
				
					$editsubjobsdata=$this->Mdl_jobs->editsubjobs($data,$id);
					if(!empty($editsubjobsdata))
					{
						$this->session->set_flashdata('success', 'Edit Sub Job Successfully');
						redirect('jobs/subjobs/'.$job_id);	
					}
					else
					{
						$data=$this->session->set_flashdata('error','Something went Wrong. Data not inserted Proper.');
						redirect('jobs/subjobs/'.$job_id);
					}
			}
		}
		else
		{
			$data=$this->session->set_flashdata('error','Something Went Wrong.');
			redirect('jobs/subjobs/'.$id);	
		}	
	}
	public function changestatus($id)
	{
		if(!empty($id))
		{
		   $jobstatus=$this->Mdl_jobs->changestatus($id);
           if($jobstatus > 0)
           {
                   $this->session->set_flashdata('success', 'Update Job status');
				   redirect('jobs'); 
            }
            else
            {
                  $data=$this->session->set_flashdata('error','Invalid status');
				    redirect('jobs');  
            }
		}
		else
		{
			$data=$this->session->set_flashdata('error','Something want wrong');
			 redirect('jobs'); 
		}
	}
}
