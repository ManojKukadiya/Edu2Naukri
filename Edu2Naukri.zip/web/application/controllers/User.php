<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct(){
		parent::__construct();
		if(site_url() == MY_SITE)
		{		
		
			$this->load->Model('Mdl_user');
			$this->load->library('form_validation','globals');
			$this->load->helper(array('form', 'url'));

		}
		else
		{
		  	redirect('user/login');
		 	exit;
		}
    }
	public function index()
	{
    	if($this->session->userdata('userdata'))
		{
    		$user=$this->Mdl_user->fetchuser();
            $this->data = array(
                'success' => $this->session->flashdata('success'),
                'error'	=> $this->session->flashdata('error'),
                'user'=>$user,
                'main_content' => 'pages/user/view'
            );
            $this->load->view('comman/templet',$this->data);
		}
		else
		{
		  	redirect('user/login');
		 	exit;
		}
	}
	public function profile($id)
	{
		$profile=$this->Mdl_user->fetchuserByid($id);
		$transaction=$this->Mdl_user->transactionByid($id);
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
            'profile'=>$profile,
			'transaction'=>$transaction,
            'main_content' => 'pages/user/profile'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function editprofile($id)
	{
		if(!empty($id))
		{
		   $coin=$_POST['coin'];
		   $profilestatus=$this->Mdl_user->changeusercoin($coin,$id);
           if($profilestatus > 0)
           {
                   $this->session->set_flashdata('success', 'User profile updated');
				   redirect('user'); 
            }
            else
            {
                  $data=$this->session->set_flashdata('error','User profile not updated');
				  redirect('user'); 
            }
		}
		else
		{
			$data=$this->session->set_flashdata('error','Something want wrong');
			redirect('user'); 
		}
	}
	public function history($id)
	{
		$apphistory=$this->Mdl_user->historyById($id);
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'history'=>$apphistory,
            'main_content' => 'pages/user/history'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function refers($id)
	{
		$referslist=$this->Mdl_user->refersById($id);
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'refers'=>$referslist,
            'main_content' => 'pages/user/refers'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function userstate()
	{
		$usercount=$this->Mdl_user->getusercount();
		$userdata = array_reverse($usercount);
		$count=[];
		$label=[];
		foreach($userdata as $user)
		{
			 array_push($count,$user['count']);
			 array_push($label,$user['label']);
		}
		$data=array(
			'label'=>$label,
			'count'=>$count
		);
		if(!empty($data))
		{
			 echo json_encode($data);die;
		}
		else
		{
			echo json_encode('Userdata not avviable');die;
		}
	}
	public function changestatus($id)
	{
		if(!empty($id))
		{
		   $userstatus=$this->Mdl_user->changestatus($id);
           if($userstatus > 0)
           {
                   $this->session->set_flashdata('success', 'Update user status');
				   redirect('user'); 
            }
            else
            {
                  $data=$this->session->set_flashdata('error','Invalid status');
				  redirect('user'); 
            }
		}
		else
		{
			$data=$this->session->set_flashdata('error','Something want wrong');
			redirect('user'); 
		}
	}
	/*
	public function adduser()
    {

        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
            'main_content' => 'pages/user/adduser'
        );
        $this->load->view('comman/templet',$this->data);
    }
	public function insertuser()
	{
		$ispost=$this->input->method(TRUE);
		if($ispost == "POST")
		{
			$this->form_validation->set_rules('username','user Name','required');
			$this->form_validation->set_rules('emailaddress','Email Address','trim|required|valid_email|is_unique[tbluser.email]');  
			$this->form_validation->set_rules('password','Password','required');  
			$this->form_validation->set_rules('cnf_password','Confirm password','required|matches[password]');  
			
			if($this->form_validation->run() == FALSE)
			{
				
				   $data=$this->session->set_flashdata('error','Try with another email or password and confirm password not match');
				   redirect('user/adduser');
                
			}
			else
			{
					$username=$this->input->post('username');
					$emailaddress=$this->input->post('emailaddress');
					$password=$this->input->post('password');
					
					$data=array(
								'name'=>$username,
								'email'=>$emailaddress,
								'password'=>md5($password)
					);
				
					$adduser=$this->Mdl_user->adduser($data);

					if($adduser > 0)
					{
						   $this->session->set_flashdata('success', 'Add user Details Successfully');
						   redirect('user/adduser');
					}
					else
					{
						  $data=$this->session->set_flashdata('error','Please enter valid Data');
						  redirect('user/adduser');
					}
					
			}
		}
		else
		{
			 $data=$this->session->set_flashdata('error','Something Went Wrong.');
			 redirect('user/adduser');
		}
	}
	
	public function edituser($id)
    {
        if(!empty($id))
        {
           $fetchuserdata=$this->Mdl_user->fetchuserdata($id);
           $this->data = array(
                'success' => $this->session->flashdata('success'),
                'error'	=> $this->session->flashdata('error'),
                'fetchuserdata'=>$fetchuserdata,
                'id'=>$id,
                'main_content' => 'pages/user/edituser'
            );
            $this->load->view('comman/templet',$this->data);

        }
        else
        {
            $data=$this->session->set_flashdata('error','Something Went Wrong');
            redirect('user'); 
        }
    }
	public function updateuser($id)
	{
		if(!empty($id))
        {
			$ispost=$this->input->method(TRUE);
			
			if($ispost == "POST")
			{
					$this->form_validation->set_rules('username','user Name','required');
			$this->form_validation->set_rules('emailaddress','Email Address','trim|required|valid_email');    
				  
					if($this->form_validation->run() == FALSE)
					
					{
					$this->session->set_flashdata('error','Something Went Wrong');
						redirect('user');

					}
					else
					{
							$username=$this->input->post('username');
							$emailaddress=$this->input->post('emailaddress');
							$data=array(
										'name'=>$username,
										'email'=>$emailaddress
							);
						   $updatecust=$this->Mdl_user->updateuserdata($data,$id);

						   if($updatecust > 0)
						   {
								   $this->session->set_flashdata('success', 'Update user Successfully');
								   redirect('user');
							}
							else
							{
								  $data=$this->session->set_flashdata('error','Please enter valid Data');
								  redirect('user');
							}
		   
					}					
			}
			else
			{
				 $data=$this->session->set_flashdata('error','Something Went Wrong..!');
				 redirect('user');
			}
		}
		else
		{
			$data=$this->session->set_flashdata('error','Please Select Record..!');
			redirect('user');
		}
	} 
	public function deleteuser($id)
	{
		if(!empty($id))
		{
			$deleteparty=$this->Mdl_user->deleteuser($id);
           if($deleteparty > 0)
           {
                   $this->session->set_flashdata('success', 'Delete user Successfully');
                   redirect('user');
            }
            else
            {
                  $data=$this->session->set_flashdata('error','something went wrong');
                  redirect('user');
            }
		}
		else
		{
			$data=$this->session->set_flashdata('error','Please Select Record..!');
			redirect('user');	
		}
	}*/
	public function login()
	{
		if(site_url() == MY_SITE)
		{
			$this->data = array(
				'success' => $this->session->flashdata('success'),
				'error'	=> $this->session->flashdata('error')
			);
			$this->load->view('pages/user/login',$this->data);
		}
		else
		{
			echo "404 Page Not Found..!";
			exit;
		}
	}
	
	public function checklogin()
	{
        $ispost=$this->input->method(TRUE);
		if($ispost == "POST")
		{
		
			$this->form_validation->set_rules('email','Email','required');
			$this->form_validation->set_rules('password','password','required');  
			
			if($this->form_validation->run() == FALSE)
			{
				
				   $data=$this->session->set_flashdata('error','something went wrong');
				   redirect('user/login');
                
			}
			else
			{
					$email=$this->input->post('email');
					$password=md5($this->input->post('password'));
					
					$adduser=$this->Mdl_user->checkuser($email,$password);

					if(empty($adduser))
					{
						   $this->session->set_flashdata('error', 'Email or Password incorrect');
						   redirect('user/login');
					}
					else
					{
						$this->session->set_userdata('userdata',$adduser);
						redirect('index');
					}
					
			}
		}
		else
		{
			 $data=$this->session->set_flashdata('error','Something Went Wrong.');
			 redirect('user/login');
		}
	}
	public function logout()
	{
		$this->session->unset_userdata('userdata');
        redirect('user/login');
	} 
	
}
