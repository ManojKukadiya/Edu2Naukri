<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Qualification extends CI_Controller {

	public function __construct(){
		parent::__construct();
		if(site_url() == MY_SITE)
		{		

			if($this->session->userdata('userdata'))
			{
				$this->load->Model('Mdl_qualification');
				$this->load->library('form_validation','globals');
				$this->load->helper(array('form', 'url'));
			}
			else
			{
				redirect('user/login');
				exit;
			}
		}
		else
		{
		 	redirect('user/login');
		 	exit;
		}
    }
	public function index()
	{
		$qualificationlist=$this->Mdl_qualification->fetchqualification();
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
            'qualificationlist'=>$qualificationlist,
            'main_content' => 'pages/jobs/qualification/view'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function newqualification()
	{
		$this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
            'main_content' => 'pages/jobs/qualification/new'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function addqualification()
	{
		$ispost=$this->input->method(TRUE);
		if($ispost == "POST")
		{
			$this->form_validation->set_rules('qualification','Category','required');
			if($this->form_validation->run() == FALSE)
			{
				     $this->data = array(
						'success' => $this->session->flashdata('success'),
						'error'	=> $this->session->flashdata('error'),
						'main_content' => 'pages/jobs/qualification/new'
					);
					$this->load->view('comman/templet',$this->data);
                
			}
			else
			{
					$qualification=$this->input->post('qualification');
					$data=array(
								'name'=>$qualification
					);
				
					$addjobsdata=$this->Mdl_qualification->addqualification($data);

					if(!empty($addjobsdata))
					{
						   $this->session->set_flashdata('success', 'Add Category Successfully');
						   redirect('qualification/newqualification');	
					}
					else
					{
						$data=$this->session->set_flashdata('error','Something went Wrong. Data not inserted Proper.');
						redirect('qualification/newqualification');
					}
			}
		}
		else
		{
			 $data=$this->session->set_flashdata('error','Something Went Wrong.');
			 redirect('qualification/newqualification');
		}			
	}
	
	public function editqualification($id)
	{
		$fetchQualificationById=$this->Mdl_qualification->fetchQualificationById($id);
		$this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'fetchQualificationById'=>$fetchQualificationById,
			'id'=>$id,
            'main_content' => 'pages/jobs/qualification/edit'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function editqualificationchange($id)
	{
		$ispost=$this->input->method(TRUE);
		if($ispost == "POST")
		{
			$this->form_validation->set_rules('qualification','Category','required'); 
			if($this->form_validation->run() == FALSE)
			{
				    redirect('qualification/newqualification');
                
			}
			else
			{
					$qualification=$this->input->post('qualification');
					
					$data=array(
								'name'=>$qualification,
					);
				
					$editqualification=$this->Mdl_qualification->editqualification($data,$id);
					if(!empty($editqualification))
					{
						$this->session->set_flashdata('success', 'Edit Category Successfully');
						redirect('qualification');	
					}
					else
					{
						$data=$this->session->set_flashdata('error','Something went Wrong. Data not inserted Proper.');
						redirect('qualification');	
					}
			}
		}
		else
		{
			 $data=$this->session->set_flashdata('error','Something Went Wrong.');
			 redirect('qualification');	
		}			
	}
	public function deletequalification($id)
	{
		if(!empty($id))
		{
		   $deleteparty=$this->Mdl_qualification->deletequalifications($id);
           if($deleteparty > 0)
           {
                   $this->session->set_flashdata('success', 'Delete Category Successfully');
                   redirect('qualification');
            }
            else
            {
                  $data=$this->session->set_flashdata('error','something went wrong');
                  redirect('qualification');
            }
		}
		else
		{
			$data=$this->session->set_flashdata('error','Please Select Record..!');
			redirect('qualification');	
		}
	}
}
