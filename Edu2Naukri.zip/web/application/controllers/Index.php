<?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    class Index extends CI_Controller {
		
	 public function __construct(){
        parent::__construct();
		if(site_url() == MY_SITE)
		{
			if($this->session->userdata('userdata'))
			{
				$this->load->Model('Mdl_dashboard');
				$this->load->library('form_validation');
				$this->load->helper(array('form', 'url'));
			}
			else
			{
				redirect('user/login');
				exit;
			}
		}
		else
		{
			redirect('user/login');
			exit;
		}
    }
	public function index()
	{
		$totaluser=$this->Mdl_dashboard->totaluser();
		$activeoffer=$this->Mdl_dashboard->activeoffer();
		$topoffer=$this->Mdl_dashboard->topoffer();
	//	$userdata=$this->Mdl_dashboard->userdata();

        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
			'totaluser'=>$totaluser,
			'activeoffer'=>$activeoffer,
            'topoffer'=>$topoffer,
            'main_content' => 'pages/dashboard/index'
        );
        $this->load->view('comman/templet',$this->data);
	}
}
