<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Payment extends CI_Controller {

	public function __construct(){
		parent::__construct();
		if(site_url() == MY_SITE)
		{		
			
			if($this->session->userdata('userdata'))
			{
				$this->load->Model('Mdl_payment');
				$this->load->library('form_validation','globals');
				$this->load->helper(array('form', 'url'));
			}
			else
			{
				redirect('user/login');
				exit;
			}
		}
		else
		{
			redirect('user/login');
			exit;
		}
    }
	public function index()
	{

		$payment=$this->Mdl_payment->fetchpayment();
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
            'payment'=>$payment,
            'main_content' => 'pages/payment/view'
        );
        $this->load->view('comman/templet',$this->data);
	}
	
	public function editpayment($id)
	{
		$singlepay=$this->Mdl_payment->fetchpaymentdata($id);
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
            'singlepay'=>$singlepay,
            'main_content' => 'pages/payment/edit'
        );
        $this->load->view('comman/templet',$this->data);
	}
	public function edit($id)
	{
		
		if(!empty($id))
        {
			$ispost=$this->input->method(TRUE);
			if($ispost == "POST")
			{
					$this->form_validation->set_rules('status','Payment Status','required');
					if($this->form_validation->run() == FALSE)
					{
						$this->session->set_flashdata('error','Something Went Wrong');
						redirect('payment');

					}
					else
					{
							$status=$this->input->post('status');
							$transation_id=$this->input->post('transation_id');
							$data=array(
										'status'=>$status,
										'transation_id'=>$transation_id
							);
						    $updatecust=$this->Mdl_payment->updatepaymentstatus($data,$id);
							
							$playerdata=$this->Mdl_payment->getPlayerid($id);
							$playerId=$playerdata['playerId'];
							if(!empty($playerId))
							{
									$playerdata=array($playerId);
									$content = array(
										"en" => "Hello"
									);
									$headings = array(
										"en" => "Manoj"
									);
									$fields = array(
										'app_id' => "d1babf36-8b94-4544-bb09-f9076902ce62",
										'include_player_ids' => $playerdata,
										'large_icon' =>"ic_launcher_round.png",
										'contents' => $content,
										'headings' => $headings
									);
									$fields = json_encode($fields);
									$ch = curl_init();
									curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
									curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
																			   'Authorization: Basic Y2E3NzNjMWItNTlkMi00ZTBkLWFjYjYtZjFhYmNlNmQ1ZWZj'));
									curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
									curl_setopt($ch, CURLOPT_HEADER, FALSE);
									curl_setopt($ch, CURLOPT_POST, TRUE);
									curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
									curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);    

									curl_exec($ch);
									curl_close($ch);
							}
						    if($updatecust > 0)
						    {
								   $this->session->set_flashdata('success', 'Update Payment Successfully');
								   redirect('payment');

							}
							else
							{
								  $data=$this->session->set_flashdata('error','Please enter valid Data');
								  	redirect('payment');

							}
		   
					}					
			}
			else
			{
				 $data=$this->session->set_flashdata('error','Something Went Wrong..!');
				redirect('payment');
			}
		}
		else
		{
			$data=$this->session->set_flashdata('error','Please Select Record..!');
			redirect('payment');
		}
	}
}
