<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

class User extends CI_Controller {
	
    public function __construct(){
        parent::__construct();
        $this->load->library('form_validation','Email');
        $this->load->Model('api/Mdl_user');
    }
    public function usersignin()
    {
        $required_fields=array('fname','email','devicetoken','playerId');
		$response=array();
		$status=$this->verifyRequiredParams($required_fields);    
        if($status)
		{
            $fname=$this->input->post('fname');
			$lname=$this->input->post('lname');
			$email=$this->input->post('email');
			$profile=$this->input->post('profile');
			$devicetoken=$this->input->post('devicetoken');
			$playerId=$this->input->post('playerId');
			
			$fbid=$this->input->post('fbid');
			
			if(!empty($fbid))
			{
				$fbidcheck=$this->Mdl_user->fbidcheck($fbid);
			}
			
            $gbid=$this->input->post('gbid');
			if(!empty($gbid))
			{
				$gbidcheck=$this->Mdl_user->gbidcheck($gbid);
			}
			
			if(!empty($gbidcheck))
			{
				$authtoken=md5(rand(100,100000));
                $logindata=array(
                    'user_id'=>$gbidcheck['id'],
                    'devicetoken'=>$devicetoken,
					'playerId'=>$playerId,
                    'authtoken'=>$authtoken
                );
                $data=$this->Mdl_user->userlogin($logindata);
                $response['status']= TRUE;
				$response['error'] = FALSE;
				$response['message'] = "Login Successfully";
				$response['data'] = $data;
			}
			elseif(!empty($fbidcheck))
			{
				$authtoken=md5(rand(100,100000));
                $logindata=array(
                    'user_id'=>$fbidcheck['id'],
                    'devicetoken'=>$devicetoken,
					'playerId'=>$playerId,
                    'authtoken'=>$authtoken
                );
                $data=$this->Mdl_user->userlogin($logindata);
                $response['status']= TRUE;
				$response['error'] = FALSE;
				$response['message'] = "Login Successfully";
				$response['data'] = $data;
			}
			else
			{
					$refferal = mt_rand(100000, 999999);
					
					$data=array(
						'fname'=>$fname,
						'lname'=>$lname,
						'email'=>$email,
						'profile'=>$profile,
						'gbid'=>$gbid,
						'fbid'=>$fbid,
						'referralcode'=>$refferal
					);
					
					
					$userregi=$this->Mdl_user->userregister($data,$email);
					
					if(!empty($userregi))
					{
						if($userregi!="2")
						{
							$receiver=$this->input->post('referralcode');
							$receivercode=$this->Mdl_user->receivercode($receiver);

							if(!empty($receivercode))
							{
								$referralcodedata=array(
									'sender_id'=>$userregi['id'],
									'receiver_id'=>$receivercode['id'],
									'status'=>1
								);
								
								$referralcode=$this->Mdl_user->referralcode($referralcodedata);
								$playerId=$receivercode['playerId'];
								if(!empty($playerId))
								{
									$playerdata=array($playerId);
									$content = array(
										"en" => "Hello"
									);
									$headings = array(
										"en" => "Manoj"
									);
									$fields = array(
										'app_id' => "d1babf36-8b94-4544-bb09-f9076902ce62",
										'include_player_ids' => $playerdata,
										'large_icon' =>"ic_launcher_round.png",
										'contents' => $content,
										'headings' => $headings
									);
									$fields = json_encode($fields);
									$ch = curl_init();
									curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
									curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
																			   'Authorization: Basic Y2E3NzNjMWItNTlkMi00ZTBkLWFjYjYtZjFhYmNlNmQ1ZWZj'));
									curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
									curl_setopt($ch, CURLOPT_HEADER, FALSE);
									curl_setopt($ch, CURLOPT_POST, TRUE);
									curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
									curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);    

									curl_exec($ch);
									curl_close($ch);
								}
								
							}
							
							$authtoken=md5(rand(100,100000));
							$logindata=array(
								'user_id'=>$userregi['id'],
								'devicetoken'=>$devicetoken,
								'playerId'=>$playerId,
								'authtoken'=>$authtoken
							);
							
							$data=$this->Mdl_user->userlogin($logindata);
							$response['status']= TRUE;
							$response['error'] = FALSE;
							$response['message'] = "Inserted Successfully";
							$response['data'] = $data;
						}
						else
						{
							$response['status']= TRUE;
							$response['error'] = FALSE;
							$response['message'] = "Email Already Inserted.";
							$response['data'] = [];
						}
					}
					else
					{
						$response['status']= TRUE;
						$response['error'] = TRUE;
						$response['message'] = "Record Not Inserted.?";
						$response['data'] = [];
					}
			}
        }
        else
        {
            $response=$this->getParameters();
        }
        $this->SendResponse($response);	 
    }

    public function logout()
	{
       
		$required_fields=array('userid','authtoken','devicetoken');
		$response=array();
		$status=$this->verifyRequiredParams($required_fields);
		if($status)
		{
           
			$userid=$this->input->post('userid');
			$authtoken=$this->input->post('authtoken');
			$devicetoken=$this->input->post('devicetoken');
            
            $data=array(
                'user_id'=>$userid,
                'authtoken'=>$authtoken,
                'devicetoken'=>$devicetoken
            );
            $result=$this->Mdl_user->logoutuser($data);
			if($result > 0)
			{
				$response["status"]=TRUE;
				$response["error"] = FALSE;
				$response['message'] = "You are successfully Logout.";
			}
			else
			{
				$response=$this->getAuthTokenResponse();
			}
		}
		else
		{
			$response=$this->getParameters();
		}
         $this->SendResponse($response);
	}

	public function userprofile()
    {
        $required_fields=array('user_id','authtoken');
		$response=array();
		$status=$this->verifyRequiredParams($required_fields);    
        if($status)
		{
			$user_id=$this->input->post('user_id');
			$authtoken=$this->input->post('authtoken');
			$isAuthValid=$this->Mdl_user->IsValidAuthToken($user_id,$authtoken);
			if($isAuthValid)
			{
				 $divcoin=$this->Mdl_user->miniAmount();
                 $profiledata=$this->Mdl_user->profiledata($user_id);
				 if($profiledata > 0)
				 {
					 $response['status']= TRUE;
					 $response['error'] = FALSE;
					 $response['message'] = "Fetch User Profile ";
					 $response['minwithdrow'] = $divcoin['miniwith'];
					 $response['divcoin'] = $divcoin['coin'];
					 $response['data'] = $profiledata;
				 }
				 else
				 {
					 $response['status']= TRUE;
					 $response['error'] = FALSE;
					 $response['message'] = "Something Want Wrong";
					 $response['minwithdrow'] = 0;
					 $response['divcoin'] = 0;
					 $response['data']=[];
				 }
			

            }
			else
			{
				$response=$this->getAuthTokenResponse();
			}
		}
		else
        {
            $response=$this->getParameters();
        }
        $this->SendResponse($response);	
    }
	public function redeem(){
		$required_fields=array('user_id','mode','amount','authtoken');
		$response=array();
		$status=$this->verifyRequiredParams($required_fields);    
        if($status)
		{
			$user_id=$this->input->post('user_id');
			$authtoken=$this->input->post('authtoken');
			$mode=$this->input->post('mode');
			$upi=$this->input->post('upi');
			$phoneno=$this->input->post('phoneno');
			$bankname=$this->input->post('bankname');
			$bankaccount=$this->input->post('bankaccount');
			$bankifsc=$this->input->post('bankifsc');
			$amount=$this->input->post('amount');
			
			$isAuthValid=$this->Mdl_user->IsValidAuthToken($user_id,$authtoken);
			if($isAuthValid)
			{
				
				$UserAmount=$this->Mdl_user->checkAmount($user_id);
				$AppSettings=$this->Mdl_user->miniAmount();
				if($UserAmount == "-1")
				{
					$response['status']= TRUE;
					$response['error'] = TRUE;
					$response['message'] = "Unable to withdraw money";
				}
				else if($amount < $AppSettings['miniwith'])
				{
					$response['status']= TRUE;
					$response['error'] = TRUE;
					$response['message'] = "Minimum Withdraw Amount ".$AppSettings['miniwith'];
				}
				else if($amount > ($UserAmount/$AppSettings['coin']))
				{
					$response['status']= TRUE;
					$response['error'] = TRUE;
					$response['message'] = "Insufficient Amount";
				}
				else 
				{
					$data=array(
						'user_id'=>$user_id,
						'mode'=>$mode,
						'upi'=>$upi,
						'phoneno'=>$phoneno,
						'bankname'=>$bankname,
						'bankaccount'=>$bankaccount,
						'bankifsc'=>$bankifsc,
						'amount'=>$amount
					 );
					 $withcoin=$amount*$AppSettings['coin'];
					 $result=$this->Mdl_user->redeemuser($data,$withcoin);
					 if($result > 0)
					 {
						$response["status"]=TRUE;
						$response["error"] = FALSE;
						$response['message'] = "Amount Withdraw Successfully";
					 }
					 else
					 {
						 $response['status']= TRUE;
						 $response['error'] = FALSE;
						 $response['message'] = "Something Want Wrong";
					 }
				}
            }
			else
			{
				$response=$this->getAuthTokenResponse();
			}
		}
		else
        {
            $response=$this->getParameters();
        }
        $this->SendResponse($response);	
	}
	
	public function transation()
	{
        $required_fields=array('user_id','authtoken');
		$response=array();
		$status=$this->verifyRequiredParams($required_fields);    
        if($status)
		{
			$user_id=$this->input->post('user_id');
			$authtoken=$this->input->post('authtoken');
			$isAuthValid=$this->Mdl_user->IsValidAuthToken($user_id,$authtoken);
			if($isAuthValid)
			{
				$result=$this->Mdl_user->transationHistory($user_id);
				if($result > 0)
				 {
					$response["status"]=TRUE;
					$response["error"] = FALSE;
					$response['message'] = "Transation History";
					$response['data'] = $result;
				 }
				 else
				 {
					 $response['status']= TRUE;
					 $response['error'] = FALSE;
					 $response['message'] = "Something Want Wrong";
					 $response['data']=[];
				 }

            }
			else
			{
				$response=$this->getAuthTokenResponse();
			}
		}
		else
        {
            $response=$this->getParameters();
        }
        $this->SendResponse($response);	
    }
	public function withdraw()
	{
        $required_fields=array('user_id','authtoken');
		$response=array();
		$status=$this->verifyRequiredParams($required_fields);    
        if($status)
		{
			$user_id=$this->input->post('user_id');
			$authtoken=$this->input->post('authtoken');
			$isAuthValid=$this->Mdl_user->IsValidAuthToken($user_id,$authtoken);
			if($isAuthValid)
			{
				$result=$this->Mdl_user->WithdrawHistory($user_id);
				if($result > 0)
				 {
					$response["status"]=TRUE;
					$response["error"] = FALSE;
					$response['message'] = "Withdraw History";
					$response['data'] = $result;
				 }
				 else
				 {
					 $response['status']= TRUE;
					 $response['error'] = FALSE;
					 $response['message'] = "Something Want Wrong";
					 $response['data']=[];
				 }

            }
			else
			{
				$response=$this->getAuthTokenResponse();
			}
		}
		else
        {
            $response=$this->getParameters();
        }
        $this->SendResponse($response);	
    }
	public function userInvite()
	{
        $required_fields=array('user_id','authtoken');
		$response=array();
		$status=$this->verifyRequiredParams($required_fields);    
        if($status)
		{
			$user_id=$this->input->post('user_id');
			$authtoken=$this->input->post('authtoken');
			$isAuthValid=$this->Mdl_user->IsValidAuthToken($user_id,$authtoken);
			if($isAuthValid)
			{
				$result=$this->Mdl_user->userInvite($user_id);
				if($result > 0)
				 {
					$response["status"]=TRUE;
					$response["error"] = FALSE;
					$response['message'] = "Invite Massage";
					$response['data'] = $result;
				 }
				 else
				 {
					 $response['status']= TRUE;
					 $response['error'] = FALSE;
					 $response['message'] = "Something Want Wrong";
					 $response['data']=[];
				 }

            }
			else
			{
				$response=$this->getAuthTokenResponse();
			}
		}
		else
        {
            $response=$this->getParameters();
        }
        $this->SendResponse($response);	
    }
	public function contactus()
	{
		$required_fields=array('user_id','authtoken');
		$response=array();
		$status=$this->verifyRequiredParams($required_fields);    
        if($status)
		{
			$user_id=$this->input->post('user_id');
			$authtoken=$this->input->post('authtoken');
			$isAuthValid=$this->Mdl_user->IsValidAuthToken($user_id,$authtoken);
			if($isAuthValid)
			{
				$heading=$this->input->post('heading');
				$message=$this->input->post('message');
				$data=array(
					'user_id'=>$user_id,
					'heading'=>$heading,
					'message'=>$message
				);
				$contactform=$this->Mdl_user->contactForm($data);
				if(!empty($contactform))
				 {
					$response["status"]=TRUE;
					$response["error"] = FALSE;
					$response['message'] = "Form Submitted";
				 }
				 else
				 {
					 $response['status']= TRUE;
					 $response['error'] = FALSE;
					 $response['message'] = "Something Want Wrong";
				 }

            }
			else
			{
				$response=$this->getAuthTokenResponse();
			}
		}
		else
        {
            $response=$this->getParameters();
        }
        $this->SendResponse($response);	
	}
	public function aboutus()
	{
		$required_fields=array('user_id','authtoken');
		$response=array();
		$status=$this->verifyRequiredParams($required_fields);    
        if($status)
		{
			$user_id=$this->input->post('user_id');
			$authtoken=$this->input->post('authtoken');
			$isAuthValid=$this->Mdl_user->IsValidAuthToken($user_id,$authtoken);
			if($isAuthValid)
			{
				$result=$this->Mdl_user->fetchaboutus();
				if($result > 0)
				 {
					$response["status"]=TRUE;
					$response["error"] = FALSE;
					$response['message'] = "get Aboutus";
					$response['data'] = $result;
				 }
				 else
				 {
					 $response['status']= TRUE;
					 $response['error'] = FALSE;
					 $response['message'] = "Something Want Wrong";
					 $response['data']=[];
				 }


            }
			else
			{
				$response=$this->getAuthTokenResponse();
			}
		}
		else
        {
            $response=$this->getParameters();
        }
        $this->SendResponse($response);	
	}
	public function privacy()
	{
		$required_fields=array('user_id','authtoken');
		$response=array();
		$status=$this->verifyRequiredParams($required_fields);    
        if($status)
		{
			$user_id=$this->input->post('user_id');
			$authtoken=$this->input->post('authtoken');
			$isAuthValid=$this->Mdl_user->IsValidAuthToken($user_id,$authtoken);
			if($isAuthValid)
			{
				$result=$this->Mdl_user->fetchprivacy();
				if($result > 0)
				 {
					$response["status"]=TRUE;
					$response["error"] = FALSE;
					$response['message'] = "get Privacy";
					$response['data'] = $result;
				 }
				 else
				 {
					 $response['status']= TRUE;
					 $response['error'] = FALSE;
					 $response['message'] = "Something Want Wrong";
					 $response['data']=[];
				 }


            }
			else
			{
				$response=$this->getAuthTokenResponse();
			}
		}
		else
        {
            $response=$this->getParameters();
        }
        $this->SendResponse($response);	
	}
	public function teamcondition()
	{
		$required_fields=array('user_id','authtoken');
		$response=array();
		$status=$this->verifyRequiredParams($required_fields);    
        if($status)
		{
			$user_id=$this->input->post('user_id');
			$authtoken=$this->input->post('authtoken');
			$isAuthValid=$this->Mdl_user->IsValidAuthToken($user_id,$authtoken);
			if($isAuthValid)
			{
				$result=$this->Mdl_user->fetchteam();
				if($result > 0)
				 {
					$response["status"]=TRUE;
					$response["error"] = FALSE;
					$response['message'] = "get Team and Condition";
					$response['data'] = $result;
				 }
				 else
				 {
					 $response['status']= TRUE;
					 $response['error'] = FALSE;
					 $response['message'] = "Something Want Wrong";
					 $response['data']=[];
				 }
            }
			else
			{
				$response=$this->getAuthTokenResponse();
			}
		}
		else
        {
            $response=$this->getParameters();
        }
        $this->SendResponse($response);	
	}
	public function dailychecking()
    {
		$required_fields=array('user_id','authtoken');
		$response=array();
		$status=$this->verifyRequiredParams($required_fields);    
        if($status)
		{
			$user_id=$this->input->post('user_id');
			$authtoken=$this->input->post('authtoken');
			$isAuthValid=$this->Mdl_user->IsValidAuthToken($user_id,$authtoken);
			if($isAuthValid)
			{
					$coindaily=$this->Mdl_user->fetchsetting();
					$coin= rand($coindaily['min_coin'],$coindaily['max_coin']);
					$todaydate=date('Y-m-d H:i:s');
					$data=array(
							'user_id'=>$user_id,
							'tran_date'=>$todaydate,
							'coin'=>$coin,
							'description'=>'Daily Coin' );
					if(!empty($data))
					{
						if($coin != "0")
					    {
							$transation=$this->Mdl_user->dailychecknow($data);
							if($transation>0)
							{
								$coins=array(
										'user_id'=>$user_id,
										'totalcoin'=>$coin
									);
								$addcoin=$this->Mdl_user->addcoin($coins);
								if(!empty($addcoin))
								{
										$response['status']= TRUE;
										$response['error'] = FALSE;
										if($coin == "-1")
											$response['message'] = "Better Luck Next Time ?";
										else
											$response['message'] = "You have won  ".$coin." Coins ";
								}
								else
								{
									$response['status']= TRUE;
									$response['error'] = FALSE;
									$response['message'] = "Something Want Wrong.";
								}
							}
							else
							{
								$response['status']= TRUE;
								$response['error'] = TRUE;
								$response['message'] = "Record Not Inserted Properly..?";
							}
						}
						else
						{
							
							$response['status']= TRUE;
							$response['error'] = TRUE;
							$response['message'] = "Better Luck Next Time ?";
						}
				}
				else
				{
					$response['status']= TRUE;
					$response['error'] = TRUE;
					$response['message'] = "Better Luck Next Time ?";
				}
			}
			else
			{
				$response=$this->getAuthTokenResponse();
			}
		}
		else
        {
            $response=$this->getParameters();
        }
        $this->SendResponse($response);	
	}
	
	public function adslist()
	{
		$result=$this->Mdl_user->fetchadslist();
		if($result > 0)
		 {
			$response["status"]=TRUE;
			$response["error"] = FALSE;
			$response['message'] = "get Ads List";
			$response['data'] = $result;
		 }
		 else
		 {
			 $response['status']= TRUE;
			 $response['error'] = FALSE;
			 $response['message'] = "Something Want Wrong";
			 $response['data']=[];
		 }
		$this->SendResponse($response);	
      
	}
    public function verifyRequiredParams($fields)
    {
        $error = false;
        $error_fields = "";
        $request_params = array();
        $request_params = $_REQUEST;
        foreach ($fields as $field) 
		{
			if (!isset($request_params[$field])) 
			{
				$error = true;
				$error_fields .= $field . ', ';
			}
		}
		if ($error) 
		{
			$response = array();
			$response["error"] = true;
			$response["status"]=false;
			$response["message"] = 'One or more fileds are required. ' . substr($error_fields, 0, -2);
			return false;
		}
		else
		{
			return true;
		}		 
    }
    public function SendResponse($response)
	{
		header('Content-Type: application/json');
		echo json_encode($response);
		die; 
	}
	public function getAuthTokenResponse()
	{
			$response = array();
			$response['error'] = true;
			$response['status'] = true;
			$response['message'] = 'Session Expired';
			return $response;
	}
    public function getParameters()
	{
		$response = array();
		$response['status']= false;
		$response['error'] = true;
        $response['message'] = 'Invalid Parameters';
		return $response;
	} 
}