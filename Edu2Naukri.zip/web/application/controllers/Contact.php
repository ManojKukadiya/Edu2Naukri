<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Contact extends CI_Controller {

	public function __construct(){
		parent::__construct();
		if(site_url() == MY_SITE)
		{		
			if($this->session->userdata('userdata'))
			{
				$this->load->Model('Mdl_contact');
				$this->load->library('form_validation','globals');
				$this->load->helper(array('form', 'url'));
			}
			else
			{
				redirect('user/login');
				exit;
			}
		}
		else
		{
			redirect('user/login');
			exit;
		}
    }
	public function index()
	{

		$contact=$this->Mdl_contact->fetchcontact();
        $this->data = array(
            'success' => $this->session->flashdata('success'),
            'error'	=> $this->session->flashdata('error'),
            'contact'=>$contact,
            'main_content' => 'pages/contact/view'
        );
        $this->load->view('comman/templet',$this->data);
	}
	
	
}
