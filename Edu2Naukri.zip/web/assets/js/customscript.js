$(document).ready(function() {
	/** Add More Filed In Application List **/
	$(document).on("click", ".adddescription", function(){
				var n = $('.dynamic').length + 1;
				var box_html='<div class="form-group ofer29-div dynamic" id="row'+n+'"><div class="input-group"><input type="text" name="desc[]" placeholder="Enter Step" class="form-control"><div class="input-group-append"><button class="btn btn-danger remove-box" type="button" ><i class="fas fa-times"></i></button></div></div></div>';
				$(box_html).hide();
				$('div.dynamic:last').after(box_html);
				$(box_html).fadeIn('slow');
				return false;
	});
	$(document).on("click", ".remove-box", function(){
		$(this).parent().parent().css( 'background-color', '#D3D3D3' );
		$(this).parent().fadeOut("fast", function() {
			$(this).parent().remove();
		});
		return false;
	});
	
	$('#imgTxt').hide();
	$('#selector').on('click', function(){
		$('#image_file').trigger('click');
	});
	$("#image_file").change(function(){
		if (this.files && this.files[0]) {
		  var reader = new FileReader();

		  reader.onload = function (e) {
			$('#preview').attr('src', e.target.result);
			$('#preview').show();
			$('#imgTxt').hide();
		  }

		  reader.readAsDataURL(this.files[0]);
		}
	});
 });